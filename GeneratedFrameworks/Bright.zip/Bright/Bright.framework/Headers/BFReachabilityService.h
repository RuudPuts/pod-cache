#import <Bright/Bright.h>
#import <Bright/BFReachability.h>

NS_ASSUME_NONNULL_BEGIN

@protocol BFReachabilityService <BFServiceInterface>

- (void)getReachabilityStatusForHostname:(NSString *)hostname completion:(void(^ __nullable)(BFReachabilityStatus status))completion;
- (void)getReachabilityStatusForInternet:(void(^)(BFReachabilityStatus status))completion;

@end

@interface BFReachabilityServiceImplementation : BFService <BFReachabilityService>

@end

NS_ASSUME_NONNULL_END
