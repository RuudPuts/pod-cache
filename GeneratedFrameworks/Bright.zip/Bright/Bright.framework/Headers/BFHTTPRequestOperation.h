#import <Bright/BFURLConnectionOperation.h>

NS_ASSUME_NONNULL_BEGIN

@class BFHTTPRequestOperation, BFError;
@protocol BFHTTPBodyEncoder, BFHTTPRequestOperationDelegate;

@protocol BFHTTPRequestResponseDecoder <BFURLRequestResponseDecoder>
@optional

- (void)operation:(BFHTTPRequestOperation *)operation modifyRequest:(NSMutableURLRequest *)request;

@end

extern NSString *const BFHTTPRequestOperationErrorDomain;

typedef NS_ENUM(NSUInteger, BFHTTPRequestOperationErrorCode) {
    BFHTTPRequestOperationErrorInvalidStatusCode = 1,
    BFHTTPRequestOperationErrorInvalidContentTypeCode = 2,
};

typedef void (^BFHTTPRequestOperationProgressBlock)(NSUInteger bytesProcessed, long long totalBytesProcessed, long long totalBytesExpectedToProcess, BFHTTPRequestOperation *operation);
typedef NSURLRequest * _Nullable (^BFHTTPRequestOperationRedirectBlock)(NSURLConnection *connection, NSURLRequest *request, NSURLResponse * _Nullable redirectResponse, BFHTTPRequestOperation *operation);
typedef NSCachedURLResponse * _Nullable (^BFHTTPRequestOperationCacheResponseBlock)(NSURLConnection *connection, NSCachedURLResponse *cachedResponse, BFHTTPRequestOperation *operation);
typedef id _Nullable (^BFHTTPRequestOperationProcessDecodedResponse)(_Nullable id decodedResponse, BFHTTPRequestOperation *operation);

typedef void (^BFHTTPRequestOperationSuccessBlock)(_Nullable id decodedResponse, BFHTTPRequestOperation *operation);
typedef void (^BFHTTPRequestOperationFailureBlock)(BFError *error, BFHTTPRequestOperation *operation);

@interface BFHTTPRequestOperation : BFURLConnectionOperation

@property (nonatomic, readonly, nullable) NSHTTPURLResponse *httpResponse;

@property (nonatomic, assign) BOOL showNetworkActivityIndicator;
@property (nonatomic, assign) BOOL allowCompressedResponse;

@property (nonatomic, copy, nullable) NSIndexSet *acceptableStatusCodes;
@property (nonatomic, copy, nullable) NSSet<NSString*> *acceptableContentTypes;

@property (nonatomic, copy, nullable) NSString *username;
@property (nonatomic, copy, nullable) NSString *password;

@property (nonatomic, assign) BOOL bodyLoggingEnabled;

@property (nonatomic, strong) id <BFHTTPRequestResponseDecoder> decoder;
@property (nonatomic, strong) id <BFHTTPBodyEncoder> encoder;

- (void)setUploadProgressBlock:(nullable BFHTTPRequestOperationProgressBlock)block;
- (void)setDownloadProgressBlock:(nullable BFHTTPRequestOperationProgressBlock)block;

- (void)setRedirectResponseBlock:(nullable BFHTTPRequestOperationRedirectBlock)block;
- (void)setCacheResponseBlock:(nullable BFHTTPRequestOperationCacheResponseBlock)block;

- (void)setProcessDecodedResponseBlock:(nullable BFHTTPRequestOperationProcessDecodedResponse)block;

- (void)setSuccessBlock:(nullable BFHTTPRequestOperationSuccessBlock)block;
- (void)setFailureBlock:(nullable BFHTTPRequestOperationFailureBlock)block;

@property (nonatomic, weak) id <BFHTTPRequestOperationDelegate> delegate;

@end

@protocol BFHTTPRequestOperationDelegate <NSObject>
@optional

- (void)handleResponse:(NSHTTPURLResponse *)response forHTTPRequestOperation:(BFHTTPRequestOperation *)operation;
- (BOOL)handleError:(BFError *)error forHTTPRequestOperation:(BFHTTPRequestOperation *)operation;

@end

@protocol BFHTTPBodyEncoder <NSObject>
@optional

- (nullable NSInputStream *)inputStreamForOperation:(BFHTTPRequestOperation *)operation;
- (NSUInteger)inputStreamDataLengthForOperation:(BFHTTPRequestOperation *)operation;

- (nullable NSData *)encodeDataForOperation:(nullable BFHTTPRequestOperation *)operation;

- (nullable NSString *)contentTypeForOperation:(nullable BFHTTPRequestOperation *)operation;

- (void)operation:(BFHTTPRequestOperation *)operation modifyRequest:(NSMutableURLRequest *)request;

- (nullable NSString *)logDescriptionForOperation:(BFHTTPRequestOperation *)operation;

@end

NS_ASSUME_NONNULL_END
