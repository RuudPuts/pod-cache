#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIApplication (BFAdditions)

///------------------------------------------///
/// @name Calling to Phone numbers
///------------------------------------------///

/**
 Checks if we can do a phone call.
 
 @return YES if we can call.
 */
@property (nonatomic, readonly) BOOL canCallPhoneNumbers;

/**
 Makes a phone call to a given number.
 
 @param phoneNumber The number to call.
 */
- (void)callPhoneNumber:(NSString *)phoneNumber;

///------------------------------------------///
/// @name Opening Maps
///------------------------------------------///

/**
 Checks if the Google Maps app is installed (iOS6 only).
 
 @return YES if it's installed. It will return always NO in iOS5.
 */
@property (nonatomic, getter=isGoogleMapsAppInstalled, readonly) BOOL googleMapsAppInstalled;

/**
 Shows a route from current location to a given location in Google Maps app (iOS6 only).

 @param location The ending location of the route.
 */
- (void)openGoogleMapsAppForLocation:(CLLocation *)location;

///------------------------------------------///
/// @name Open Settings
///------------------------------------------///

/**
 Checks if this is the right version of iOS to open up settings, 
 as this is only supported from iOS 8 and up.
 
 @return YES If it's iOS 8 or up
 */
@property (nonatomic, readonly) BOOL canOpenSettings;

/**
 Open the 'Settings' app. If the current app has any specific app settings,
 that settings section will be opened.
 */
- (void)openSettings;

@end

NS_ASSUME_NONNULL_END
