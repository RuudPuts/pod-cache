#import <Bright/BFJihaaObject.h>

@class BFJihaaObjectEncoder;

NS_ASSUME_NONNULL_BEGIN

@interface BFJihaaObject (Encoding)

- (nullable NSDictionary *)encodeToJSON;
+ (nullable NSArray *)encodeArrayToJSON:(NSArray *)array;

- (void)encodeToFile:(NSString *)filePath;
+ (void)encodeArray:(NSArray *)array toFile:(NSString *)filePath;

@property (nonatomic, readonly, strong) BFJihaaObjectEncoder *encoder;

@end

NS_ASSUME_NONNULL_END
