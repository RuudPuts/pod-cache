#import <Bright/BFJSONDecoder.h>

@protocol BFJihaaPropertyTransformer;

NS_ASSUME_NONNULL_BEGIN

@interface BFJihaaTransformerJSONDecoder : BFJSONDecoder

- (instancetype)init NS_UNAVAILABLE;

- (instancetype)initWithTransformer:(id <BFJihaaPropertyTransformer>)transformer NS_DESIGNATED_INITIALIZER;
- (instancetype)initForClass:(Class)cls;

@property (nonatomic, readonly) id <BFJihaaPropertyTransformer> transformer;

@end

NS_ASSUME_NONNULL_END
