#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NSString * _Nonnull(^BFHTML2AttribsReplacementTextBlock)(NSString *tagName, NSString *innerText, NSDictionary *attributes, BOOL startOfText);
typedef NSDictionary * _Nonnull(^BFHTML2AttribsGenerateAttribsBlock)(NSString *tagName, NSDictionary *attributes);

@interface NSAttributedString (BFHTML)

+ (instancetype)stringFromHTML:(NSString *)html defaultAttributes:(NSDictionary *)defaultAttributes supportedTagAttributeMapping:(NSDictionary *)supportedTagAttributeMapping replacementTextBlock:(BFHTML2AttribsReplacementTextBlock)replacementTextBlock attributeBlock:(BFHTML2AttribsGenerateAttribsBlock)attributeBlock;

@end

NS_ASSUME_NONNULL_END
