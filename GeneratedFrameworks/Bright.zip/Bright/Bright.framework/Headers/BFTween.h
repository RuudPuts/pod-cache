#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <Bright/BFTweenBlocks.h>

NS_ASSUME_NONNULL_BEGIN

typedef void (^BFTweenCompletionBlock)(void);

@interface BFTween : NSObject

- (instancetype)initWithTween:(BFTweenBlock)tween
            forView:(UIView*)view
            keyPath:(NSString*)keyPath
          fromValue:(double)fromValue
            toValue:(double)toValue
           duration:(double)duration NS_DESIGNATED_INITIALIZER;

- (instancetype)initWithTweenGroup:(NSArray*)tweens
                duration:(double)duration NS_DESIGNATED_INITIALIZER;

+ (BFTween *)tween:(BFTweenBlock)tween
           forView:(UIView*)view
           keyPath:(NSString*)keyPath
         fromValue:(double)fromValue
           toValue:(double)toValue
          duration:(double)duration;

+ (BFTween *)tween:(BFTweenBlock)tween
           forView:(UIView*)view
           keyPath:(NSString*)keyPath
         fromValue:(double)fromValue
           toValue:(double)toValue;

+ (BFTween *)group:(NSArray<BFTween*>*)tweens
          duration:(double)duration;

- (BFTween*)chain:(BFTween*)tween;

- (void)perform;

- (void)performWithCompletion:(nullable BFTweenCompletionBlock)completion;

@property (nonatomic, strong, readonly) UIView *view;
@property (nonatomic, copy, readonly, nullable) NSArray<BFTween*> *groupedTweens;
@property (nonatomic, copy, readonly) NSString *keyPath;
@property (nonatomic, copy, readonly) BFTweenBlock tween;
@property (nonatomic, assign, readonly) double duration;
@property (nonatomic, assign, readonly) double fromValue;
@property (nonatomic, assign, readonly) double toValue;

@property (nonatomic, assign) BOOL animateOnly;

+ (void)harlemShakeView:(UIView *)view completion:(void(^ __nullable)(void))completion;

+ (NSArray *)keyFrameValuesForFunction:(BFTweenBlock)tween
                             fromValue:(double)fromValue
                               toValue:(double)toValue
                              duration:(double)duration;

@end

@interface CAKeyframeAnimation (Tween)

+ (instancetype)animationWithKeyPath:(NSString *)path
                  function:(BFTweenBlock)tween
                 fromValue:(double)fromValue
                   toValue:(double)toValue
                  duration:(double)duration;

@end

NS_ASSUME_NONNULL_END
