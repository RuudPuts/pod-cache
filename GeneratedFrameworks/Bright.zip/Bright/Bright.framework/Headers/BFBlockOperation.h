#import <Bright/BFOperation.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFBlockOperation : NSObject <BFOperation>

+ (instancetype)operationWithCancelBlock:(void(^ _Nullable)(void))cancelBlock;

@property (nonatomic, assign, getter = isFinished) BOOL finished;

@end

NS_ASSUME_NONNULL_END
