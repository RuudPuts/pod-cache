#import <Bright/BFJihaaPropertyTransformer.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFJihaaObjectPropertyTransformer : BFJihaaPropertyTransformer

- (instancetype)init NS_UNAVAILABLE;

- (instancetype)initForJSONObjectClass:(Class)cls NS_DESIGNATED_INITIALIZER;

@property (nonatomic, readonly) Class jsonObjectClass;

@end

NS_ASSUME_NONNULL_END
