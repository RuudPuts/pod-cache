NS_ASSUME_NONNULL_BEGIN

@interface BFHTTPServiceImplementation (Private)

- (void)modifyRequest:(NSMutableURLRequest *)request;
- (void)modifyOperation:(BFHTTPRequestOperation *)operation;
- (BOOL)handleError:(BFError *)error forHTTPRequestOperation:(BFHTTPRequestOperation *)operation;
- (void)handleResponse:(NSHTTPURLResponse *)response forHTTPRequestOperation:(BFHTTPRequestOperation *)operation;

@end

NS_ASSUME_NONNULL_END
