#import <UIKit/UIKit.h>
#import <Bright/BFView.h>

NS_ASSUME_NONNULL_BEGIN

typedef void(^BFMessageViewCallback)(void);

@interface BFMessageView : BFView

- (void)updateForImage:(nullable UIImage *)image message:(nullable NSString *)message actionTitle:(nullable NSString *)actionTitle callback:(nullable BFMessageViewCallback)callback;

@property (nonatomic, readonly, nullable) UIImage *image;
@property (nonatomic, readonly, nullable) NSString *message;
@property (nonatomic, readonly, nullable) NSString *actionTitle;

@end

NS_ASSUME_NONNULL_END
