#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

#define BFSynthesizeSingleton(getter) \
 \
+ (instancetype)getter { \
	static id singleton = nil; \
	static dispatch_once_t onceToken; \
	dispatch_once(&onceToken, ^{ \
		singleton = [(id)[super alloc] init]; \
	}); \
	return singleton; \
}

#define BFSynthesizeSingletonInterface(getter) \
    + (instancetype)getter; \
    + (instancetype)alloc __attribute__((unavailable("this class is a singleton"))); \
    - (instancetype)init __attribute__((unavailable("this class is a singleton"))); \
    + (instancetype)new __attribute__((unavailable("this class is a singleton"))); \

NS_ASSUME_NONNULL_END
