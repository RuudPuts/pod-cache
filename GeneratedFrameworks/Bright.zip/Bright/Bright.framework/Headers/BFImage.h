#import <Bright/BFOperation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef void(^BFImageRetrievalCompletionBlock)(UIImage * _Nullable image);
typedef id <BFOperation> _Nullable (^BFImageRetrievalBlock)(BFImageRetrievalCompletionBlock completion);

@interface BFImage : NSObject

+ (nullable instancetype)imageWithImage:(nullable UIImage *)image;

+ (nullable instancetype)imageNamed:(NSString *)imageName;

+ (instancetype)imageWithContentsOfFile:(NSString *)path;

+ (instancetype)imageWithContentsAtURL:(NSString *)url;

+ (instancetype)imageWithRetrievalBlock:(BFImageRetrievalBlock)retrievalBlock;

@property (nonatomic, strong, nullable) UIImage *imageValue;

@property (nonatomic, readonly, getter = isLoading) BOOL loading;
- (void)cancelLoading;

@end

NS_ASSUME_NONNULL_END
