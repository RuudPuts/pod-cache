#import <UIKit/UIKit.h>

@interface BFView : UIView

@end
