#import <Bright/BFHTTPRequestOperation.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFJihaaObjectEncoder : NSObject <BFHTTPBodyEncoder>

- (instancetype)init NS_UNAVAILABLE;

+ (instancetype)encoderWithObject:(id)object;
- (instancetype)initWithJSONObject:(id)object NS_DESIGNATED_INITIALIZER;

@property (nonatomic, strong) id jsonObject;
@property (nonatomic, assign) NSJSONWritingOptions writingOptions;

@end

NS_ASSUME_NONNULL_END
