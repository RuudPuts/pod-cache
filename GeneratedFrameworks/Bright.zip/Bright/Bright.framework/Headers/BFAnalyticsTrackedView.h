#import <Bright/BFJihaaObject.h>

NS_ASSUME_NONNULL_BEGIN

BFJihaaDecoration(BFAnalyticsTrackedView);

@interface BFAnalyticsTrackedView : BFJihaaObject

@property (nonatomic, assign) NSTimeInterval timestamp;

@property (nonatomic, copy, nullable) NSString <BFJihaaOptional> *module;
@property (nonatomic, copy, nullable) NSString *identifier;
@property (nonatomic, copy, nullable) NSArray <BFJihaaString, BFJihaaOptional> *arguments;

@end

NS_ASSUME_NONNULL_END
