#import <Bright/Bright.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFURLSettingsDetailsViewController ()

@property (nonatomic, strong, nullable) IBOutlet UIBarButtonItem *cancelButton;
@property (nonatomic, strong, nullable) IBOutlet UIBarButtonItem *saveButton;

@property (nonatomic, weak) IBOutlet BFTextField *inputField;
@property (nonatomic, weak) IBOutlet UIPickerView *pickerView;

- (void)didTapSaveButton;

@end

NS_ASSUME_NONNULL_END
