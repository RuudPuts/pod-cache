#import <Bright/BFURLConnectionOperation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSUInteger, BFURLConnectionOperationState) {
    BFURLConnectionOperationStateInitial,
	BFURLConnectionOperationStateExecuting,
	BFURLConnectionOperationStateProcessing,
	BFURLConnectionOperationStateFinishing,
	BFURLConnectionOperationStateFinished
};

@interface BFURLConnectionOperation ()

@property (nonatomic, assign) BFURLConnectionOperationState state;

@property (nonatomic, strong) NSMutableURLRequest *mutableRequest;

- (void)setOperationError:(NSError *)error;
- (BFError *)errorForOperation:(BFURLConnectionOperation *)operation error:(NSError *)error;

- (void)_log:(NSString *)formatString, ...;

- (void)_performLockedBlock:(void(^)(void))block;
- (void)_performCallback:(void(^)(void))callback;

- (void)_performStartup;
- (void)_processResponse;
- (void)_performCompletion;

@end

NS_ASSUME_NONNULL_END
