NS_ASSUME_NONNULL_BEGIN

@interface BFSettingsHeaderView : UITableViewHeaderFooterView

@property (nonatomic, copy, nullable) NSString *title;
@property (nonatomic, copy, nullable) NSAttributedString *attributedTitle;

@end

NS_ASSUME_NONNULL_END
