#import <Bright/BFJihaaObject.h>

BFJihaaDecoration(BFDemoConfiguration);

@interface BFDemoConfiguration : BFJihaaObject

@property (nonatomic, copy) NSString *title;

@end
