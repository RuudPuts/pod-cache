#import <UIKit/UIKit.h>

typedef NS_ENUM(NSUInteger, UIDeviceModel) {
    UIDeviceModel_Unknown,
    
    UIDeviceModel_iPhoneSimulator,
    UIDeviceModel_iPadSimulator,
    
    UIDeviceModel_iPhone5S,
    UIDeviceModel_iPhoneSE,
    UIDeviceModel_iPhone6,
    UIDeviceModel_iPhone6Plus,
    UIDeviceModel_iPhone6S,
    UIDeviceModel_iPhone6SPlus,
    UIDeviceModel_iPhone7,
    UIDeviceModel_iPhone7Plus,
    UIDeviceModel_iPhone8,
    UIDeviceModel_iPhone8Plus,
    UIDeviceModel_iPhoneX,
    UIDeviceModel_iPhoneXR,
    UIDeviceModel_iPhoneXS,
    UIDeviceModel_iPhoneXSMax,
    UIDeviceModel_iPhone11,
    UIDeviceModel_iPhone11Pro,
    UIDeviceModel_iPhone11ProMax,
    UIDeviceModel_iPhoneSE2ndGen,
    UIDeviceModel_iPhone12Mini,
    UIDeviceModel_iPhone12,
    UIDeviceModel_iPhone12Pro,
    UIDeviceModel_iPhone12ProMax,

    UIDeviceModel_iPodTouch6G,

    UIDeviceModel_iPad2,
    UIDeviceModel_iPad3,
    UIDeviceModel_iPad4,
    UIDeviceModel_iPadAir,
    UIDeviceModel_iPadAir2,

    UIDeviceModel_iPadPro,
    
    UIDeviceModel_iPadMini2,
    UIDeviceModel_iPadMini3,
    UIDeviceModel_iPadMini4
};

@interface UIDevice (BFSpecificModel)

@property (nonatomic, readonly, copy) NSString *specificModel;
@property (nonatomic, readonly) UIDeviceModel specificDeviceModel;

@end
