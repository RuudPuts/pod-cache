#import <Bright/BFJihaaDecoration.h>

@protocol BFJihaaPropertyTransformer;
@class BFJihaaProperty;

NS_ASSUME_NONNULL_BEGIN

extern NSString *const BFJihaaErrorDomain;
extern NSString *const BFJihaaParsingPathUserInfoKey;

typedef NS_ENUM(NSInteger, BFJihaaErrorCode) {
    BFJihaaGenericParsingError,
    BFJihaaParsingInvalidRootObject,
    BFJihaaParsingPropertyTypeValidationError,
    BFJihaaParsingEnumPropertyInvalidValueError,
    BFJihaaParsingRequiredPropertyNilError,
    BFJihaaParsingInvalidKeyPathError,
    BFJihaaParsingRootKeyPathNotFoundError,
    BFJihaaValidationError,
};

@interface BFJihaaObject : NSObject <NSSecureCoding, NSCopying>

+ (Class)classForCopy;
+ (Class)classForMutableCopy;

+ (void)registerTransformer:(id <BFJihaaPropertyTransformer>)transformer forClass:(Class)cls;
+ (id <BFJihaaPropertyTransformer>)transformerForClass:(Class)cls;

+ (BOOL)automaticallyMapUnderscoresToCamelCase;

+ (NSDictionary *)propertyMappings;
+ (NSDictionary<NSString*, id<BFJihaaPropertyTransformer>> *)propertyTransformers;
+ (NSDictionary<NSString*, NSArray<NSString*>*> *)propertyAttributes;

+ (NSArray<NSString*> *)propertiesToDetermineEquality;

- (void)willMigrateFromVersion:(NSInteger)storedVersion;
- (void)decodeProperty:(BFJihaaProperty *)property withCoder:(NSCoder *)coder version:(NSInteger)version;
- (void)didMigrateFromVersion:(NSInteger)storedVersion;

- (void)encodeProperty:(BFJihaaProperty *)property withCoder:(NSCoder *)coder;

- (void)willEncodeObject;
- (void)didEncodeObject;

- (void)willDecodeObject;
- (void)didDecodeObject;

- (BOOL)validateDecodedObject:(NSError **)error;

@end

NS_ASSUME_NONNULL_END
