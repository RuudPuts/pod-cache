#import <Bright/BFMessageView.h>
#import <Bright/BFKeyboardHelper.h>

@class BFError, BFPageViewController;

NS_ASSUME_NONNULL_BEGIN

@protocol BFViewController

@property (nonatomic, readonly, getter = isVisible) BOOL visible;
@property (nonatomic, readonly, getter = isAppearing) BOOL appearing;
@property (nonatomic, readonly, getter = isDisappearing) BOOL disappearing;

@end

@interface BFViewController : UIViewController <BFViewController, BFKeyboardObserver>

///------------------------------------------///
/// @name Appearance Methods
///------------------------------------------///

- (void)viewWillAppear:(BOOL)animated NS_REQUIRES_SUPER;
- (void)viewDidAppear:(BOOL)animated NS_REQUIRES_SUPER;
- (void)viewWillDisappear:(BOOL)animated NS_REQUIRES_SUPER;
- (void)viewDidDisappear:(BOOL)animated NS_REQUIRES_SUPER;

@property (nonatomic, readonly) BOOL shouldPopViewController;

///------------------------------------------///
/// @name Tracking
///------------------------------------------///

- (void)setTrackingModule:(nullable NSString *)module identifier:(nullable NSString *)identifier;
- (void)setTrackingModule:(nullable NSString *)module identifier:(nullable NSString *)identifier arguments:(nullable NSArray *)arguments;

@property (nonatomic, readonly, nullable) NSString *trackingModule;
@property (nonatomic, readonly, nullable) NSString *trackingIdentifier;
@property (nonatomic, readonly, nullable) NSArray *trackingArguments;

+ (void)setTrackWhenEnteringForeground:(BOOL)trackWhenEnteringForeground;
+ (BOOL)trackWhenEnteringForeground;

///------------------------------------------///
/// @name Handling messages and errors
///------------------------------------------///

/**
 Shows a `BFMessageView` with a provided message and image.
 
 @param message The message to show to the user.
 @param icon The image to show in the message view.
 */
- (void)showMessage:(nullable NSString *)message icon:(nullable UIImage *)icon;

/**
 Shows a `BFMessageView` with a provided message, image, title and callback.
 
 @param message The message to show to the user.
 @param icon The image to show in the message view.
 @param actionTitle The title of the button in the message view.
 @param callback The callback block to be executed when the button is clicked.
 */
- (void)showMessage:(nullable NSString *)message icon:(nullable UIImage *)icon actionTitle:(nullable NSString *)actionTitle callback:(nullable BFMessageViewCallback)callback;

/**
 Shows a `BFMessageView` from a BFError. 
 The message that will be displayed is the localized message contained in the BFError object.
 
 @param error The BFError containing all the info about the error.
 */
- (void)showError:(BFError *)error;

/**
 Shows a `BFMessageView` from a BFError. 
 The message that will be displayed is the localized message contained in the BFError object. 
 It will also show a button and handle the click of that with the callback provided.
 
 @param error The BFError containing all the info about the error.
 @param actionTitle The title of the button in the message view.
 @param callback The callback block to be executed when the button is clicked.
 */
- (void)showError:(BFError *)error actionTitle:(nullable NSString *)actionTitle callback:(nullable BFMessageViewCallback)callback;

/**
 Hides the BFMessageView created with the methods above, removing it from the super view.
 */
- (void)hideMessageView;

///------------------------------------------///
/// @name Progress
///------------------------------------------///

@property (nonatomic, assign, getter = isProgressViewVisible) BOOL progressViewVisible;
@property (nonatomic, assign) float progressViewProgress;

///------------------------------------------///
/// @name Managing keyboard overlap
///------------------------------------------///

/**
 The current amount of overlap in points the keyboard has with the view of the view controller.
 */
@property (nonatomic, readonly) CGFloat keyboardOverlap;

@property (nonatomic, weak) UIResponder *responderOnViewWillAppear;

@property (nonatomic, assign) BOOL shouldShowSidebarMenuButton;
- (void)setShouldShowSidebarMenuButton:(BOOL)shouldShowSidebarMenuButton animated:(BOOL)animated;

///------------------------------------------///
/// @name Back Bar Button Without Text
///------------------------------------------///

+ (BOOL)hidesBackBarButtonItemText;
+ (void)setHidesBackBarButtonItemText:(BOOL)hidesBackBarButtonItemText;

///------------------------------------------///
/// @name Horizontal Size Class
///------------------------------------------///

@property (nonatomic, readonly) UIUserInterfaceSizeClass predictedHorizontalSizeClass;

@end

NS_ASSUME_NONNULL_END
