#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSObject (JihaaKeyPath)

- (BOOL)getObject:(_Nullable id * _Nonnull)object forJihaaKey:(id)key error:(NSError **)error;
- (BOOL)getObject:(_Nullable id * _Nonnull)object forJihaaKeyPath:(NSArray *)keyPath error:(NSError **)error;

@end

NS_ASSUME_NONNULL_END
