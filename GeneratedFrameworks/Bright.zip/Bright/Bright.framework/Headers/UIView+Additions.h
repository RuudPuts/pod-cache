#import <objc/objc.h>
#import <Bright/BFCGAddtions.h>

NS_ASSUME_NONNULL_BEGIN

/**
 Category on `UIView` for easily aligning the view in other views using `BFViewAlignment`. This category also specifies some methods to easily alter the frame for the view.
 */
@interface UIView (BFAdditions)

/**
 Sets the `frame` and `autoResizing` values for the `UIView` to align it in another view based on a specific alignment value.
 
 @param view The `UIView` in which to align the current view.
 @param alignment The `BFViewAlignment` value to use for aligning the view.
 @param edgeInsets The edge insets to use for alignment.
 */
- (void)alignInView:(UIView *)view withAlignment:(BFViewAlignment)alignment edgeInsets:(UIEdgeInsets)edgeInsets;
/**
 Sets the `frame` for the `UIView` to align it in another view based on a specific alignment value.
 
 @param view The `UIView` in which to align the current view.
 @param alignment The `BFViewAlignment` value to use for aligning the view.
 @param edgeInsets The edge insets to use for alignment.
 */
- (void)layoutInView:(UIView *)view withAlignment:(BFViewAlignment)alignment edgeInsets:(UIEdgeInsets)edgeInsets;

/**
 Sets the `frame` and `autoResizing` values for the `UIView` to align it in its superview based on a specific alignment value.
 
 @param alignment The `BFViewAlignment` value to use for aligning the view.
 @param edgeInsets The edge insets to use for alignment.
 */
- (void)alignInSuperviewWithAlignment:(BFViewAlignment)alignment edgeInsets:(UIEdgeInsets)edgeInsets;
/**
 Sets the `frame`  values for the `UIView` to align it in its superview based on a specific alignment value.
 
 @param alignment The `BFViewAlignment` value to use for aligning the view.
 @param edgeInsets The edge insets to use for alignment.
 */
- (void)layoutInSuperviewWithAlignment:(BFViewAlignment)alignment edgeInsets:(UIEdgeInsets)edgeInsets;

///------------------------------------------///
/// @name Adding aligned subviews
///------------------------------------------///

/**
 Adds a view to the end of the receiver’s list of subviews and aligns it using a specific alignment value.
 
 @param view The view to be added. This view is retained by the receiver. After being added, this view appears on top of any other subviews.
 @param alignment The `BFViewAlignment` value to use for aligning the view.
 @param edgeInsets The edge insets to use for alignment.
 */
- (void)addSubview:(UIView *)view withAlignment:(BFViewAlignment)alignment edgeInsets:(UIEdgeInsets)edgeInsets;

/**
 Inserts a subview at the specified index and aligns it using a specific alignment value.
 
 @param view The view to insert. This value cannot be nil.
 @param index The index in the array of the subviews property at which to insert the view. Subview indices start at 0 and cannot be greater than the number of subviews.
 @param alignment The `BFViewAlignment` value to use for aligning the view.
 @param edgeInsets The edge insets to use for alignment.
 */
- (void)insertSubview:(UIView *)view atIndex:(NSInteger)index withAlignment:(BFViewAlignment)alignment edgeInsets:(UIEdgeInsets)edgeInsets;

/**
 Inserts a view above another view in the view hierarchy and aligns it using a specific alignment value.
 
 @param view The view to insert. This value cannot be nil.
 @param siblingSubview The sibling view that will be below the inserted view.
 @param alignment The `BFViewAlignment` value to use for aligning the view.
 @param edgeInsets The edge insets to use for alignment.
 */
- (void)insertSubview:(UIView *)view aboveSubview:(UIView *)siblingSubview withAlignment:(BFViewAlignment)alignment edgeInsets:(UIEdgeInsets)edgeInsets;

/**
 Inserts a view below another view in the view hierarchy and aligns it using a specific alignment value.
 
 @param view The view to insert. This value cannot be nil.
 @param siblingSubview The sibling view that will be above the inserted view.
 @param alignment The `BFViewAlignment` value to use for aligning the view.
 @param edgeInsets The edge insets to use for alignment.
 */
- (void)insertSubview:(UIView *)view belowSubview:(UIView *)siblingSubview withAlignment:(BFViewAlignment)alignment edgeInsets:(UIEdgeInsets)edgeInsets;

///------------------------------------------///
/// @name Animations
///------------------------------------------///

- (void)animationBounceFromScale:(CGFloat)fromScale toScale:(CGFloat)toScale bounceScale:(CGFloat)bounceScale completion:(void(^ __nullable)(void))completion;
- (void)animationBounceFromScale:(CGFloat)fromScale toScale:(CGFloat)toScale bounceScale:(CGFloat)bounceScale duration:(NSTimeInterval)duration completion:(void(^ __nullable)(void))completion;

- (void)removeAllAnimations;

///------------------------------------------///
/// @name Predicted Size Class
///------------------------------------------///

@property (nonatomic, readonly) UIUserInterfaceSizeClass predictedHorizontalSizeClass;

///------------------------------------------///
/// @name Floating view
///------------------------------------------///

@property (nonatomic, weak) UIView *floatingSubview;

///------------------------------------------///
/// @name View Hierarchy
///------------------------------------------///

/**
 Enumerates over the whole subview hierarchy for the current view.
 
 @param block Block to call for all subviews. When returning NO from the block, the subview will not be further traversed.
 */
- (void)enumerateAllSubviewsWithBlock:(BOOL (^)(UIView *subview, BOOL *stop))block;

/**
 Get an array with all the subviews recursivly. This also means the subviews of subviews.
 */
@property (nonatomic, readonly, copy) NSArray<UIView *> *allSubviews;

/**
 Get an array with all the subviews recursivly. This also means the subviews of subviews.
 */
- (NSArray *)allSubviewsOfClass:(Class)cls;

- (nullable UIView *)ancestorSharedWithView:(UIView *)otherView;

///------------------------------------------///
/// @name Hit Area
///------------------------------------------///

- (BOOL)pointInside:(CGPoint)point forMinimumHitArea:(CGSize)minimumHitArea insets:(UIEdgeInsets)hitAreaInsets;

@end

NS_ASSUME_NONNULL_END
