#import <Bright/BFModuleConfiguration.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFModuleConfiguration ()

- (void)enumerateModulesUsingBlock:(void(^)(Class implementationClass, Protocol *protocol, NSString * _Nullable itemId, _Nullable BFModuleConfigurationBlock configureBlock))block;

- (void)enumerateDynamicModulesUsingBlock:(void(^)(NSString *title, NSInteger order, BOOL isEnabledByDefault, NSArray<Protocol*> *protocols))block;

@end

NS_ASSUME_NONNULL_END
