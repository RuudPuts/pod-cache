#import <Bright/BFHTTPService.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFHTTPServiceImplementation (Subclass)

- (Class)requestOperationClass;
- (NSMutableURLRequest *)requestWithMethod:(NSString *)method
                                      path:(NSString *)path
                                parameters:(nullable NSDictionary *)parameters;

@end

NS_ASSUME_NONNULL_END
