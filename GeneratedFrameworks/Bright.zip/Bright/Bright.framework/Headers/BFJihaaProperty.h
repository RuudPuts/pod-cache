#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@protocol BFJihaaPropertyTransformer;

@interface BFJihaaProperty : NSObject <NSCopying>

@property (nonatomic, assign) Class cls;

@property (nonatomic, assign, getter = isPrimitive) BOOL primitive;
@property (nonatomic, assign, getter = isBooleanPrimitive) BOOL booleanPrimitive;

@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *mappedTo;

@property (nonatomic, strong, nullable) id <BFJihaaPropertyTransformer> transformer;

@property (nonatomic, assign, getter = isObjcReadonly) BOOL objcReadonly;

@property (nonatomic, copy, nullable) NSSet *attributes;

@property (nonatomic, copy, nullable) NSArray *keyPath;

- (nullable id)propertyValueForObject:(id)object;
- (void)setPropertyValue:(nullable id)value forObject:(id)object;

@property (nonatomic, getter=isReadonly, readonly) BOOL readonly;

@end

NS_ASSUME_NONNULL_END
