#import <UIKit/UIKit.h>
#import "UIDevice+SpecificModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface UIScreen (Sizes)

/*
 Please do not use the following methods, they are not reliable and definitely not future proof. In
 general you should not depend the layout on what kind of phone it is. Try to scale or layout based
 upon sizes or preferably size classes.
 */

@property (nonatomic, getter=isIPhone4Screen, readonly) BOOL IPhone4Screen;
@property (nonatomic, getter=isIPhone5Screen, readonly) BOOL IPhone5Screen;
- (BOOL)deviceModelZoomedIn:(UIDeviceModel)model;

- (CGSize)convertPointsToResolution:(CGSize)size;

@end

NS_ASSUME_NONNULL_END
