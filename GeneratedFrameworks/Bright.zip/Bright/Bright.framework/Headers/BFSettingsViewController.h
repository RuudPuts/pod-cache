#import <Bright/BFSettingsManager.h>
#import <Bright/BFViewController.h>

@class BFSettingsItem;

NS_ASSUME_NONNULL_BEGIN

@interface BFSettingsViewController : BFViewController<UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, weak) id <BFSettingsItemDataSource> dataSource;

@end

NS_ASSUME_NONNULL_END
