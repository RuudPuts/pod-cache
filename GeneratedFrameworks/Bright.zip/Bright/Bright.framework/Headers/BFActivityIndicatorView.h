#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@protocol BFActivityIndicatorView <NSObject>
@optional

- (void)startAnimating;
- (void)stopAnimating;

- (void)setProgress:(float)progress;
- (void)setProgress:(float)progress animated:(BOOL)animated;

@end

@interface UIActivityIndicatorView () <BFActivityIndicatorView>
@end

NS_ASSUME_NONNULL_END
