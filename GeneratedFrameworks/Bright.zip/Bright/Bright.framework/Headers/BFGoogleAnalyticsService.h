#import <Bright/BFAnalyticsService.h>
#import <Bright/BFNumberSettingsItem.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFGoogleAnalyticsServiceImplementation : BFAnalyticsServiceImplementation

/**
 Debug Menu setting for turning analytics events on/off.
 *DISCLAIMER*
 If optOut is NO then it will send tracking information.
 */
@property (nonatomic, strong) BFBoolSettingsItem <BFHiddenSetting> *optOutSettingsItem;

/**
 Interval in seconds between dispatches to the analytics servers. If negative, tracking information must be sent manually by calling dispatch. If zero, tracking information will be sent as soon as possible (usually as soon as there's a connection). Setting the interval to zero from non-zero dispatches any queued data.
 Default value: `120`.
 */
@property (nonatomic, assign) BFNumberSettingsItem <BFHiddenSetting> *dispatchIntervalSettingsItem;

/**
 Enable dispatching when the app moves to the background. This will create a background task for the Google Analytics SDK to dispatch all data for a time period of 10 seconds. Prevents from data getting lost when the users aren't using the app every 24h.
 Will add an observer for `UIApplicationWillResignActiveNotification`.
 */
@property (nonatomic, assign) BOOL enableDispatchWhenAppResignsActive;

/**
 The tracking identifier the analytics instance is associated with. This property can only be set once.
 */
@property (nonatomic, strong, nullable) NSString *trackingId;

/**
 When set to YES debugging information will be printed.
 Default value: False
 */
@property (nonatomic, assign) BOOL debugMode;

/**
 Used to register keys for custom dimensions.
 
 Use the `setTrackingValue:forKey:` method to set the value for a custom dimension registered to the specific key.
 
 @param key The key for the custom dimension.
 @param index The index for the custom dimension.
 */
- (void)registerKey:(NSString *)key forCustomDimensionIndex:(NSInteger)index;

/**
 Used to register checkout steps to be tracked during checkout.
 */
- (void)registerStep:(NSString *)step forCheckoutStepIndex:(NSInteger)index;
/**
 Used to register the event used for checkout steps
 */
- (void)setCheckoutEventWithModule:(nullable NSString *)module category:(nullable NSString *)category option:(nullable NSString *)option;

@end

NS_ASSUME_NONNULL_END
