#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/**
 Dictionary category for retrieving the dictionary as an URL query string.
 */
@interface NSDictionary (BFQueryString)

///------------------------------------------///
/// @name Retrieving an URL query string
///------------------------------------------///

/**
 Creates and returns an URL query string from the dictionary keys and values.
 
 @return The URL query string for this dictionary.
 */
@property (nonatomic, readonly, copy) NSString *URLQueryString;

@end

NS_ASSUME_NONNULL_END
