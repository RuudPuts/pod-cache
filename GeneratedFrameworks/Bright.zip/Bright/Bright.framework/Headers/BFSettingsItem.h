#import <Foundation/Foundation.h>

@protocol BFViewController;
@class BFViewController, BFSettingsViewController, BFSettingsSection, BFGroupSettingsItem, BFSettingsCell;

NS_ASSUME_NONNULL_BEGIN

@interface BFSettingsItem : NSObject

///------------------------------------------///
/// @name Setup
///------------------------------------------///

+ (NSArray<__kindof BFSettingsItem*> *)setupSettingsForObject:(id)object;

///------------------------------------------///
/// @name UUID
///------------------------------------------///

@property (nonatomic, readonly) NSString *UUID;

///------------------------------------------///
/// @name Configure the settings item
///------------------------------------------///

@property (nonatomic, strong, nullable) BFSettingsSection *section;

// Set a title or titleKey: title is set directly. titleKey is a reference to a localized string and will thus be updated when the strings file changes.
@property (nonatomic, copy, nullable) NSString *title;
@property (nonatomic, copy, nullable) NSString *titleKey;

@property (nonatomic, assign) NSInteger order;
@property (nonatomic, weak) BFGroupSettingsItem *groupItem;

@property (nonatomic, copy, nullable) NSString *settingsId;
@property (nonatomic, copy, nullable) NSString *key;

@property (nonatomic, assign, getter = isEnabled) BOOL enabled;
@property (nonatomic, assign, getter = isVisible) BOOL visible;

@property (nonatomic, strong, nullable) id defaultValue;

///------------------------------------------///
/// @name Retrieving the current value
///------------------------------------------///

@property (nonatomic, strong, nullable) id currentValue;

- (void)setValueFromString:(NSString *)stringValue;

///------------------------------------------///
/// @name Title / Description
///------------------------------------------///

- (nullable NSString *)titleForValue:(nullable id)value defaultTitle:(nullable NSString *)defaultTitle;
- (nullable NSString *)descriptionForValue:(nullable id)value;

///------------------------------------------///
/// @name Compare
///------------------------------------------///

- (NSComparisonResult)compare:(BFSettingsItem *)item;

///------------------------------------------///
/// @name Migration
///------------------------------------------///

@property (nonatomic, copy, nullable) NSArray<NSString *> *migrationUUIDs;

@end

@protocol BFStaticSetting
@end

@protocol BFHiddenSetting
@end

#ifdef DEBUG
#define BFDebugSetting NSObject
#else
#define BFDebugSetting BFHiddenSetting
#endif

NS_ASSUME_NONNULL_END
