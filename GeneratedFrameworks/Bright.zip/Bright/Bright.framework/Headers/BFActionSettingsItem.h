#import <Bright/BFSettingsItem.h>

NS_ASSUME_NONNULL_BEGIN

typedef void(^BFActionSettingsItemBlock)(void);

@interface BFActionSettingsItem : BFSettingsItem

- (void)setActionBlock:(nullable BFActionSettingsItemBlock)block;

@property (nonatomic, readonly) BOOL canPerformAction;
- (void)performAction;

@end

NS_ASSUME_NONNULL_END
