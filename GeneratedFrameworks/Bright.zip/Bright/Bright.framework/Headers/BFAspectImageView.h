#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFAspectImageView : UIImageView

@property (nonatomic, assign, getter=isAspectRatioConstraintEnabled) IBInspectable BOOL aspectRatioConstraintEnabled;
@property (nonatomic, assign) UILayoutPriority aspectRatioConstraintPriority;

@end

NS_ASSUME_NONNULL_END
