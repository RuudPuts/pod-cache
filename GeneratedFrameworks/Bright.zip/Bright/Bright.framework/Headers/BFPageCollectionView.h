#import "BFPageCollectionViewLayout.h"

@class BFPageCollectionView;

NS_ASSUME_NONNULL_BEGIN

@protocol BFPageCollectionViewDelegate <UICollectionViewDelegate>
@optional

- (void)pageCollectionView:(BFPageCollectionView *)view didChangeToPageAtIndex:(nullable NSNumber *)pageIndex;

@end

@interface BFPageCollectionView : UICollectionView

@property (nonatomic, strong) BFPageCollectionViewLayout *collectionViewLayout;

@property (nonatomic, weak) IBOutlet UIPageControl *pageControl;

@property (nonatomic, readonly) NSUInteger numberOfPages;

@property (nonatomic, strong, nullable) NSNumber *currentPage;
- (void)setCurrentPage:(nullable NSNumber *)pageIndex animated:(BOOL)animated;

@property (nonatomic, assign) IBInspectable BOOL updateCurrentPageOnWillEndDragging;

@property (nonatomic, weak) id <BFPageCollectionViewDelegate> delegate;

@end

@interface BFPageCollectionViewLayout ()

@property (nonatomic, readonly) BFPageCollectionView *collectionView;

@end

NS_ASSUME_NONNULL_END
