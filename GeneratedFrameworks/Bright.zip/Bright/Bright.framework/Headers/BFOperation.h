#import <Foundation/Foundation.h>

@class BFError;

NS_ASSUME_NONNULL_BEGIN

@protocol BFOperation <NSObject>

@property (nonatomic, getter=isExecuting, readonly) BOOL executing;
@property (nonatomic, getter=isFinished, readonly) BOOL finished;
@property (nonatomic, getter=isReady, readonly) BOOL ready;

@property (nonatomic, getter=isCancelled, readonly) BOOL cancelled;
- (void)cancel;

@end

typedef void(^BFOperationSuccessHandler)(void);
typedef void(^BFOperationDataSuccessHandler)(_Nullable id data);
typedef void(^BFOperationFailureHandler)(BFError *error);
typedef void(^BFOperationProgressHandler)(NSInteger bytes, NSInteger totalBytes, long long totalBytesExpected);

NS_ASSUME_NONNULL_END
