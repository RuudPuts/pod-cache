#import <Bright/BFService.h>

NS_ASSUME_NONNULL_BEGIN

/**
 *  BFUUIDService is a service that provides an alphanumeric string that uniquely identifies a device to the app’s vendor.
 */

@protocol BFUUIDService <BFServiceInterface>

@property (nonatomic, readonly) NSString *UUID;

@end

@interface BFUUIDServiceImplementation : BFService <BFUUIDService>

@end

NS_ASSUME_NONNULL_END
