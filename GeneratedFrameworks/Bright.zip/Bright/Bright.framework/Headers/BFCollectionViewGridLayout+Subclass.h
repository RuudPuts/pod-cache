#import <Bright/BFCollectionViewGridLayout.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFCollectionViewGridLayout ()

@property (nonatomic, readonly, nullable) NSArray<NSNumber*> *sectionHeights;
@property (nonatomic, readonly, nullable) NSArray<NSNumber*> *sectionRowCounts;
@property (nonatomic, readonly, nullable) NSArray<NSNumber*> *sectionColumnCounts;

- (BFCollectionViewSectionProperties *)actualPropertiesForSection:(NSUInteger)section;

- (CGFloat)offsetForSection:(NSInteger)section;

- (void)updateLayoutAttributes:(UICollectionViewLayoutAttributes *)attributes forItemAtIndexPath:(NSIndexPath *)indexPath;
- (void)updateLayoutAttributes:(UICollectionViewLayoutAttributes *)attributes forSupplementaryViewOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath;
- (void)updateLayoutAttributes:(UICollectionViewLayoutAttributes *)attributes forDecorationViewOfKind:(NSString *)decorationViewKind atIndexPath:(NSIndexPath *)indexPath;

@end

NS_ASSUME_NONNULL_END
