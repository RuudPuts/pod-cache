#import <Bright/BFService.h>
#import <Bright/BFActionSettingsItem.h>
#import <Bright/BFBoolSettingsItem.h>

NS_ASSUME_NONNULL_BEGIN

@protocol BFDemoHTTPHandler;
@class BFDemoConfiguration;

@protocol BFDemoService <BFServiceInterface>

@property (nonatomic, readonly, getter = isEnabled) BOOL enabled;

- (void)registerHTTPHandler:(id <BFDemoHTTPHandler>)handler;
- (void)unregisterHTTPHandler:(id <BFDemoHTTPHandler>)handler;

- (nullable NSData *)demoDataForKey:(NSString *)key;

- (void)simulatePushNotificationWithText:(nullable NSString *)text data:(nullable NSDictionary *)data;
- (void)simulatePushNotificationWithText:(nullable NSString *)text data:(nullable NSDictionary *)data afterInterval:(NSTimeInterval)interval;

@end

@protocol BFDemoServiceObserver <BFServiceObserver>
@optional

- (void)demoServiceDidChangeEnabledState:(id <BFDemoService>)service;

@end

@interface BFDemoServiceImplementation : BFService <BFDemoService>

@property (nonatomic, strong) BFBoolSettingsItem <BFHiddenSetting> *enabledSetting;
@property (nonatomic, strong) BFBoolSettingsItem <BFHiddenSetting> *recordRequestsSetting;

@property (nonatomic, strong) BFBoolSettingsItem <BFHiddenSetting> *slowResponseSetting;

@property (nonatomic, strong) BFBoolSettingsItem <BFHiddenSetting> *showErrorWhenDemoNotImplementedSetting;

@property (nonatomic, strong) BFActionSettingsItem <BFHiddenSetting> *simulatePushNotificationSetting;

@property (nonatomic, copy, nullable) NSArray *excludedHosts;

@property (nonatomic, copy, nullable) NSString *dropboxDemoDataConfigurationsPath;

@end

@protocol BFDemoHTTPHandler <NSObject>

- (BOOL)canHandleRequest:(NSURLRequest *)request;

@optional

- (NSInteger)demoStatusCodeForRequest:(NSURLRequest *)request;

- (nullable NSDictionary *)demoHeadersForRequest:(NSURLRequest *)request;
- (nullable NSData *)demoDataForRequest:(NSURLRequest *)request;

- (void)performDemoRequest:(NSURLRequest *)request responseBlock:(void(^)(NSInteger statusCode, NSDictionary *responseHeaders))responseBlock completionBlock:(void(^)(NSData *responseData))completionBlock;

@end

NS_ASSUME_NONNULL_END
