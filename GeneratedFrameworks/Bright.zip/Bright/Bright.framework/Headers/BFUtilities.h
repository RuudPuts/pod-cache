#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@class Protocol;

/**
 Checks whether a procotol contains a certain instance method.
 
 @param protocol The protocol to check.
 @param aSelector The selector for the instance method to check.
 @return `YES` if the protocol contains the selector, `NO` otherwise.
 */
extern BOOL protocolContainsInstanceMethod(Protocol *protocol, SEL aSelector);

/**
 Checks whether a procotol contains a certain instance method.
 
 @param protocol The protocol to check.
 @param aSelector The selector for the instance method to check.
 @param required If the protocol contains the instance method, this boolean will indicate whether the method is a required method.
 @return `YES` if the protocol contains the selector, `NO` otherwise.
 */
extern BOOL protocolContainsInstanceMethodRequired(Protocol *protocol, SEL aSelector,  BOOL * _Nullable required);

extern NSTimeInterval getBootReferenceTime(void);

/**
 Swaps the implementations of two instance methods of a given class by using `method_exchangeImplementations`.
 
 Take extreme care when using this method and only use it when absolutely necessary. This will change methods everywhere this class is used, even in Apple's frameworks.
 
 @param c The class to swap methods for.
 @param sel1 The selector of the first method to swap.
 @param sel2 The selector of the second method to swap.
 */
extern void swapInstanceMethods(Class c, SEL sel1, SEL sel2);

/**
 Swaps the implementations of two class methods of a given class by using `method_exchangeImplementations`.
 
 Take extreme care when using this method and only use it when absolutely necessary. This will change methods everywhere this class is used, even in Apple's frameworks.
 
 @param c The class to swap methods for.
 @param sel1 The selector of the first method to swap.
 @param sel2 The selector of the second method to swap.
 */
extern void swapClassMethods(Class c, SEL sel1, SEL sel2);

extern void dumpProtocol(Protocol *p);

/**
 Prints out class methods, instance methods and ivars from a given class.
 
 @param c The class to dump.
 */
extern void dumpClass(Class c);

NS_ASSUME_NONNULL_END
