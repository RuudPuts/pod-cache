#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef void(^BFActionSheetCompletionHandler)(NSInteger buttonIndex, BOOL cancelled);

NS_CLASS_DEPRECATED_IOS(2_0, 8_3)
@interface BFActionSheet : UIActionSheet

+ (void)dismissAllActiveActionSheetsAnimated:(BOOL)animated;

- (void)showFromToolbar:(UIToolbar *)view completion:(nullable BFActionSheetCompletionHandler)completion;
- (void)showFromTabBar:(UITabBar *)view completion:(nullable BFActionSheetCompletionHandler)completion;
- (void)showFromBarButtonItem:(UIBarButtonItem *)item animated:(BOOL)animated completion:(nullable BFActionSheetCompletionHandler)completion;
- (void)showFromRect:(CGRect)rect inView:(UIView *)view animated:(BOOL)animated completion:(nullable BFActionSheetCompletionHandler)completion;
- (void)showInView:(UIView *)view completion:(nullable BFActionSheetCompletionHandler)completion;

@end

NS_ASSUME_NONNULL_END
