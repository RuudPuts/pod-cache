#import <Bright/BFHTTPRequestOperation.h>

@class BFError;

NS_ASSUME_NONNULL_BEGIN

@interface BFJSONDecoder : NSObject <BFHTTPRequestResponseDecoder>

+ (instancetype)decoder;

@end

NS_ASSUME_NONNULL_END
