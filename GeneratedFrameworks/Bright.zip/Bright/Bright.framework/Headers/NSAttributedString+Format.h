#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSAttributedString (Format)

+ (instancetype)stringWithDefaultAttributes:(NSDictionary *)defaultAttributes format:(NSString *)format, ...;

@end

NS_ASSUME_NONNULL_END
