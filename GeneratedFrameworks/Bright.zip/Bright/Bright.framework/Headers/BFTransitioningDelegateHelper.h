#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/**
 This class is used to circumvent retain cycles when setting self as transitioningDelegate
 */
@interface BFTransitioningDelegateHelper : NSObject <UIViewControllerTransitioningDelegate>

+ (instancetype)helperWithDelegate:(id <UIViewControllerTransitioningDelegate>)delegate;

@property (nonatomic, weak, readonly) id <UIViewControllerTransitioningDelegate> transitioningDelegate;

@end

NS_ASSUME_NONNULL_END
