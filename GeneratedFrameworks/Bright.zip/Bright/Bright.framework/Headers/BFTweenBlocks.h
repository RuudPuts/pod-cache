typedef double (^BFTweenBlock)(double time);

extern const BFTweenBlock BFTweenNone;
extern const BFTweenBlock BFTweenEaseInQuad;
extern const BFTweenBlock BFTweenEaseOutQuad;
extern const BFTweenBlock BFTweenEaseInOutQuad;
extern const BFTweenBlock BFTweenEaseOutQuint;
extern const BFTweenBlock BFTweenEaseInExpo;
extern const BFTweenBlock BFTweenEaseOutExpo;
extern const BFTweenBlock BFTweenEaseInOutExpo;
extern const BFTweenBlock BFTweenEaseOutElastic;
extern const BFTweenBlock BFTweenEaseOutBounce;
extern const BFTweenBlock BFTweenEaseInBack;
extern const BFTweenBlock BFTweenEaseOutBack;
extern const BFTweenBlock BFTweenEaseInOutBack;

extern BFTweenBlock tweenBlockFromBezierCurve(double y1, double y2);
extern BFTweenBlock tweenBlockForSpringAnimation(double damping, double mass, double stiffness, double velocity);
