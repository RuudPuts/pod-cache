#import <Bright/BFJihaaPropertyTransformer.h>

NS_ASSUME_NONNULL_BEGIN

typedef id _Nullable (^BFJihaaTransformBlock)(id object, NSArray *path, id parentObject, NSError **error);

@interface BFJihaaBlockPropertyTransformer : BFJihaaPropertyTransformer

- (instancetype)init NS_UNAVAILABLE;

+ (instancetype)transformerWithValueClass:(Class)valueClass jsonValueClass:(Class)jsonValueClass encodeBlock:(BFJihaaTransformBlock)encodeBlock decodeBlock:(BFJihaaTransformBlock)decodeBlock;

@end

NS_ASSUME_NONNULL_END
