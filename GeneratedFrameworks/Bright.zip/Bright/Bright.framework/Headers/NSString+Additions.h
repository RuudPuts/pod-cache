#import <Foundation/Foundation.h>

/**
 These macros allow for the stringification of preprocessor string values.
 */
#define STRINGIZE_HELPER(x) #x

/**
 Due to a limitation in the preprocessor flow we need to wrap the helper in another macro.
 */
#define STRINGIZE(x) @STRINGIZE_HELPER(x)

NS_ASSUME_NONNULL_BEGIN

/**
 This category adds frequently used string methods to `NSString`.
 */
@interface NSString (BFAdditions)

///------------------------------------------///
/// @name Validating string contents
///------------------------------------------///

/**
 Checks whether the string contains only characters from another string.
 
 @param string The string containing the allowed characters.
 @return `YES` if this string only contains characters from `string`, `NO` otherwise.
 */
- (BOOL)containsOnlyCharactersFromString:(NSString *)string;

/**
 Checks whether the string is equal to the other string supplied ignoring 
 case-sensitivity.
 
 @param string The string with which it will be compared
 @return `YES` if the strings are equal ignoring case-sensitivity, `NO` otherwise.
 */
- (BOOL)isEqualToStringIgnoringCase:(NSString *)string;

///------------------------------------------///
/// @name Altering string contents
///------------------------------------------///

/**
 Returns a new string by removing all characters that do not exist in a given string.
 
 @param string The string containing the allowed characters which will be kept.
 @return The string with all characters not in `string` removed.
 */
- (NSString *)stringByRemovingAllCharactersNotInString:(NSString *)string;

/**
 Returns a new string by removing all non digits.

 @return The string with all non digits removed.
 */
- (NSString *)trimmedNonDigits;

/**
 Returns a new string by removing all characters that from a given string.
 
 @param string The string containing the characters which will be removed.
 @return The string with all characters in `string` removed.
 */
- (NSString *)stringByRemovingAllCharactersInString:(NSString *)string;

@property (nonatomic, readonly, copy) NSString *stringByDecodingHTMLEntities;
@property (nonatomic, readonly, copy) NSString *stringByStrippingHTMLTags;

/**
 Returns a new string by trimming whitespace and newline characters.
 
 @return The string with all whitespace and newline characters trimmed.
 */
- (NSString *)trim;

/**
 Returns a new string by trimming whitespace and newline characters from the end of the string.
 
 @return The string with all whitespace and newline characters trimmed from the end.
 */
- (NSString *)trimTrailingWhitespace;

/**
 Returns a new string by trimming whitespace and newline characters from the start of the string.
 
 @return The string with all whitespace and newline characters trimmed from the start.
 */
- (NSString *)trimLeadingWhitespace;

- (NSString *)stringByTrimmingToMaximumLength:(NSUInteger)maxLength;

- (NSString *)safeSubstringWithinRange:(NSRange)range;

///------------------------------------------///
/// @name Managing URLs
///------------------------------------------///

/**
 Creates a dictionary from the keys and values of a URL query string.
 
 @return Dictionary contains the keys and values from this URL query string.
 */
- (NSDictionary *)dictionaryFromURLQuery;

/**
 Creates an array from the keys and values of a URL query string.
 
 Each array entry is an `NSDictionary` object containing values for "key" and "value" keys.
 
 @return Array containing the key and value pairs from this URL query string.
 */
@property (nonatomic, readonly, copy) NSArray *keyValuePairsFromURLQuery;

@property (nonatomic, readonly, nullable) NSString *URLPathEncodedString;
@property (nonatomic, readonly, nullable) NSString *URLQueryEncodedString;
@property (nonatomic, readonly, nullable) NSString *URLQueryKeyValueEncodedString;
@property (nonatomic, readonly, nullable) NSString *URLDecodedString;

///------------------------------------------///
/// @name HTML
///------------------------------------------///

@property (nonatomic, readonly, copy) NSString *htmlEncodedString;

///------------------------------------------///
/// @name Encoding and decoding hex
///------------------------------------------///

/**
 Decodes a hex string into an `NSData` object.
 
 @return The decoded hex data.
 */
- (nullable NSData *)decodeHexData;

/**
 Decodes a hex string into an `unsigned int` value.
 
 @return The decoded hex value.
 */
- (unsigned int)decodeHexInt;

/**
 Decodes a hex string into an `unsigned long long` value.
 
 @return The decoded hex value.
 */
- (unsigned long long)decodeHexLongLong;

/**
 Decodes a hex string into an `float` value.
 
 @return The decoded hex value.
 */
- (float)decodeHexFloat;

/**
 Decodes a hex string into an `double` value.
 
 @return The decoded hex value.
 */
- (double)decodeHexDouble;

///------------------------------------------///
/// @name Creating a hash
///------------------------------------------///

/**
 Returns the MD5 hash for the current string.
 
 @return The MD5 hash.
 */
@property (nonatomic, readonly, nullable) NSString *BFMD5String;

/**
 Returns the SHA1 hash for the current string.
 
 @return The SHA1 hash.
 */
@property (nonatomic, readonly, nullable) NSString *BFSHA1String;

@end

NS_ASSUME_NONNULL_END
