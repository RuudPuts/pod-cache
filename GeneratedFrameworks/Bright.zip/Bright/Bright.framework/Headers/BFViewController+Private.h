#import "BFViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface BFViewController ()

@property (nonatomic, readonly, nullable) BFPageViewController *BFPageViewControllerOrNilIfNotVisible;

@end

NS_ASSUME_NONNULL_END
