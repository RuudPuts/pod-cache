#import <Bright/BFService.h>
#import <Bright/BFModuleCenter.h>
#import <Bright/BFBoolSettingsItem.h>

NS_ASSUME_NONNULL_BEGIN

extern NSString *const BFAnalyticsServiceDidTrackViewNotification;
extern NSString *const BFAnalyticsServiceDidTrackEventNotification;
extern NSString *const BFAnalyticsServiceTrackedObjectUserInfoKey;

@protocol BFAnalyticsService <BFServiceInterface>

- (void)trackViewForModule:(nullable NSString *)module withIdentifier:(nullable NSString *)identifier arguments:(nullable NSArray *)arguments;

- (void)trackEventForModule:(nullable NSString *)module withCategory:(nullable NSString *)category action:(nullable NSString *)action label:(nullable id)label value:(nullable NSNumber *)value;

- (void)setTrackingValue:(nullable id)value forKey:(NSString *)key;
- (void)removeTrackingValueForKey:(nullable NSString *)key;

- (void)trackEcommerceCheckoutStepBegin:(NSString *)step;

- (void)trackEcommerceCheckoutStepEnd:(NSString *)step option:(nullable NSString *)option;

- (void)trackEcommerceTransactionForModule:(nullable NSString *)module withTransactionID:(NSString *)transactionID affiliation:(nullable NSString *)affiliation revenue:(nullable NSNumber *)revenue tax:(nullable NSNumber *)tax shipping:(nullable NSNumber *)shipping;

- (void)trackEcommerceProductTransactionForModule:(nullable NSString *)module withTransactionID:(NSString *)transactionID affiliation:(nullable NSString *)affiliation productID:(nullable NSString *)productID productName:(nullable NSString *)productName price:(nullable NSNumber *)price quantity:(nullable NSNumber *)quantity;

@end

@interface BFAnalyticsServiceImplementation : BFService <BFAnalyticsService>
- (nullable NSString *)analyticsStringForLabel:(nullable NSString *)labelIdentifier;
- (nullable NSString *)analyticsStringForViewIdentifier:(NSString *)identifier module:(nullable NSString *)module;
- (nullable NSString *)analyticsStringForEventCategory:(nullable NSString *)category module:(nullable NSString *)module;
- (nullable NSString *)analyticsStringForEventAction:(NSString *)action module:(nullable NSString *)module;
- (nullable NSString *)analyticsStringForEcommerceIdentifier:(NSString *)identifier module:(nullable NSString *)module;

@end

#define BFAnalyticsTrackView(module, theIdentifier, theArguments) [[[BFModuleCenter sharedCenter] moduleForProtocol:@protocol(BFAnalyticsService)] trackViewForModule:(module) withIdentifier:(theIdentifier) arguments:(theArguments)]
#define BFAnalyticsTrackEvent(module, category, theAction, theLabel, theValue) [[[BFModuleCenter sharedCenter] moduleForProtocol:@protocol(BFAnalyticsService)]  trackEventForModule:(module) withCategory:(category) action:(theAction) label:(theLabel) value:(theValue)]
#define BFAnalyticsSetTrackingValueForKey(value, key) [[[BFModuleCenter sharedCenter] moduleForProtocol:@protocol(BFAnalyticsService)] setTrackingValue:(value) forKey:(key)]
#define BFAnalyticsRemoveTrackingValueForKey(key) [[[BFModuleCenter sharedCenter] moduleForProtocol:@protocol(BFAnalyticsService)] removeTrackingValueForKey:(key)]
#define BFAnalyticsBeginCheckoutStep(theStep) [[[BFModuleCenter sharedCenter] moduleForProtocol:@protocol(BFAnalyticsService)] trackEcommerceCheckoutStepBegin:(theStep)]
#define BFAnalyticsEndCheckoutStep(theStep, theOption) [[[BFModuleCenter sharedCenter] moduleForProtocol:@protocol(BFAnalyticsService)] trackEcommerceCheckoutStepEnd:(theStep) option:(theOption)]

NS_ASSUME_NONNULL_END
