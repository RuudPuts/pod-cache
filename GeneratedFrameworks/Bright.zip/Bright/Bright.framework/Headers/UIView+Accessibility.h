#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIView (Accessibility)

- (void)setAccessibilityIdentifierAndLabelWithString:(nullable NSString *)string;

@end

@interface UIBarButtonItem (Accessibility)

- (void)setAccessibilityIdentifierAndLabelWithString:(nullable NSString *)string;

@end

NS_ASSUME_NONNULL_END
