#import "BFModule.h"

NS_ASSUME_NONNULL_BEGIN

@interface BFModuleProxy : NSObject

- (instancetype)init NS_UNAVAILABLE;

- (instancetype)initWithTarget:(BFModule *)target;

@property (nonatomic, strong) BFModule *proxyTarget;

@end

NS_ASSUME_NONNULL_END
