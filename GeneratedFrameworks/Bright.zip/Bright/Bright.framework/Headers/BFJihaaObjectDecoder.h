#import <Bright/BFJSONDecoder.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSUInteger, BFJihaaObjectDecoderType) {
    BFJihaaObjectDecoderTypeObject,
    BFJihaaObjectDecoderTypeArray,
};

extern NSString *const BFJihaaObjectDecoderErrorDomain;
extern NSInteger const BFJihaaObjectDecoderEmptyArrayDecodeErrorCode;

@interface BFJihaaObjectDecoder : BFJSONDecoder

- (instancetype)init NS_UNAVAILABLE;

- (instancetype)initForJihaaClass:(Class)cls type:(BFJihaaObjectDecoderType)type withRootKeyPath:(nullable NSArray *)rootKeyPath attributes:(nullable NSSet *)attributes NS_DESIGNATED_INITIALIZER;

@property (nonatomic, readonly) Class jihaaClass;
@property (nonatomic, readonly) BFJihaaObjectDecoderType type;
@property (nonatomic, readonly, nullable) NSArray *rootKeyPath;
@property (nonatomic, readonly, nullable) NSSet<NSString*> *attributes;

@property (nonatomic, assign) BOOL rootObjectIsOptional;

@end

NS_ASSUME_NONNULL_END
