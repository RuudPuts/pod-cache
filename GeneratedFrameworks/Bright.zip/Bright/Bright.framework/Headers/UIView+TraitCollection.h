#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

NS_CLASS_DEPRECATED_IOS(7_0, 8_0)
@interface BFUITraitCollection : UITraitCollection
@end

/**
 Backwards compatibility for UITraitCollection methods on UIView and UIViewController for iOS 7
 */
@interface UIView (BFTraitCollectionBackwardsCompatibility)

@property (readonly, strong) BFUITraitCollection *BFTraitCollection NS_DEPRECATED_IOS(7.0, 8.0);

@end

@interface UIViewController (BFTraitCollectionBackwardsCompatibility)

@property (readonly, strong) BFUITraitCollection *BFTraitCollection NS_DEPRECATED_IOS(7.0, 8.0);

@end

NS_ASSUME_NONNULL_END
