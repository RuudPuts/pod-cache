#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFTextView : UITextView

- (void)setFont:(nullable UIFont *)font compactSize:(CGFloat)compactSize regularSize:(CGFloat)regularSize;
@property (nonatomic, readonly) CGFloat compactFontSize;
@property (nonatomic, readonly) CGFloat regularFontSize;
- (void)resetSizeClassFontSizes;

@end

NS_ASSUME_NONNULL_END
