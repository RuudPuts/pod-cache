#import "BFImage.h"

NS_ASSUME_NONNULL_BEGIN

@interface BFImageView : UIView

@property (nonatomic, strong, nullable) BFImage *image;
- (void)setImage:(nullable BFImage *)image animated:(BOOL)animated;

@property (nonatomic, assign) IBInspectable BOOL shouldAnimateImageChanges;
@property (nonatomic, assign) UIViewContentMode placeholderImageContentMode;

@property (nonatomic, strong, nullable) IBInspectable UIImage *placeholderImage;
@property (nonatomic, strong, nullable) IBInspectable UIImage *placeholderHighlightedImage;

@property (nonatomic, assign) IBInspectable BOOL automaticallyHidesWithoutImage;

@end

NS_ASSUME_NONNULL_END
