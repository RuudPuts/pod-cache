#import <Bright/BFArrayDataViewController.h>
#import <Bright/BFDataViewController+Subclass.h>
#import <Bright/BFCollectionView.h>
#import <Bright/BFLoadMoreControl.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, BFArrayDataViewControllerLoadMoreOffsetType) {
    BFArrayDataViewControllerLoadMoreOffsetTypeObjectIndex,
    BFArrayDataViewControllerLoadMoreOffsetTypePageIndex,
};

/**
 The private interface which can be used by subclasses of the `BFArrayDataViewController`.
 */
@interface BFArrayDataViewController () <UITableViewDataSource, UITableViewDelegate, UICollectionViewDataSource, UICollectionViewDelegate, UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, readonly) NSMutableArray *mutableData;

- (void)updateViewForDataChangeAndKeepSelectedItems;
- (void)updateViewForDataChangeAndKeepSelectedItemsWithBlock:(void(^__nullable)(void))block;

///------------------------------------------///
/// @name Retrieving the data
///------------------------------------------///

/**
 This is the same method as `retrieveDataWithSuccess:failure:` in `BFDataViewController`, with the exception that the success block returns an `NSArray`.
 
 When the view controller supports load more, by setting the `canLoadMore` property to `YES`, it should overwrite `retrieveDataWithOffset:success:failure:` instead of this one.
 
 @param success The success block. The data parameter will be used to update the `data` property with.
 @param failure The failure block which should be called in case of an error during retrieval.
 @return The `BFOperation` allowing to cancel the retrieval, can be `nil` if the operation can not be cancelled.
 @see retrieveDataWithOffset:success:failure:
 */
- (nullable id <BFOperation>)retrieveDataWithSuccess:(void(^__nullable)(NSArray *data))success failure:(void(^__nullable)(BFError *error))failure;

///------------------------------------------///
/// @name Configuration
///------------------------------------------///

/**
 Called when the array data view controller will flash the content's scroll indicators.
 
 This method should not be called directly, but can be overwritten to change the behavior of flashing scroll indicators.
 
 @return `YES` if the scroll indicators should be flashed, `NO` otherwise.
 */
@property (nonatomic, readonly) BOOL shouldFlashScrollIndicators;

@property (nonatomic, readonly) BOOL shouldClearSelectionOnViewWillAppear;

@property (nonatomic, readonly) BOOL shouldEnableScrollsToTop;

///------------------------------------------///
/// @name Sectioning
///------------------------------------------///

@property (nonatomic, assign) BOOL hasSections;

@property (nonatomic, readonly, copy, nullable) NSString *automaticSectionKeyPath;
- (void)addRetrievedSectionData:(NSArray *)data toArray:(NSMutableArray *)existingData;
- (void)prependRetrievedSectionData:(NSArray *)data toArray:(NSMutableArray *)existingData;

@property (nonatomic, readonly) NSUInteger numberOfSections;
- (NSUInteger)numberOfItemsInSection:(NSUInteger)section;

///------------------------------------------///
/// @name Empty state handling
///------------------------------------------///

/**
 Indicates whether the empty state should be shown after the data was retrieved.
 
 @return YES if the empty state should be displayed, NO otherwise.
 */
@property (nonatomic, readonly) BOOL shouldDisplayEmptyState;

- (void)showEmptyState;
- (void)hideEmptyState;

/**
 Icon shown in the message view when the `data` property is an empty array.
 
 The empty view is shown when the data was loaded successfully, but consists of an empty array.
 
 @return The icon for the empty view.
 */
@property (nonatomic, readonly, strong, nullable) UIImage *iconForEmptyState;

/**
 Message shown in the message view when the `data` property is an empty array.
 
 The empty view is shown when the data was loaded successfully, but consists of an empty array.
 
 @return The message for the empty view.
 */
@property (nonatomic, readonly, copy, nullable) NSString *messageForEmptyState;

/**
 The title for the retry button shown in the message view when the `data` property is an empty array.
 
 When returning `nil` from this method, the retry button will be hidden.
 
 The empty view is shown when the data was loaded successfully, but consists of an empty array.
 
 @return The retry button title for the empty view or `nil` if the button should be hidden.
 */
@property (nonatomic, readonly, copy, nullable) NSString *retryActionTitleForEmptyState;

/**
 The action callback for the retry button shown in the message view when the `data` property is an empty array.
 
 When returning `NULL` from this method, the retry button will be hidden.
 
 The empty view is shown when the data was loaded successfully, but consists of an empty array.
 
 @return The retry button action callback for the empty view or `NULL` if the button should be hidden.
 */
@property (nonatomic, readonly, copy, nullable) BFMessageViewCallback retryActionCallbackForEmptyState;

///------------------------------------------///
/// @name Loading more data
///------------------------------------------///

@property (nonatomic, strong, null_unspecified) IBOutlet BFLoadMoreControl *loadMoreControl;

/**
 Setting this property to `YES` enables load more.
 
 Currently load more is only supported when the `displayType` is set to `BFArrayDataViewControllerDisplayTypeTableView`.
 
 When setting this property to `YES`, be sure to implement the `retrieveDataWithOffset:success:failure:` method.
 */
@property (nonatomic, assign) BOOL canLoadMore;
@property (nonatomic, assign) BOOL hasReachedLoadMoreEnd;

@property (nonatomic, assign) BFArrayDataViewControllerLoadMoreOffsetType loadMoreOffsetType;

/**
 This method should be implemented by a subclass if it wants to support loading more data.
 
 To fully support loading more, the `canLoadMore` property should also be set to `YES`.
 
 The retrieval can either be synchronous or asynchronous. This method will however be called on the main thread, so make sure not to block it.
 
 @param success The success block. The data parameter will be used to update the `data` property with. The `hasReachedEnd` property is used to indicate to the user when the end of the list has been reached. `newData` is the array of newly loaded data, the objects in the array will be added to the end of the `data` array.
 @param failure The failure block which should be called in case of an error during retrieval.
 @return The `BFOperation` allowing to cancel the retrieval, can be `nil` if the operation can not be cancelled.
 */
- (nullable id <BFOperation>)retrieveDataWithOffset:(NSUInteger)offset success:(void(^__nullable)(NSArray *newData, BOOL hasReachedEnd, NSNumber * _Nullable totalCount))success failure:(void(^__nullable)(BFError *error))failure;

- (void)updateForLoadMoreStateChange;
- (void)updateViewForDidLoadMoreData;

/**
 Called when loading more data has failed.
 
 This method should not be called directly and should generally not be overwritten.
 
 By default this method will show an error message in the footer of the table view. When this footer is clicked the view controller will retry to load more data.
 
 @param error The error that occurred.
 */
- (void)didFailToLoadMoreDataWithError:(BFError *)error;

///------------------------------------------///
/// @name Managing the tableView
///------------------------------------------///

/**
 The `UITableView` which is shown when the `displayType` property is set to `BFArrayDataViewControllerDisplayTypeTableView`.
 */
@property (nonatomic, strong, null_unspecified) IBOutlet UITableView *tableView;

/**
 Indicates the type of cell used for the table view.
 
 This method should be implemented by the subclass when the `displayType` property is set to `BFArrayDataViewControllerDisplayTypeTableView`.
 
 @return The cell class to use for cells in the `UITableView`.
 */
@property (nonatomic, readonly, strong, nullable) Class tableViewCellClass;

@property (nonatomic, readonly, strong, nullable) UINib *tableViewCellNib;

/**
 Called before a cell is shown on screen.
 
 This method can be used to update the data in a cell before it is shown to the user.
 
 @param cell The cell to setup.
 @param indexPath The index path which the cell represents.
 */
- (void)setupTableViewCell:(UITableViewCell *)cell forIndexPath:(NSIndexPath *)indexPath dataItem:(id)dataItem;

///------------------------------------------///
/// @name Managing the collectionView
///------------------------------------------///

/**
 The `UICollectionView` which is shown when the `displayType` property is set to `BFArrayDataViewControllerDisplayTypeCollectionView`.
 */
@property (nonatomic, strong, null_unspecified) IBOutlet BFCollectionView *collectionView;

/**
 Indicates the type of cell used for the collection view.
 
 This method should be implemented by the subclass when the `displayType` property is set to `BFArrayDataViewControllerDisplayTypeCollectionView`.
 
 @return The cell class to use for cells in the `UICollectionView`.
 */
@property (nonatomic, readonly, strong, nullable) Class collectionViewCellClass;

@property (nonatomic, readonly, strong, nullable) UINib *collectionViewCellNib;

/**
 Called before a cell is shown on screen.
 
 This method can be used to update the data in a cell before it is shown to the user.
 
 @param cell The cell to setup.
 @param indexPath The index path which the cell represents.
 */
- (void)setupCollectionViewCell:(UICollectionViewCell *)cell forIndexPath:(NSIndexPath *)indexPath dataItem:(id)dataItem;

///------------------------------------------///
/// @name Tapping cells
///------------------------------------------///

/**
 Called when the user taps a cell.
 
 @param item The item that was tapped.
 @param indexPath The indexPath of the item that was tapped.
 */
- (void)didTapItem:(id)item atIndexPath:(NSIndexPath *)indexPath;

@end

NS_ASSUME_NONNULL_END
