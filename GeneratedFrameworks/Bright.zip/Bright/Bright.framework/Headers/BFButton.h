#import <UIKit/UIKit.h>
#import <Bright/BFDefines.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFButton : UIButton

@property (nonatomic, assign) IBInspectable UIEdgeInsets hitAreaInsets;
@property (nonatomic, assign) IBInspectable CGSize minimumHitAreaSize;

@property (nonatomic, assign) IBInspectable BOOL respondsToAccessibilityEscape;

@property (nonatomic, assign) IBInspectable BOOL imageShouldBeAfterText;
@property (nonatomic, assign) IBInspectable BOOL titleAndImageShouldBeVertical;

@property (nonatomic, assign) BOOL automaticallyUpdateSubviewsHighlightedState;
@property (nonatomic, assign) BOOL automaticallyUpdateSubviewsSelectedState;
@property (nonatomic, assign) BOOL automaticallyUpdateSubviewsEnabledState;

- (nullable UIColor *)tintColorForState:(UIControlState)state;
- (void)setTintColor:(nullable UIColor *)tintColor forState:(UIControlState)state;

- (void)setTitleFont:(nullable UIFont *)font forState:(UIControlState)state;
- (void)setTitleFont:(nullable UIFont *)font compactSize:(CGFloat)compactSize regularSize:(CGFloat)regularSize;
@property (nonatomic, readonly) CGFloat compactTitleFontSize;
@property (nonatomic, readonly) CGFloat regularTitleFontSize;
- (void)resetSizeClassTitleFontSizes;

@end

@interface UIButton (Bright)

- (void)setImagesWithBaseName:(NSString *)baseName forStates:(UIControlState)states;
- (void)setImagesWithBaseName:(NSString *)baseName forStates:(UIControlState)states renderingMode:(UIImageRenderingMode)renderingMode;

- (void)setBackgroundImagesWithBaseName:(NSString *)baseName forStates:(UIControlState)states;
- (void)setBackgroundImagesWithBaseName:(NSString *)baseName withCapInsets:(UIEdgeInsets)capInsets forStates:(UIControlState)states;

@end

NS_ASSUME_NONNULL_END
