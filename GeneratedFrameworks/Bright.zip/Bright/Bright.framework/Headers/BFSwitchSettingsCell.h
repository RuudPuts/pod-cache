#import <Bright/BFSettingsCell.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFSwitchSettingsCell : BFSettingsCell

@property (weak, nonatomic) IBOutlet UISwitch *switchView;

@end

NS_ASSUME_NONNULL_END
