#import <Bright/BFLoadMoreControl.h>
#import <Bright/BFActivityIndicatorView.h>
#import <Bright/BFLabel.h>
#import <Bright/BFButton.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFLoadMoreControl ()

@property (nonatomic, strong, nullable) IBOutletCollection(NSLayoutConstraint) NSArray *defaultStateConstraints;
@property (nonatomic, strong, nullable) IBOutlet UIView <BFActivityIndicatorView> *activityIndicatorView;

@property (nonatomic, strong, nullable) IBOutletCollection(NSLayoutConstraint) NSArray *errorStateConstraints;
@property (nonatomic, strong, nullable) IBOutlet BFLabel *errorLabel;
@property (nonatomic, strong, nullable) IBOutlet BFButton *retryButton;

@property (nonatomic, readonly) CGFloat scrollViewContentInsetBottom;
@property (nonatomic, readonly, unsafe_unretained, nullable) UIScrollView *scrollView;

- (void)updateForLoadingMoreStateChanged;

@end

NS_ASSUME_NONNULL_END
