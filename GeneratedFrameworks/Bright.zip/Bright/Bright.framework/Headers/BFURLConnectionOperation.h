#import <Bright/BFOperation.h>

@class BFError, BFURLConnectionOperation;

NS_ASSUME_NONNULL_BEGIN

extern NSString *const BFURLConnectionOperationErrorDomain;

typedef NS_ENUM(NSUInteger, BFURLConnectionOperationErrorCode) {
    BFURLConnectionOperationDecodingError = 1,
};

typedef void (^BFURLConnectionOperationProgressBlock)(NSUInteger bytesProcessed, long long totalBytesProcessed, long long totalBytesExpectedToProcess, BFURLConnectionOperation *operation);
typedef NSURLRequest * _Nullable (^BFURLConnectionOperationRedirectBlock)(NSURLConnection *connection, NSURLRequest *request,  NSURLResponse * _Nullable redirectResponse, BFURLConnectionOperation *operation);
typedef NSCachedURLResponse * _Nullable (^BFURLConnectionOperationCacheResponseBlock)(NSURLConnection *connection, NSCachedURLResponse *cachedResponse, BFURLConnectionOperation *operation);
typedef id _Nullable (^BFURLConnectionOperationProcessDecodedResponse)(_Nullable id decodedResponse, BFURLConnectionOperation *operation);
typedef void (^BFURLConnectionOperationAuthenticationChallengeBlock)(NSURLConnection *connection, NSURLAuthenticationChallenge *challenge, BFURLConnectionOperation *operation);

extern NSString *const BFURLConnectionOperationWillStartNotification;
extern NSString *const BFURLConnectionOperationDidStartNotification;

extern NSString *const BFURLConnectionOperationWillFinishNotification;
extern NSString *const BFURLConnectionOperationDidFinishNotification;

@protocol BFURLRequestResponseDecoder;

@interface BFURLConnectionOperation : NSOperation <BFOperation, NSCopying, NSSecureCoding>

- (instancetype)init NS_UNAVAILABLE;
- (instancetype)initWithRequest:(NSURLRequest *)request NS_DESIGNATED_INITIALIZER;

@property (nonatomic, copy, readonly) NSURLRequest *request;
@property (nonatomic, readonly, nullable) NSURLRequest *finalRequest;

@property (nonatomic, strong, nullable) NSInputStream *inputStream;
@property (nonatomic, strong, nullable) NSOutputStream *outputStream;

@property (nonatomic, assign, getter = isLoggingEnabled) BOOL loggingEnabled;

@property (nonatomic, copy) NSSet<NSString*> *runLoopModes;
@property (nonatomic, assign) NSTimeInterval maximumOperationDuration;

@property (nonatomic, assign) BOOL shouldContinueInBackground;

@property (nonatomic, copy, nullable) NSDictionary *userInfo;

@property (nonatomic, assign, readonly) long long totalBytesRead;

@property (nonatomic, strong, readonly, nullable) NSURLResponse *response;
@property (nonatomic, strong, readonly, nullable) BFError *error;

@property (nonatomic, strong, nullable) id <BFURLRequestResponseDecoder> decoder;

@property (nonatomic, strong, readonly, nullable) NSData *responseData;
@property (nonatomic, copy, readonly, nullable) NSString *responseString;
@property (nonatomic, assign, readonly) NSStringEncoding responseStringEncoding;
@property (nonatomic, strong, readonly, nullable) id decodedResponse;

@property (nonatomic, strong, nullable) dispatch_queue_t callbackQueue;

- (void)setUploadProgressBlock:(nullable BFURLConnectionOperationProgressBlock)block;
- (void)setDownloadProgressBlock:(nullable BFURLConnectionOperationProgressBlock)block;

- (void)setRedirectResponseBlock:(nullable BFURLConnectionOperationRedirectBlock)block;
- (void)setCacheResponseBlock:(nullable BFURLConnectionOperationCacheResponseBlock)block;

- (void)setProcessDecodedResponseBlock:(nullable BFURLConnectionOperationProcessDecodedResponse)block;

- (void)setAuthenticationChallengeBlock:(nullable BFURLConnectionOperationAuthenticationChallengeBlock)block;

@property (nonatomic, assign) NSTimeInterval requestDelayTimeInterval;

+ (BOOL)isNoInternetErrorCode:(NSInteger)code;
+ (BOOL)isNoInternetError:(NSError *)error;

@end

@protocol BFURLRequestResponseDecoder <NSObject>
@required

- (nullable id)decodeResponse:(NSURLResponse *)response data:(NSData *)data forOperation:(BFURLConnectionOperation *)operation error:(NSError **)error;

@optional

- (void)operation:(BFURLConnectionOperation *)operation didReceiveResponse:(NSURLResponse *)response;
- (void)operation:(BFURLConnectionOperation *)operation didReceiveData:(NSData *)data;

- (void)operationDidFinishLoading:(BFURLConnectionOperation *)operation;
- (void)operation:(BFURLConnectionOperation *)operation didFailWithError:(NSError *)error;

- (void)operationFinished:(BFURLConnectionOperation *)operation;

@end

NS_ASSUME_NONNULL_END
