#import <Bright/BFSettingsItem.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFURLSettingsItem : BFSettingsItem

@property (nonatomic, assign) BOOL valueCanBeNil;
@property (nonatomic, copy, nullable) NSArray *predefinedValues;

@property (nonatomic, strong, nullable) NSURL *currentValue;
@property (nonatomic, strong, nullable) NSURL *defaultValue;

@end

NS_ASSUME_NONNULL_END
