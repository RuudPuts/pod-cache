#import <Bright/BFGroupSettingsItem.h>

@class BFSettingsItem;

NS_ASSUME_NONNULL_BEGIN

@interface BFGroupSettingsItem ()

- (void)addSettingsItem:(BFSettingsItem *)settingsItem;

@end

NS_ASSUME_NONNULL_END
