#import <QuartzCore/QuartzCore.h>

NS_ASSUME_NONNULL_BEGIN

@interface CAMediaTimingFunction (Tween)

- (CGFloat)tweenTimeAtPercentage:(CGFloat)percentage;

@end

NS_ASSUME_NONNULL_END
