#import "BFInvocationCenter.h"

NS_ASSUME_NONNULL_BEGIN

@interface BFInvocationCenter ()

- (NSSet *)observersForProtocol:(Protocol *)protocol object:(id)invocationSender;

@end

NS_ASSUME_NONNULL_END
