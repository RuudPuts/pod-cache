#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@protocol BFRecyclableObject;

@interface BFObjectRecycler : NSObject

- (void)recycleObject:(id <BFRecyclableObject>)obj;
- (nullable id <BFRecyclableObject>)dequeueRecyclableObjectWithIdentifier:(NSString *)reuseIdentifier;

@property (nonatomic, readonly, copy) NSArray<id <BFRecyclableObject>> *recycledObjects;

- (void)removeAllRecycledObjects;

@end

@protocol BFRecyclableObject <NSObject>

@property (nonatomic, copy, readonly, nullable) NSString *reuseIdentifier;

- (void)prepareForReuse;

@end

NS_ASSUME_NONNULL_END
