#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/**
 This category provides a number of convenient ways to get objects of specific classes from `NSDictionary`.
 
 In case the object is `[NSNull null]`, these methods will return nil, thereby not breaking all kinds of calls that worked on the specific class. E.g., if you're expecting an `NSString` but got an `NSNull` instead, using any `NSString` method (which would do nothing on nil) causes a crash when called on `NSNull`. This is inconvenient.
 */
@interface NSDictionary<__covariant KeyType, __covariant ObjectType> (BFAdditions)

///------------------------------------------///
/// @name Retrieving class specific objects
///------------------------------------------///

/**
 Return the object for the specified key, but only if it is an instance of a specified class (or one of its subclasses).
 
 @param aKey The key used to look-up the value in the dictionary.
 @param aClass The class of which the value must be an instance.
 @return The object for the given key, or nil if it is not found/not an instance of the specified class.
 */
- (nullable ObjectType)objectForKey:(KeyType)aKey ofClass:(Class)aClass;

/**
 Return the object for the specified key, but only if it is an instance of `NSString`.
 
 @param aKey The key used to look-up the value in the dictionary.
 @return The object for the given key, or nil if it is not found/not an instance of `NSString`.
 */
- (nullable NSString *)stringForKey:(KeyType)aKey;

/**
 Return the object for the specified key, but only if it is an instance of `NSNumber`.
 
 @param aKey The key used to look-up the value in the dictionary.
 @return The object for the given key, or nil if it is not found/not an instance of `NSNumber`.
 */
- (nullable NSNumber *)numberForKey:(KeyType)aKey;

/**
 Return the object for the specified key, but only if it is an instance of `NSArray`.
 
 @param aKey The key used to look-up the value in the dictionary.
 @return The object for the given key, or nil if it is not found/not an instance of `NSArray`.
 */
- (nullable NSArray *)arrayForKey:(KeyType)aKey;

/**
 Return the object for the specified key, but only if it is an instance of `NSDictionary`.
 
 @param aKey The key used to look-up the value in the dictionary.
 @return The object for the given key, or nil if it is not found/not an instance of `NSDictionary`.
 */
- (nullable NSDictionary *)dictionaryForKey:(KeyType)aKey;

@end

@interface NSDictionary<KeyType, ObjectType> (BFSharedKeySetAdditions)

@property (nonatomic, readonly, copy) NSMutableDictionary<KeyType, ObjectType> *optimizedDictionaryUsingSharedKeySet;

@end

/**
 Category on `NSMutableDictionary` for creating dictionaries that do not retain objects added to it. When adding objects, make sure they are retained somewhere else.
 */
@interface NSMutableDictionary<KeyType, ObjectType> (BFAdditions)

///------------------------------------------///
/// @name Safely setting values
///------------------------------------------///

/**
 Adds a given key-value pair to the dictionary.
 
 If the given object is `nil`, this method will instead call `removeObjectForKey:` on the dictionary to remove any existing value.
 
 @param anObject The value for aKey. If `nil`, any existing value with the given key will be removed from the dictionary.
 @param key The key for value.
 */
- (void)safelySetObject:(nullable ObjectType)anObject forKey:(KeyType <NSCopying>)key;

@end

NS_ASSUME_NONNULL_END
