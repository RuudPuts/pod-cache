#import "BFSettingsItem.h"

@protocol BFSettingsChangeHandler;

NS_ASSUME_NONNULL_BEGIN

@interface BFSettingsItem ()

@property (nonatomic, weak) id <BFSettingsChangeHandler> changeHandler;

@end

NS_ASSUME_NONNULL_END
