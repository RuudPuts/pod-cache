#import <Bright/BFModuleCenter.h>

@class BFModuleConfiguration;

NS_ASSUME_NONNULL_BEGIN

@interface BFModuleCenter ()

- (void)bootstrapWithModuleConfiguration:(BFModuleConfiguration *)configuration;

- (id)observerProxyForModule:(BFModule *)module;
- (id)observerProxyForModule:(BFModule *)module callbackOnMainThread:(BOOL)callbackOnMainThread;

- (void)testDealloc;

@end

NS_ASSUME_NONNULL_END
