#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef void(^BFModuleConfigurationBlock)(id module);

@interface BFModuleConfiguration : NSObject

- (void)addImplementation:(Class)implementationClass forProtocol:(Protocol *)protocol configureBlock:(nullable BFModuleConfigurationBlock)configureBlock;
- (void)addImplementation:(Class)implementationClass forProtocol:(Protocol *)protocol withId:(nullable NSString *)moduleId configureBlock:(nullable BFModuleConfigurationBlock)configureBlock;

- (void)removeImplementationsForProtocol:(Protocol *)protocol;

- (void)addDynamicModule:(NSString *)title order:(NSInteger)order enabledByDefault:(BOOL)enabledByDefault forProtocols:(NSArray<Protocol*> *)protocols;

@end

NS_ASSUME_NONNULL_END
