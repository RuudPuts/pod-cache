#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

extern void dispatch_after_interval(NSTimeInterval delay, dispatch_queue_t queue, dispatch_block_t block);

NS_ASSUME_NONNULL_END
