#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIView (Skinnable)

+ (instancetype)skinnedInstance;
+ (instancetype)skinnedInstanceWithNibName:(NSString *)nibName;

- (void)setupSkinnable;
- (void)awakeSkinnable;

- (void)prepareSkinnableForInterfaceBuilder;

#if TARGET_INTERFACE_BUILDER
@property (nonatomic, assign) BOOL didPrepareForInterfaceBuilder;
- (void)prepareSubviewsForInterfaceBuilder;
#endif

@end

NS_ASSUME_NONNULL_END

#if !TARGET_INTERFACE_BUILDER

#define BFSynthesizeSkinnableSetup() \
    - (instancetype)initWithFrame:(CGRect)frame { \
        if ((self = [super initWithFrame:frame])) { \
            [self setupSkinnable]; \
            [self awakeSkinnable]; \
        } \
        return self; \
    } \
    \
    - (instancetype)initWithCoder:(NSCoder *)aDecoder { \
        if ((self = [super initWithCoder:aDecoder])) { \
            [self setupSkinnable]; \
        } \
        return self; \
    } \
    \
    - (void)awakeFromNib { \
        [super awakeFromNib]; \
        [self awakeSkinnable]; \
    }

#else

#define BFSynthesizeSkinnableSetup() \
    - (instancetype)initWithFrame:(CGRect)frame { \
        if ((self = [super initWithFrame:frame])) { \
            [self setupSkinnable]; \
        } \
        return self; \
    } \
    - (instancetype)initWithCoder:(NSCoder *)aDecoder { \
        if ((self = [super initWithCoder:aDecoder])) { \
            [self setupSkinnable]; \
        } \
        return self; \
    } \
    \
    - (void)prepareForInterfaceBuilder { \
        if (self.didPrepareForInterfaceBuilder) { \
            return; \
        } \
        self.didPrepareForInterfaceBuilder = YES; \
        \
        [super prepareForInterfaceBuilder]; \
        [self awakeSkinnable]; \
        [self prepareSkinnableForInterfaceBuilder]; \
        \
        [self prepareSubviewsForInterfaceBuilder]; \
    }

#endif
