#import <Bright/BFViewController.h>
#import <Bright/BFProgressView.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFViewController ()

///------------------------------------------///
/// @name Skinning the message view
///------------------------------------------///

@property (nonatomic, strong, nullable) IBOutlet BFMessageView *messageView;

@property (nonatomic, readonly, strong, nullable) UIView *superviewForMessageView;
- (void)setupConstraintsForMessageView;

- (void)didShowMessageView;
- (void)didHideMessageView;

///------------------------------------------///
/// @name Dismissal behavior
///------------------------------------------///

@property (nonatomic, readonly) BOOL shouldEndEditingWhenDismissing;

///------------------------------------------///
/// @name Skinning based on the keyboard status
///------------------------------------------///

- (void)updateForShowKeyboard NS_REQUIRES_SUPER;
- (void)updateForHideKeyboard NS_REQUIRES_SUPER;
- (void)updateForChangeKeyboardState NS_REQUIRES_SUPER;
- (void)updateForKeyboardOverlap:(CGFloat)keyboardOverlap NS_REQUIRES_SUPER;

@property (nonatomic, strong, nullable) IBOutletCollection(NSLayoutConstraint) NSArray *keyboardOverlapConstraints;

/**
 Property for automatically setting scrollview insets based on the keyboard. Take into account that this property does not work
 well together with BFRefreshControl and BFLoadMoreControl!
 */
@property (nonatomic, weak) IBOutlet UIScrollView *keyboardInsetScrollView;

///------------------------------------------///
/// @name Loading
///------------------------------------------///

@property (nonatomic, strong, nullable) IBOutlet BFProgressView *progressView;

@property (nonatomic, readonly, strong, nullable) UIView *superviewForProgressView;
- (void)setupConstraintsForProgressView;

- (void)didShowProgressView;
- (void)didHideProgressView;

@end

NS_ASSUME_NONNULL_END
