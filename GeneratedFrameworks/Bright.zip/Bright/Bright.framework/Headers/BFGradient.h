#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/**
 A class for easily storing a gradient which can be used together with the `CGContextDrawGradientColor` method.
 */
@interface BFGradient : NSObject <NSSecureCoding, NSCopying>

///------------------------------------------///
/// @name Initializing the gradient
///------------------------------------------///

/**
 Creates a gradient from an array of colors.
 
 @param colors The colors for the gradient. At least one color has to be in the array.
 @return The gradient.
 */
+ (instancetype)gradientWithColors:(NSArray<UIColor*> *)colors;

/**
 Creates a gradient from an array of colors and locations.
 
 @param colors The colors for the gradient. At least one color has to be in the array.
 @param locations The location for each color provided in colors; each location must be a `NSNumber` with a float value in the range of 0 to 1, inclusive.
 @return The gradient.
 */
+ (instancetype)gradientWithColors:(NSArray<UIColor*> *)colors locations:(nullable NSArray<NSNumber*> *)locations;

/**
 Creates a gradient from two colors.
 
 @param fromColor The color with which the gradient will start.
 @param toColor The color with which the gradient will end.
 @return The gradient.
 */
+ (instancetype)gradientWithFromColor:(UIColor *)fromColor toColor:(UIColor *)toColor;

/**
 Creates a gradient from a given string.
 
 The string should be created using the <stringRepresentation> method. It should have the following format `0x11223344_0.5`, where `0x11223344` is the color value with alpha component and `0.5` is the location of the color in the gradient.
 
 @param gradientString The string with the gradient information.
 @return The gradient.
 */
+ (instancetype)gradientWithString:(NSString *)gradientString;

/**
 Returns a gradient that matches the default `UINavigationBar` background with a given tint color.
 
 @param tintColor The tint color for the gradient. If `nil` uses Apple's default tint color.
 @return The gradient for the given tint color.
 */
+ (instancetype)gradientWithNavigationBarTintColor:(UIColor *)tintColor;

/**
 Returns a gradient that matches the default `UIBarButtonItem` background with a given tint color.
 
 @param tintColor The tint color for the gradient. If `nil` uses Apple's default tint color.
 @param highlighted Indicates whether the highlighted gradient should be returned.
 @return The gradient for the given tint color.
 */
+ (instancetype)gradientWithButtonTintColor:(UIColor *)tintColor highlighted:(BOOL)highlighted;

/**
 Creates a gradient from an array of colors.
 
 @param colors The colors for the gradient. At least one color has to be in the array.
 @return The gradient.
 */
- (instancetype)initWithColors:(NSArray<UIColor*> *)colors;

/**
 Creates a gradient from an array of colors and locations.
 
 @param colors The colors for the gradient. At least one color has to be in the array.
 @param locations The location for each color provided in colors; each location must be a `NSNumber` with a float value in the range of 0 to 1, inclusive.
 @return The gradient.
 */
- (instancetype)initWithColors:(NSArray<UIColor*> *)colors locations:(nullable NSArray<NSNumber*> *)locations NS_DESIGNATED_INITIALIZER;

/**
 Creates a gradient from two colors.
 
 @param fromColor The color with which the gradient will start.
 @param toColor The color with which the gradient will end.
 @return The gradient.
 */
- (instancetype)initWithFromColor:(UIColor *)fromColor toColor:(UIColor *)toColor;

/**
 Creates a gradient from a given string.
 
 The string should be created using the <stringRepresentation> method. It should have the following format `0x11223344_0.5`, where `0x11223344` is the color value with alpha component and `0.5` is the location of the color in the gradient.
 
 @param gradientString The string with the gradient information.
 @return The gradient.
 */
- (instancetype)initWithString:(NSString *)gradientString;

///------------------------------------------///
/// @name Managing the gradient colors
///------------------------------------------///

/**
 The colors of the gradient.
 */
@property (nonatomic, copy, readonly) NSArray<UIColor*> *colors;

/**
 The locations for each gradient.
 */
@property (nonatomic, copy, readonly) NSArray<NSNumber*> *locations;

/**
 Adds a color to the gradient array.
 
 @param color The color to add to the gradient.
 */
- (void)addColor:(UIColor *)color;

/**
 Adds a color to the gradient array.
 
 @param color The color to add to the gradient.
 @param location The location for the color.
 */
- (void)addColor:(UIColor *)color location:(float)location;

/**
 Inserts a color into the gradient array.
 
 @param color The color to add to the gradient.
 @param index The index where to insert the color.
 */
- (void)insertColor:(UIColor *)color atIndex:(NSUInteger)index;

/**
 Inserts a color into the gradient array.
 
 @param color The color to add to the gradient.
 @param index The index where to insert the color.
 @param location The location for the color.
 */
- (void)insertColor:(UIColor *)color location:(float)location atIndex:(NSUInteger)index;

/**
 Replaces a color in the gradient array with another color.
 
 @param index The index of the color to replace.
 @param color The color to replace the original color with.
 */
- (void)replaceColorAtIndex:(NSUInteger)index withColor:(UIColor *)color;

/**
 Replaces a color in the gradient array with another color.
 
 @param index The index of the color to replace.
 @param color The color to replace the original color with.
 @param location The location for the replaced color.
 */
- (void)replaceColorAtIndex:(NSUInteger)index withColor:(UIColor *)color location:(float)location;

/**
 Removes a color at a given index in the gradient array.
 
 @param index The index of the color to remove.
 */
- (void)removeColorAtIndex:(NSUInteger)index;

/**
 Removes all colors from the gradient array.
 */
- (void)removeAllColors;

/**
 Returns a color at a given index in the gradient array.
 
 @param index The index of the color to return.
 @return The color at the given index.
 */
- (UIColor *)colorAtIndex:(NSUInteger)index;

/**
 Returns the location of a color at a given index in the gradient array.
 
 @param index The index of the location to return.
 @return The location of the color at the given index.
 */
- (float)locationAtIndex:(NSUInteger)index;

/**
 Returns the number of colors in the gradient.
 */
@property (nonatomic, readonly) NSUInteger count;

///------------------------------------------///
/// @name Generating a string representation
///------------------------------------------///

/**
 Creates a string containing all the gradient information.
 
 This string can be used with the <initWithString:> method to create a new gradient object.
 
 @return The string representation for the gradient.
 */
@property (nonatomic, readonly, copy) NSString *stringRepresentation;

@end

NS_ASSUME_NONNULL_END
