#import <Bright/BFJSONDecoder.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFJSONDecoder ()

- (nullable id)decodeJSONObject:(id)jsonObject error:(NSError **)error;
@property (nonatomic, readonly) BOOL shouldReturnErrorOnEmptyData;

@end

NS_ASSUME_NONNULL_END
