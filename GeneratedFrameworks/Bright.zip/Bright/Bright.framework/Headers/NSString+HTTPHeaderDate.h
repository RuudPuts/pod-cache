#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/**
 Category for parsing HTTP date headers.
 */
@interface NSString (BFHTTPHeaderDate)

///------------------------------------------///
/// @name Parsing HTTP date headers
///------------------------------------------///

/**
 Tries to parse the string as a HTTP date header and returns the `NSDate` instance.
 
 @return The parsed `NSDate` or `nil` if parsing failed.
 */
@property (nonatomic, readonly, nullable) NSDate *httpHeaderDate;

@end

NS_ASSUME_NONNULL_END
