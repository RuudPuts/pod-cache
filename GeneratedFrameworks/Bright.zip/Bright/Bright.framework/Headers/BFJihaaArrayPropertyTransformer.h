#import <Bright/BFJihaaPropertyTransformer.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFJihaaArrayPropertyTransformer : BFJihaaPropertyTransformer

- (instancetype)init NS_UNAVAILABLE;

- (instancetype)initForObjectClass:(Class)cls attributes:(nullable NSSet *)attributes NS_DESIGNATED_INITIALIZER;
- (instancetype)initWithCustomTransformer:(BFJihaaPropertyTransformer*)transformer attributes:(nullable NSSet *)attributes NS_DESIGNATED_INITIALIZER;

@property (nonatomic, readonly) Class arrayObjectClass;
@property (nonatomic, readonly, nullable) NSSet *attributes;
@property (nonatomic, readonly) BFJihaaPropertyTransformer *customTransformer;

@end

NS_ASSUME_NONNULL_END
