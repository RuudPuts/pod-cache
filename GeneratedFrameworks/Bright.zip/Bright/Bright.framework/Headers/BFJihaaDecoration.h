#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

#define BFJihaaDecoration(name) \
    @protocol name \
    @end \
    \
    @interface NSObject() <name> \
    @end

#define BFJihaaDecorationInherit(name, inherit) \
    @protocol name <inherit> \
    @end \
    \
    @interface NSObject() <name> \
    @end

#define BFJihaaAttribute(name) \
    NSStringFromProtocol(@protocol(name))

#define BFJihaaGenerics(name) <name *> <name>
#define BFJihaaGenericsOptional(name) <name *> <name, BFJihaaOptional>

BFJihaaDecoration(BFJihaaString);
BFJihaaDecoration(BFJihaaNumber);
BFJihaaDecoration(BFJihaaDictionary);
BFJihaaDecoration(BFJihaaArray);

BFJihaaDecoration(BFJihaaOptional);
BFJihaaDecoration(BFJihaaReadOnly);
BFJihaaDecoration(BFJihaaWriteOnly);
BFJihaaDecoration(BFJihaaIgnore);

BFJihaaDecoration(BFJihaaWrapperObject);

BFJihaaDecoration(BFJihaaIncludeNull);

BFJihaaDecoration(BFJihaaDetailsOnly);
BFJihaaDecoration(BFJihaaDetailsObject);

NS_ASSUME_NONNULL_END
