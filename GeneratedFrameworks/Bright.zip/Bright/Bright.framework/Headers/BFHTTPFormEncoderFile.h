#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NSData * _Nullable (^BFHTTPFormEncoderFileDataRetriever)(void);

@interface BFHTTPFormEncoderFile : NSObject

- (instancetype)initWithFile:(NSString *)filePath;
- (instancetype)initWithFile:(NSString *)filePath name:(nullable NSString *)fileName;
- (instancetype)initWithFile:(NSString *)filePath name:(nullable NSString *)fileName contentType:(nullable NSString *)contentType NS_DESIGNATED_INITIALIZER;

- (instancetype)initWithData:(nullable NSData *)fileData name:(nullable NSString *)fileName contentType:(nullable NSString *)contentType NS_DESIGNATED_INITIALIZER;
- (instancetype)initWithDataRetriever:(BFHTTPFormEncoderFileDataRetriever)dataRetriever name:(NSString *)fileName contentType:(NSString *)contentType NS_DESIGNATED_INITIALIZER;

@property (nonatomic, copy, nullable) NSString *fileName;
@property (nonatomic, copy, nullable) NSString *filePath;
@property (nonatomic, copy, nullable) NSData *fileData;
@property (nonatomic, copy) NSString *contentType;

@property (nonatomic, copy) BFHTTPFormEncoderFileDataRetriever dataRetriever;

@end

NS_ASSUME_NONNULL_END
