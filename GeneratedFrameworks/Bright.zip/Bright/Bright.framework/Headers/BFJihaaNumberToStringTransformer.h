#import <Bright/BFJihaaPropertyTransformer.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFJihaaNumberToStringTransformer : BFJihaaPropertyTransformer

@end

NS_ASSUME_NONNULL_END
