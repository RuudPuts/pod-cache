#import <Bright/Bright.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFStringSettingsDetailsViewController ()

@property (nonatomic, strong, nullable) IBOutlet UIBarButtonItem *cancelButton;
@property (nonatomic, strong, nullable) IBOutlet UIBarButtonItem *saveButton;

@property (nonatomic, weak) IBOutlet BFTextField *inputField;

- (void)didTapSaveButton;

@end

NS_ASSUME_NONNULL_END
