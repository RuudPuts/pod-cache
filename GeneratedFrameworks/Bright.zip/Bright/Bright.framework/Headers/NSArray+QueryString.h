#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/**
 Array category for retrieving the array as an URL query string.
 */
@interface NSArray (BFQueryString)

///------------------------------------------///
/// @name Retrieving an URL query string
///------------------------------------------///

/**
 Creates and returns an URL query string from an array which contains dictionaries of key and value pairs.
 
 The array must consist of only dictionaries with key value pairs.
 
 @return The URL query string for this array.
 */
@property (nonatomic, readonly, copy) NSString *URLQueryString;

@end

NS_ASSUME_NONNULL_END
