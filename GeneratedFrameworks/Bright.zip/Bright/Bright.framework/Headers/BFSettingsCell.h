@class BFSettingsItem, BFSettingsViewController;
@protocol BFSettingsCellDelegate;

NS_ASSUME_NONNULL_BEGIN

@interface BFSettingsCell : UITableViewCell

@property (nonatomic, weak) id <BFSettingsCellDelegate> delegate;
@property (nonatomic, weak) BFSettingsViewController *settingsViewController;

@property (nonatomic, strong) BFSettingsItem *item;

- (void)setTitle:(nullable NSString *)title value:(nullable id)value valueDescription:(nullable NSString *)valueDescription animated:(BOOL)animated;
@property (nonatomic, readonly, nullable) NSString *title;
@property (nonatomic, readonly, nullable) id value;
@property (nonatomic, readonly, nullable) NSString *valueDescription;

- (void)setClickable:(BOOL)clickable enabled:(BOOL)enabled;
@property (nonatomic, readonly, getter = isClickable) BOOL clickable;
@property (nonatomic, readonly, getter = isEnabled) BOOL enabled;

@end

@protocol BFSettingsCellDelegate <NSObject>

- (void)settingsCell:(BFSettingsCell *)cell didChangeValue:(nullable id)value;

@end

NS_ASSUME_NONNULL_END
