#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIScrollView (BFLoadMoreHelper)

@property (nonatomic, assign) NSInteger BFLoadMoreIgnoreContentInsetChangeCounter;

- (void)BFSetContentInsetIgnoringChange:(UIEdgeInsets)contentInset;

@end

NS_ASSUME_NONNULL_END
