#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFSettingsSection : NSObject <NSCopying>

+ (instancetype)sectionWithTitle:(NSString *)title order:(NSInteger)order;

+ (instancetype)sectionWithTitleKey:(NSString *)titleKey order:(NSInteger)order;

/*
 Set the title or the titleKey
 The title will be set directly. The titleKey is a reference to the localized strings file. 
 This is needed for stamps where the localized strings can be updated from the middle layer. 
*/

@property (nonatomic, readonly, nullable) NSString *title;
@property (nonatomic, readonly, nullable) NSString *titleKey;

@property (nonatomic, readonly) NSInteger order;

- (NSComparisonResult)compare:(BFSettingsSection *)section;

@end

NS_ASSUME_NONNULL_END
