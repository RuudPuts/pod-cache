#import <Bright/Bright.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFVerticalGroupContainerView ()

@property (nonatomic, readonly, strong) id contentViewClassOrNib;
@property (nonatomic, readonly) NSUInteger numberOfContentViews;

@property (nonatomic, readonly) CGFloat topSpacing;
@property (nonatomic, readonly) CGFloat contentViewSpacing;
@property (nonatomic, readonly) CGFloat bottomSpacing;

@property (nonatomic, readonly, copy) NSArray<__kindof UIView *> *contentViews;
- (void)updateContentViews;

@end

NS_ASSUME_NONNULL_END
