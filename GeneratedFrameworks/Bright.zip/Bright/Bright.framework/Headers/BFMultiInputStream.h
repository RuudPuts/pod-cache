#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFMultiInputStream : NSObject <NSStreamDelegate>

- (instancetype)initWithStreams:(NSArray *)theStreams bufferSize:(NSUInteger)size NS_DESIGNATED_INITIALIZER;

@end

NS_ASSUME_NONNULL_END
