#import <Bright/Bright.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFEnumSettingsDetailsViewController ()

@property (nonatomic, weak) IBOutlet UITableView *tableView;
@property (nonatomic, strong, nullable) NSArray *possibleValues;

@end

NS_ASSUME_NONNULL_END
