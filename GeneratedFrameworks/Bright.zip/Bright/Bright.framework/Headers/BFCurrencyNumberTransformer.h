#import <Bright/BFJihaaPropertyTransformer.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFCurrencyNumberTransformer : BFJihaaPropertyTransformer

@property (nonatomic, copy) NSString *parentContextCurrencyCodeKey;
@property (nonatomic, assign) BOOL numberIsFloat;

@end

NS_ASSUME_NONNULL_END
