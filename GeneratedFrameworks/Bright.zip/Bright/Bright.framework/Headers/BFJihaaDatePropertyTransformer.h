#import <Bright/BFJihaaPropertyTransformer.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFJihaaDatePropertyTransformer : BFJihaaPropertyTransformer

@property (nonatomic, assign) BOOL usesMilliSeconds;

@end

NS_ASSUME_NONNULL_END
