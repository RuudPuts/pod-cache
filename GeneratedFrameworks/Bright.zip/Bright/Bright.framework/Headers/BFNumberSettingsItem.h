#import <Bright/BFSettingsItem.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFNumberSettingsItem : BFSettingsItem

@property (nonatomic, assign) double minimumValue;
@property (nonatomic, assign) double maximumValue;
@property (nonatomic, assign) double stepValue;

@property (nonatomic, strong, nullable) NSNumber *currentValue;
@property (nonatomic, strong, nullable) NSNumber *defaultValue;

@end

NS_ASSUME_NONNULL_END
