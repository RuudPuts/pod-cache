#import <Bright/BFSettingsCell.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFStepperSettingsCell : BFSettingsCell

@property (weak, nonatomic) IBOutlet UIStepper *stepper;
@property (weak, nonatomic) IBOutlet UILabel *valueLabel;

@property (nonatomic, assign) double minimumValue;
@property (nonatomic, assign) double maximumValue;
@property (nonatomic, assign) double stepValue;

@end

NS_ASSUME_NONNULL_END
