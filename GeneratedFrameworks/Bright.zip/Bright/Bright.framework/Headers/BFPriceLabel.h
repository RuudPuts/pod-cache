#import <Foundation/Foundation.h>
#import <Bright/BFLabel.h>

@class BFCurrencyNumber;

NS_ASSUME_NONNULL_BEGIN

@interface BFPriceLabel : BFLabel

@property (nonatomic, copy, nullable) BFCurrencyNumber *price;
- (void)setPrice:(nullable BFCurrencyNumber *)price animated:(BOOL)animated;

@property (nonatomic, assign) IBInspectable BOOL shouldShowCurrencySign;
@property (nonatomic, assign) IBInspectable BOOL shouldShowPlusSign;

@property (nonatomic, copy, nullable) NSDictionary *integralAttributes;
- (void)setCompactIntegralAttributes:(nullable NSDictionary *)integralAttributes regularAttributes:(nullable NSDictionary *)regularAttributes;

@property (nonatomic, copy, nullable) NSDictionary *decimalSeparatorAttributes;
- (void)setCompactDecimalSeparatorAttributes:(nullable NSDictionary *)decimalSeparatorAttributes regularAttributes:(nullable NSDictionary *)regularAttributes;

@property (nonatomic, copy, nullable) NSDictionary *decimalAttributes;
- (void)setCompactDecimalAttributes:(nullable NSDictionary *)decimalAttributes regularAttributes:(nullable NSDictionary *)regularAttributes;

- (void)clearSizeClassAttributes;

- (void)clearSizeClassDecimalAttributes;

@end

NS_ASSUME_NONNULL_END
