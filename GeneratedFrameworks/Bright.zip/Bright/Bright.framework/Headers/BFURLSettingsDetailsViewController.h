#import <Bright/BFSettingsDetailsViewController.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFURLSettingsDetailsViewController : BFSettingsDetailsViewController

@property (nonatomic, assign) BOOL valueCanBeNil;
@property (nonatomic, copy, nullable) NSArray *predefinedValues;

@end

NS_ASSUME_NONNULL_END
