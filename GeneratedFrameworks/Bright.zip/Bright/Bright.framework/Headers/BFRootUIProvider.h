#import <UIKit/UIKit.h>
#import <Bright/BFUIProvider.h>

@protocol BFRootUIProvider <BFUIProviderInterface>
@required

@property (nonatomic, readonly, strong) UIViewController *rootViewController;

@optional

- (void)rootUIDidAppear;

@end
