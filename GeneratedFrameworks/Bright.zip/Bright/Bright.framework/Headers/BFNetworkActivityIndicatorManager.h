#import <Bright/BFSingleton.h>
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFNetworkActivityIndicatorManager : NSObject

BFSynthesizeSingletonInterface(sharedManager);

- (void)beginShowingNetworkActivityIndicator;
- (void)endShowingNetworkActivityIndicator;

@property (nonatomic, readonly) BOOL isNetworkActivityIndicatorVisible;

@end

NS_ASSUME_NONNULL_END
