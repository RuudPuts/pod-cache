#import <Bright/BFHTTPRequestOperation.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFHTTPFormEncoder : NSObject <BFHTTPBodyEncoder>

+ (instancetype)encoder;
+ (instancetype)encoderWithDictionary:(NSDictionary *)dictionary;

@property (nonatomic, readonly, copy) NSArray *allData;
- (NSArray *)formValuesForKey:(NSString *)key;
- (void)removeFormValuesForKey:(NSString *)key;

- (void)addFormValue:(id)value forKey:(NSString *)key;
- (void)setFormValue:(nullable id)value forKey:(NSString *)key;

- (void)addFile:(NSString *)filePath forKey:(NSString *)key;
- (void)addFile:(NSString *)filePath withFileName:(nullable NSString *)fileName andContentType:(nullable NSString *)contentType forKey:(NSString *)key;

- (void)setFile:(NSString *)filePath forKey:(NSString *)key;
- (void)setFile:(NSString *)filePath withFileName:(nullable NSString *)fileName andContentType:(nullable NSString *)contentType forKey:(NSString *)key;

- (void)addData:(NSData *)data forKey:(NSString *)key;
- (void)addData:(NSData *)data withFileName:(nullable NSString *)fileName andContentType:(nullable NSString *)contentType forKey:(NSString *)key;

- (void)setData:(NSData *)data forKey:(NSString *)key;
- (void)setData:(NSData *)data withFileName:(nullable NSString *)fileName andContentType:(nullable NSString *)contentType forKey:(NSString *)key;

@property (nonatomic, assign) NSStringEncoding stringEncoding;
@property (nonatomic, assign) NSUInteger streamingBufferSize;

@property (nonatomic, readonly) BOOL isMultipartData;

@end

NS_ASSUME_NONNULL_END
