#import <Bright/BFImage.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFImage ()

@property (nonatomic, weak) id <BFOperation> imageDownloadHandler;
@property (nonatomic, readwrite, getter = isLoading) BOOL loading;

@end

NS_ASSUME_NONNULL_END
