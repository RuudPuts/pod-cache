#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, BFReachabilityStatus) {
    BFReachabilityStatusNotReachable,
    BFReachabilityStatusReachableViaWiFi,
    BFReachabilityStatusReachableViaWWAN,
};

@protocol BFReachabilityDelegate;

@interface BFReachability : NSObject

+ (nullable instancetype)reachabilityWithHostname:(NSString *)hostname;
+ (instancetype)reachabilityForInternetConnection;
+ (instancetype)reachabilityWithAddress:(void *)hostAddress;
+ (instancetype)reachabilityForLocalWiFi;

@property (nonatomic, readonly) BFReachabilityStatus status;
@property (nonatomic, readonly) BOOL isConnectionRequired;

@property (nonatomic, weak) id <BFReachabilityDelegate> delegate;

- (BOOL)startMonitoring;
- (void)stopMonitoring;

@end

@protocol BFReachabilityDelegate <NSObject>
@optional

- (void)reachability:(BFReachability *)reachability didChangeStatus:(BFReachabilityStatus)status;

@end

NS_ASSUME_NONNULL_END
