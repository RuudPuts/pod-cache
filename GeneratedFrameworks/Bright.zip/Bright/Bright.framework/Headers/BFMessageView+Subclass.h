#import <Bright/BFMessageView.h>
#import <Bright/BFLabel.h>
#import <Bright/BFButton.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFMessageView ()

@property (nonatomic, weak) IBOutlet UIImageView *imageView;
@property (nonatomic, weak) IBOutlet BFLabel *messageLabel;
@property (nonatomic, weak) IBOutlet BFButton *actionButton;

@end

NS_ASSUME_NONNULL_END
