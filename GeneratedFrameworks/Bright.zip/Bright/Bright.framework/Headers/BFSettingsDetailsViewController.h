#import <Bright/BFViewController.h>

@protocol BFSettingsDetailsViewControllerDelegate;

NS_ASSUME_NONNULL_BEGIN

@protocol BFSettingsDetailsViewController <BFViewController>

@property (nonatomic, strong, nullable) id settingsValue;
@property (nonatomic, weak) id <BFSettingsDetailsViewControllerDelegate> settingsDetailsDelegate;

@end

@interface BFSettingsDetailsViewController : BFViewController <BFSettingsDetailsViewController>

@end

@protocol BFSettingsDetailsViewControllerDelegate <NSObject>

- (void)settingsDetailsViewController:(BFViewController <BFSettingsDetailsViewController> *)viewController didChangeValue:(nullable id)value;
- (void)settingsDetailsViewControllerDidCancel:(BFViewController <BFSettingsDetailsViewController> *)viewController;

@end

NS_ASSUME_NONNULL_END
