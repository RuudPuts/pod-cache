#import <Bright/BFSettingsCell.h>

@class BFStateActionSettingsCell;

NS_ASSUME_NONNULL_BEGIN

typedef void(^BFStateActionSettingsCellBlock)(BFStateActionSettingsCell *cell, id _Nullable value);

@interface BFStateActionSettingsCell : BFSettingsCell

@property (weak, nonatomic) IBOutlet  UIButton *actionButton;

- (void)setActionBlock:(nullable BFStateActionSettingsCellBlock)block;

@end

NS_ASSUME_NONNULL_END
