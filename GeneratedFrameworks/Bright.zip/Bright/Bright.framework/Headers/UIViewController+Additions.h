#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIViewController (BFAdditions)

///------------------------------------------///
/// @name Retrieving appearance status
///------------------------------------------///

@property (nonatomic, readonly, getter = isVisible) BOOL visible;

@property (nonatomic, readonly, getter = isAppearing) BOOL appearing;
@property (nonatomic, readonly, getter = isDisappearing) BOOL disappearing;

///------------------------------------------///
/// @name Transition Block
///------------------------------------------///

- (void)performTransitionBlock:(void(^ __nullable)(void))block cancelledBlock:(void(^ __nullable)(void))cancelledBlock;
- (void)performTransitionInContainerView:(UIView *)containerView block:(void(^ __nullable)(void))block cancelledBlock:(void(^ __nullable)(void))cancelledBlock;

@end

NS_ASSUME_NONNULL_END
