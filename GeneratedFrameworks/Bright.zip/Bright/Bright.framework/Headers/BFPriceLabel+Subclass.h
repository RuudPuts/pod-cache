#import <Bright/BFPriceLabel.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFPriceLabel ()

- (void)updateForPriceChangedFromOldPrice:(nullable BFCurrencyNumber *)oldPrice animated:(BOOL)animated;

@end

NS_ASSUME_NONNULL_END
