#import <Bright/BFButton.h>

@class BFError;

NS_ASSUME_NONNULL_BEGIN

@interface BFLoadMoreControl : UIControl

@property (nonatomic, readonly, getter = isLoadingMore) BOOL loadingMore;

@property (nonatomic, assign) IBInspectable CGFloat bottomInset;

@property (nonatomic, assign) CGFloat preloadInset;

- (void)beginLoadingMore;
- (void)endLoadingMoreWithError:(nullable BFError *)error;
- (void)hideLoadingMore;

@property (nonatomic, readonly, nullable) BFError *error;

@end

NS_ASSUME_NONNULL_END
