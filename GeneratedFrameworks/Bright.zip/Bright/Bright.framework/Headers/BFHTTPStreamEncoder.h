#import <Bright/BFHTTPRequestOperation.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFHTTPStreamEncoder : NSObject <BFHTTPBodyEncoder>

- (instancetype)init NS_UNAVAILABLE;

+ (instancetype)encoderWithStream:(NSInputStream *)stream;
+ (instancetype)encoderWithStream:(NSInputStream *)stream contentType:(NSString *)contentType;

- (instancetype)initWithStream:(NSInputStream *)stream;
- (instancetype)initWithStream:(NSInputStream *)stream contentType:(NSString *)type NS_DESIGNATED_INITIALIZER;

@property (nonatomic, strong) NSInputStream *stream;
@property (nonatomic, copy, nullable) NSString *contentType;

@end

NS_ASSUME_NONNULL_END
