#import "BFDemoService.h"

@class BFDemoURLProtocol;

@interface BFDemoServiceImplementation ()

- (BOOL)canInitWithRequest:(NSURLRequest *)request;
- (NSURLRequest *)canonicalRequestForRequest:(NSURLRequest *)request;

- (void)startLoadingForProtocol:(BFDemoURLProtocol *)protocol;
- (void)stopLoadingForProtocol:(BFDemoURLProtocol *)protocol;

@end
