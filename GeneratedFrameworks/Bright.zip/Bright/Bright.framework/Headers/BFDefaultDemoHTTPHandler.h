#import "BFDemoService.h"

@interface BFDefaultDemoHTTPHandler : NSObject <BFDemoHTTPHandler>

@property (nonatomic, assign, getter = isEnabled) BOOL enabled;

- (NSData *)demoDataForKey:(NSString *)key;

- (void)addDemoDataEntries:(NSDictionary *)entries;

@end
