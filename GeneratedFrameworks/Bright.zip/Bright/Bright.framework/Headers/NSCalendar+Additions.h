#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSCalendar (Additions)

- (nullable NSDate *)dateFromDate:(NSDate *)date withComponentFlags:(NSCalendarUnit)componentFlags;

- (BOOL)isDate:(NSDate *)date1 equalToDate:(NSDate *)date2 withComponents:(NSCalendarUnit)componentFlags;
- (BOOL)isDate:(NSDate *)date1 equalToDate:(NSDate *)date2 withGranularity:(NSCalendarUnit)granularity;

- (NSComparisonResult)compareDate:(NSDate *)date1 toDate:(NSDate *)date2 withGranularity:(NSCalendarUnit)granularity;

@end

NS_ASSUME_NONNULL_END
