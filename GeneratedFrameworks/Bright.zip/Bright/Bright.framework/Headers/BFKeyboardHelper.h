#import <Bright/BFSingleton.h>
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/**
 Utility class for observing changes to the keyboard.
 */
@interface BFKeyboardHelper : NSObject

///------------------------------------------///
/// @name Retrieving the singleton instance
///------------------------------------------///

BFSynthesizeSingletonInterface(sharedHelper);

///------------------------------------------///
/// @name Retrieving keyboard status
///------------------------------------------///

/**
 Indicates whether the keyboard is currently visible.
 */
@property (nonatomic, readonly, getter = isKeyboardVisible) BOOL keyboardVisible;

@property (nonatomic, readonly, getter = isKeyboardAnimatingShow) BOOL keyboardAnimatingShow;
@property (nonatomic, readonly, getter = isKeyboardAnimatingHide) BOOL keyboardAnimatingHide;

/**
 Returns the frame for the keyboard given in the coordinate space of a specific view.
 
 The returned value is undefined if `keyboardVisible` is set to `NO`.
 
 @param view The view in which coordinate space the returned frame should be.
 @return The frame for the keyboard.
 */
- (CGRect)keyboardFrameInView:(UIView *)view;

@end

/**
 The observable protocol for observing keyboard changes.
 
 To receive these callbacks, the observer can register itself with the default `BFInvocationCenter`.
 */
@protocol BFKeyboardObserver
@optional

///------------------------------------------///
/// @name Receiving keyboard change callbacks
///------------------------------------------///

/**
 Called when the keyboard will be shown.
 
 @param frame The frame the keyboard will animate to.
 */
- (void)keyboardWillShowToFrame:(CGRect)frame;

/**
 Called in an animation block that will be performed during the showing of the keyboard.
 
 @param fromFrame The frame from which the keyboard will animate.
 @param toFrame The frame to which the keyboard will animate.
 */
- (void)keyboardAnimateShowFromFrame:(CGRect)fromFrame toFrame:(CGRect)toFrame;

/**
 Called after the keyboard has been shown.
 
 @param frame The frame from which the keyboard animated.
 */
- (void)keyboardDidShowFromFrame:(CGRect)frame;

/**
 Called when the keyboard will be hidden.
 
 @param frame The frame the keyboard will animate to.
 */
- (void)keyboardWillHideToFrame:(CGRect)frame;

/**
 Called in an animation block that will be performed during the hiding of the keyboard.
 
 @param fromFrame The frame from which the keyboard will animate.
 @param toFrame The frame to which the keyboard will animate.
 */
- (void)keyboardAnimateHideFromFrame:(CGRect)fromFrame toFrame:(CGRect)toFrame;

/**
 Called after the keyboard has been hidden.
 
 @param frame The frame from which the keyboard animated.
 */
- (void)keyboardDidHideFromFrame:(CGRect)frame;

/**
 Called when the keyboard will change its frame
 
 @param toFrame The frame the keyboard will animate to.
 */
- (void)keyboardWillChangeToFrame:(CGRect)toFrame;

/**
 Called in an animation block that will be performed during the changing of the keyboard's frame.
 
 @param fromFrame The frame from which the keyboard will animate.
 @param toFrame The frame to which the keyboard will animate.
 */
- (void)keyboardAnimateFromFrame:(CGRect)fromFrame toFrame:(CGRect)toFrame;

/**
 Called after the keyboard has changed its frame.
 
 @param fromFrame The frame from which the keyboard animated.
 */
- (void)keyboardDidChangeFromFrame:(CGRect)fromFrame;

@end

NS_ASSUME_NONNULL_END
