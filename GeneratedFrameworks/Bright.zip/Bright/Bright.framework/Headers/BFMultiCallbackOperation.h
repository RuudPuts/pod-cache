#import <Bright/BFOperation.h>

@class BFError;

NS_ASSUME_NONNULL_BEGIN

typedef void (^BFMultiCallbackOperationSuccessBlock)(_Nullable id context);
typedef void (^BFMultiCallbackOperationFailureBlock)(_Nullable id context, BFError *error);
typedef _Nullable id <BFOperation>(^BFMultiCallbackOperationBlock)(BFMultiCallbackOperationSuccessBlock success, BFMultiCallbackOperationFailureBlock failure);

extern BFMultiCallbackOperationSuccessBlock BFMultiCallbackSuccessBlockForSuccess(BFOperationSuccessHandler handler);
extern BFMultiCallbackOperationSuccessBlock BFMultiCallbackSuccessBlockForSuccessData(BFOperationDataSuccessHandler handler);
extern BFMultiCallbackOperationFailureBlock BFMultiCallbackFailureBlockForFailure(BFOperationFailureHandler handler);

@interface BFMultiCallbackOperation : NSObject <BFOperation>

- (nullable id)addSuccessCallback:(nullable BFMultiCallbackOperationSuccessBlock)callback;
- (void)removeSuccessCallback:(id)callback;

- (nullable id)addFailureCallback:(nullable BFMultiCallbackOperationFailureBlock)callback;
- (void)removeFailureCallback:(id)callback;

- (instancetype)runWithBlock:(nullable BFMultiCallbackOperationBlock)block;

@end

NS_ASSUME_NONNULL_END
