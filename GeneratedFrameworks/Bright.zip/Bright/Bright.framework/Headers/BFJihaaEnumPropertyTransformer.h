#import <Bright/BFJihaaPropertyTransformer.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, BFJihaaEnumPropertyTransformerType) {
    BFJihaaEnumPropertyTransformerTypeString,
    BFJihaaEnumPropertyTransformerTypeNumber,
};

@interface BFJihaaEnumPropertyTransformer : BFJihaaPropertyTransformer

+ (instancetype)transformerWithStringToEnumMapping:(NSDictionary *)enumMapping fallbackValue:(nullable NSNumber *)fallbackValue;
+ (instancetype)transformerWithNumberToEnumMapping:(NSDictionary *)enumMapping fallbackValue:(nullable NSNumber *)fallbackValue;

+ (instancetype)caseInsensitiveTransformerWithStringToEnumMapping:(NSDictionary *)enumMapping fallbackValue:(nullable NSNumber *)fallbackValue;

@property (nonatomic, readonly) BFJihaaEnumPropertyTransformerType type;
@property (nonatomic, readonly) NSDictionary *enumMapping;
@property (nonatomic, readonly, nullable) NSNumber *fallbackValue;

@property (nonatomic, readonly, getter=isCaseInsensitive) BOOL caseInsensitive;

@end

NS_ASSUME_NONNULL_END
