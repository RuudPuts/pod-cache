#import <Bright/BFSettingsCell.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFStringSettingsCell : BFSettingsCell 

@property (weak, nonatomic) IBOutlet UILabel *valueTextLabel;

@end

NS_ASSUME_NONNULL_END
