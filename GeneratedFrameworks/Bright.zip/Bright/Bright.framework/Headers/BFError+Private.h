#import <Bright/BFError.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFError ()

@property (nonatomic, readwrite) NSInteger httpStatusCode;

@end

NS_ASSUME_NONNULL_END
