#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSUserDefaults (BFAdditions)

- (nullable id)objectForKey:(NSString *)key defaultValue:(nullable id)defaultValue;

- (nullable id)encodableObjectForKey:(NSString *)key defaultValue:(nullable id <NSCoding>)defaultValue;
- (void)setEncodableObject:(nullable id <NSCoding>)value forKey:(NSString *)key;

@end

NS_ASSUME_NONNULL_END
