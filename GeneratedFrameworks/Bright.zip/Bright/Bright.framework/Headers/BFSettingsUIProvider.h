#import <Bright/BFUIProvider.h>
#import <Bright/BFSettingsCellManager.h>

NS_ASSUME_NONNULL_BEGIN

/*
 *  BFSettingsUIProvider is used to provide UI for different types of settings cells.
 */
@protocol BFSettingsUIProvider <BFUIProviderInterface>

- (void)registerCellManager:(id <BFSettingsCellManager>)manager forItemClass:(Class)cls;
- (void)registerCellManager:(id <BFSettingsCellManager>)manager forItem:(BFSettingsItem *)item;

- (id <BFSettingsCellManager>)cellManagerForItem:(BFSettingsItem *)item;

@end

@interface BFSettingsUIProviderImplementation : BFUIProvider <BFSettingsUIProvider>

@end

NS_ASSUME_NONNULL_END
