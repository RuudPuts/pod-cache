#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

NS_CLASS_DEPRECATED_IOS(7_0, 9_0)
@interface BFNSLayoutXAxisAnchor : NSLayoutXAxisAnchor
@end

NS_CLASS_DEPRECATED_IOS(7_0, 9_0)
@interface BFNSLayoutYAxisAnchor : NSLayoutYAxisAnchor
@end

NS_CLASS_DEPRECATED_IOS(7_0, 9_0)
@interface BFNSLayoutDimension : NSLayoutDimension
@end

/**
 Backwards compatibility for NSLayoutAnchor on iOS 7 and 8
 */
@interface UIView (BFLayoutConstraintCreation)

@property (readonly, strong) BFNSLayoutXAxisAnchor *BFLeadingAnchor NS_DEPRECATED_IOS(7.0, 9.0);
@property (readonly, strong) BFNSLayoutXAxisAnchor *BFTrailingAnchor NS_DEPRECATED_IOS(7.0, 9.0);
@property (readonly, strong) BFNSLayoutXAxisAnchor *BFLeftAnchor NS_DEPRECATED_IOS(7.0, 9.0);
@property (readonly, strong) BFNSLayoutXAxisAnchor *BFRightAnchor NS_DEPRECATED_IOS(7.0, 9.0);
@property (readonly, strong) BFNSLayoutYAxisAnchor *BFTopAnchor NS_DEPRECATED_IOS(7.0, 9.0);
@property (readonly, strong) BFNSLayoutYAxisAnchor *BFBottomAnchor NS_DEPRECATED_IOS(7.0, 9.0);
@property (readonly, strong) BFNSLayoutDimension *BFWidthAnchor NS_DEPRECATED_IOS(7.0, 9.0);
@property (readonly, strong) BFNSLayoutDimension *BFHeightAnchor NS_DEPRECATED_IOS(7.0, 9.0);
@property (readonly, strong) BFNSLayoutXAxisAnchor *BFCenterXAnchor NS_DEPRECATED_IOS(7.0, 9.0);
@property (readonly, strong) BFNSLayoutYAxisAnchor *BFCenterYAnchor NS_DEPRECATED_IOS(7.0, 9.0);
@property (readonly, strong) BFNSLayoutYAxisAnchor *BFFirstBaselineAnchor NS_DEPRECATED_IOS(7.0, 9.0);
@property (readonly, strong) BFNSLayoutYAxisAnchor *BFLastBaselineAnchor NS_DEPRECATED_IOS(7.0, 9.0);

@end

@interface NSLayoutConstraint (BFBackwardsCompatibility)

@property (getter=BFIsActive, setter=BFSetActive:) BOOL BFActive NS_DEPRECATED_IOS(7.0, 9.0);

+ (void)BFActivateConstraints:(NSArray<NSLayoutConstraint *> *)constraints NS_DEPRECATED_IOS(7.0, 9.0);

+ (void)BFDeactivateConstraints:(NSArray<NSLayoutConstraint *> *)constraints NS_DEPRECATED_IOS(7.0, 9.0);

@end

@interface UIView (LayoutAdditions)

///------------------------------------------///
/// @name Fill
///------------------------------------------///

- (NSArray<NSLayoutConstraint*> *)fillViewInSuperviewUsingAutoLayout;
- (NSArray<NSLayoutConstraint*> *)fillViewInSuperviewUsingAutoLayoutWithInsets:(UIEdgeInsets)insets;
- (NSArray<NSLayoutConstraint*> *)fillViewInSuperviewUsingAutoLayoutWithInsets:(UIEdgeInsets)insets priority:(UILayoutPriority)priority;

- (NSArray<NSLayoutConstraint*> *)fillViewVerticallyInSuperviewUsingAutoLayoutWithInsets:(UIEdgeInsets)insets priority:(UILayoutPriority)priority;
- (NSArray<NSLayoutConstraint*> *)fillViewHorizontallyInSuperviewUsingAutoLayoutWithInsets:(UIEdgeInsets)insets priority:(UILayoutPriority)priority;

///------------------------------------------///
/// @name Center
///------------------------------------------///

- (NSArray<NSLayoutConstraint*> *)centerViewInSuperviewUsingAutoLayout;
- (NSLayoutConstraint *)centerViewVerticallyInSuperviewUsingAutoLayout;
- (NSLayoutConstraint *)centerViewHorizontallyInSuperviewUsingAutoLayout;

///------------------------------------------///
/// @name Alignment
///------------------------------------------///

- (NSLayoutConstraint *)alignTopInSuperviewUsingAutoLayout;
- (NSLayoutConstraint *)alignTopInSuperviewUsingAutoLayoutWithConstant:(CGFloat)constant;
- (NSLayoutConstraint *)alignTopInSuperviewUsingAutoLayoutWithConstant:(CGFloat)constant priority:(UILayoutPriority)priority;

- (NSLayoutConstraint *)alignBottomInSuperviewUsingAutoLayout;
- (NSLayoutConstraint *)alignBottomInSuperviewUsingAutoLayoutWithConstant:(CGFloat)constant;
- (NSLayoutConstraint *)alignBottomInSuperviewUsingAutoLayoutWithConstant:(CGFloat)constant priority:(UILayoutPriority)priority;

- (NSLayoutConstraint *)alignLeftInSuperviewUsingAutoLayout;
- (NSLayoutConstraint *)alignLeftInSuperviewUsingAutoLayoutWithConstant:(CGFloat)constant;
- (NSLayoutConstraint *)alignLeftInSuperviewUsingAutoLayoutWithConstant:(CGFloat)constant priority:(UILayoutPriority)priority;

- (NSLayoutConstraint *)alignRightInSuperviewUsingAutoLayout;
- (NSLayoutConstraint *)alignRightInSuperviewUsingAutoLayoutWithConstant:(CGFloat)constant;
- (NSLayoutConstraint *)alignRightInSuperviewUsingAutoLayoutWithConstant:(CGFloat)constant priority:(UILayoutPriority)priority;

///------------------------------------------///
/// @name Superview Constraints
///------------------------------------------///

- (NSLayoutConstraint *)addSuperviewConstraintWithAttribute:(NSLayoutAttribute)attribute relation:(NSLayoutRelation)relation constant:(CGFloat)constant;
- (NSLayoutConstraint *)addSuperviewConstraintWithAttribute:(NSLayoutAttribute)attribute relation:(NSLayoutRelation)relation constant:(CGFloat)constant priority:(UILayoutPriority)priority;
- (NSLayoutConstraint *)addSuperviewConstraintWithAttribute:(NSLayoutAttribute)attribute relation:(NSLayoutRelation)relation constant:(CGFloat)constant multiplier:(CGFloat)multiplier;
- (NSLayoutConstraint *)addSuperviewConstraintWithAttribute:(NSLayoutAttribute)attribute relation:(NSLayoutRelation)relation constant:(CGFloat)constant multiplier:(CGFloat)multiplier priority:(UILayoutPriority)priority;

@end

NS_ASSUME_NONNULL_END
