#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSBundle (BFAdditions)

- (nullable NSString *)urlPathForResource:(nullable NSString *)resource ofType:(nullable NSString *)type;
- (nullable NSString *)urlPathForImageResource:(nullable NSString *)resource ofType:(nullable NSString *)type;

@end

NS_ASSUME_NONNULL_END
