#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFCollectionViewSectionProperties : NSObject <NSCopying>

@property (nonatomic, assign) CGSize itemSize;
@property (nonatomic, assign) UIEdgeInsets sectionInset;

@property (nonatomic, assign) CGFloat horizontalSpacing;
@property (nonatomic, assign) CGFloat verticalSpacing;

@property (nonatomic, assign) CGFloat sectionHeaderHeight;
@property (nonatomic, assign) CGFloat sectionHeaderSpacing;

@property (nonatomic, assign) CGFloat sectionFooterHeight;
@property (nonatomic, assign) CGFloat sectionFooterSpacing;

@end

@interface BFCollectionViewGridLayout : UICollectionViewLayout

@property (nonatomic, readonly) BFCollectionViewSectionProperties *defaultProperties;

- (nullable BFCollectionViewSectionProperties *)propertiesForSection:(NSUInteger)section;
- (void)setProperties:(nullable BFCollectionViewSectionProperties *)properties forSection:(NSUInteger)section;

@property (nonatomic, strong, nullable) UIView *contentHeaderView;
@property (nonatomic, assign) BOOL shouldAutomaticallyDetermineContentHeaderViewSize;

@property (nonatomic, strong, nullable) UIView *contentFooterView;
@property (nonatomic, assign) BOOL shouldAutomaticallyDetermineContentFooterViewSize;

@property (nonatomic, assign) UIEdgeInsets contentInsets;

@end

NS_ASSUME_NONNULL_END
