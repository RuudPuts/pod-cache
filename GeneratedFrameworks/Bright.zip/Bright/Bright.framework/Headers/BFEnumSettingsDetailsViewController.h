#import <Bright/BFSettingsDetailsViewController.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFEnumSettingsDetailsViewController : BFSettingsDetailsViewController

- (instancetype)initWithPossibleValues:(nullable NSArray *)possibleValues;
- (instancetype)initWithPossibleValues:(nullable NSArray *)possibleValues nibName:(nullable NSString *)nibNameOrNil bundle:(nullable NSBundle *)nibBundleOrNil NS_DESIGNATED_INITIALIZER;

- (nullable instancetype)initWithCoder:(NSCoder *)aDecoder NS_DESIGNATED_INITIALIZER;

@end

NS_ASSUME_NONNULL_END
