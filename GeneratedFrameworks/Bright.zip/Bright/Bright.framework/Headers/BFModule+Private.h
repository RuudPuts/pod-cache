#import "BFModule.h"
#import "BFSettingsManager.h"

@interface BFModule () <BFSettingsChangeHandler>

@property (nonatomic, copy, readwrite) NSString *id;
@property (nonatomic, strong, readwrite) Protocol *interface;

@property (nonatomic, assign, readwrite, getter = isSetup) BOOL setup;
@property (nonatomic, assign, readwrite, getter = isStarted) BOOL started;

- (void)testDealloc;

@end
