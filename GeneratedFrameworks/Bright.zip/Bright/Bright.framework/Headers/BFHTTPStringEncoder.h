#import <Bright/BFHTTPRequestOperation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSUInteger, BFHTTPTextType) {
	BFHTTPTextTypePlain,
	BFHTTPTextTypeHTML,
	BFHTTPTextTypeCSS,
	BFHTTPTextTypeCMD,
	BFHTTPTextTypeCSV,
	BFHTTPTextTypeJavaScript,
	BFHTTPTextTypeXML
};

@interface BFHTTPStringEncoder : NSObject <BFHTTPBodyEncoder>

+ (instancetype)encoderWithString:(NSString *)string;
+ (instancetype)encoderWithString:(NSString *)string encoding:(NSStringEncoding)encoding;

- (instancetype)initWithString:(NSString *)string;
- (instancetype)initWithString:(NSString *)string encoding:(NSStringEncoding)encoding;
- (instancetype)initWithString:(NSString *)string encoding:(NSStringEncoding)encoding textType:(BFHTTPTextType)type NS_DESIGNATED_INITIALIZER;

@property (nonatomic, copy) NSString *string;
@property (nonatomic, assign) NSStringEncoding encoding;
@property (nonatomic, assign) BFHTTPTextType type;

@end

NS_ASSUME_NONNULL_END
