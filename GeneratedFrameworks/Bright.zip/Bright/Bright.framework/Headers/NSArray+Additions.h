#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSArray<__covariant ObjectType> (BFAdditions)

@property (nonatomic, readonly, copy) NSArray<ObjectType> *shuffle;

- (nullable ObjectType)firstObjectPassingBFTest:(BOOL (^)(ObjectType obj, NSUInteger idx))predicate;
- (nullable ObjectType)lastObjectPassingBFTest:(BOOL (^)(ObjectType obj, NSUInteger idx))predicate;

- (NSUInteger)numberOfObjectsPassingBFTest:(BOOL (^)(ObjectType obj, NSUInteger idx))predicate;

- (BOOL)containsObjectPassingBFTest:(BOOL (^)(ObjectType obj, NSUInteger idx))predicate;

- (NSArray *)objectsPassingBFTest:(BOOL (^)(ObjectType obj, NSUInteger idx))predicate;

- (NSArray *)mapObjectsUsingBFBlock:(id (^)(ObjectType obj, NSUInteger idx))block;

@end

@interface NSMutableArray<ObjectType> (BFAdditions)

- (nullable ObjectType)removeFirstObjectPassingBFTest:(BOOL (^)(ObjectType obj, NSUInteger idx))predicate;
- (nullable ObjectType)removeLastObjectPassingBFTest:(BOOL (^)(ObjectType obj, NSUInteger idx))predicate;

- (NSArray *)removeObjectsPassingBFTest:(BOOL (^)(ObjectType obj, NSUInteger idx))predicate;

@end

NS_ASSUME_NONNULL_END
