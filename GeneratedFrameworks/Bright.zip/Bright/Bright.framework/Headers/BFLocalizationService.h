#import <Bright/BFService.h>
#import <Bright/BFModuleCenter.h>

NS_ASSUME_NONNULL_BEGIN

extern NSString *const BFLocalizeableStringsFileName;
extern NSString *const BFLocalizeableStringsExtension;

@class BFCurrency, BFCurrencyNumber;

@protocol BFLocalizationService <BFServiceInterface>

///------------------------------------------///
/// @name Language & Country code
///------------------------------------------///

@property (nonatomic, readonly, copy) NSLocale *currentLocale;

@property (nonatomic, readonly, copy) NSString *preferredBundleLanguage;

@property (nonatomic, readonly, copy) NSString *preferredLanguage;
@property (nonatomic, readonly, copy, nullable) NSString *countryCode;
@property (nonatomic, readonly, copy, nullable) NSString *acceptLanguage;

///------------------------------------------///
/// @name Localized strings
///------------------------------------------///

- (NSString *)localizedStringForKey:(NSString *)key defaultValue:(nullable NSString *)defaultValue;

///------------------------------------------///
/// @name Currencies
///------------------------------------------///

- (BFCurrency *)defaultCurrency;
- (BFCurrency *)currenyForCode:(NSString *)code;

- (NSString *)localizedCurrencyNumber:(BFCurrencyNumber *)number displayPlusSign:(BOOL)displayPlusSign;
- (NSString *)localizedNumber:(NSNumber *)number forCurrency:(BFCurrency *)currency displayPlusSign:(BOOL)displayPlusSign;

///------------------------------------------///
/// @name Number
///------------------------------------------///

- (NSString *)localizedNumber:(NSNumber *)number numberOfDecimals:(NSUInteger)numberOfDecimals displayPlusSign:(BOOL)displayPlusSign;
- (NSString *)localizedNumber:(NSNumber *)number minNumberOfDecimals:(NSUInteger)minNumberOfDecimals maxNumberOfDecimals:(NSUInteger)maxNumberOfDecimals displayPlusSign:(BOOL)displayPlusSign;
@property (nonatomic, readonly, copy) NSString *decimalSeparator;

///------------------------------------------///
/// @name Plurals
///------------------------------------------///

- (NSString *)localizedPluralForKey:(NSString *)key number:(NSNumber *)number defaultValue:(nullable NSString *)defaultValue;

///------------------------------------------///
/// @name Dates
///------------------------------------------///

- (NSString *)localizedDate:(NSDate *)date withDateStyle:(NSDateFormatterStyle)dateStyle timeStyle:(NSDateFormatterStyle)timeStyle;
- (NSString *)localizedDate:(NSDate *)date withStyle:(NSDateFormatterStyle)style;
- (NSString *)localizedTime:(NSDate *)time withStyle:(NSDateFormatterStyle)style;

- (nullable NSString *)localizedElapsedTimeFromDate:(NSDate *)fromDate toDate:(NSDate *)toDate;
- (nullable NSString *)localizedElapsedTimeFromDate:(NSDate *)fromDate toDate:(NSDate *)toDate includesFutureDates:(BOOL)includesFutureDates;

@property (nonatomic, readonly, copy) NSDateFormatter *localizedDateFormatter;
- (NSDateFormatter *)localizedDateFormatterWithFormat:(NSString *)format;
- (NSString *)localizedDate:(NSDate *)date withFormat:(NSString *)format;

- (void)loadLocalizedStrings;

@end

@protocol BFLocalizationServiceObserver <BFServiceObserver>
@optional

- (void)localizationService:(id <BFLocalizationService>)service willChangePreferredLanguageFrom:(NSString *)fromPreferredLanguage to:(NSString *)toPreferredLanguage;
- (void)localizationService:(id <BFLocalizationService>)service didChangePreferredLanguageFrom:(NSString *)fromPreferredLanguage to:(NSString *)toPreferredLanguage;

- (void)localizationService:(id <BFLocalizationService>)service willChangeCountryCodeFrom:(NSString *)fromPreferredLanguage to:(NSString *)toPreferredLanguage;
- (void)localizationService:(id <BFLocalizationService>)service didChangeCountryCodeFrom:(NSString *)fromPreferredLanguage to:(NSString *)toPreferredLanguage;

@end

@interface BFLocalizationServiceImplementation : BFService <BFLocalizationService>

@property (nonatomic, readonly) NSDictionary *jsonStringDict;
- (void)loadLocalizedStrings;

@property (nonatomic, strong) BFCurrency *defaultCurrency;

@property (nonatomic, readonly) NSRecursiveLock *currencyFormatLock;
@property (nonatomic, readonly) NSNumberFormatter *currencyIntegralFormatter;
@property (nonatomic, readonly) NSNumberFormatter *currencyDecimalFormatter;

- (NSString *)positiveNumberPrefixForCurrencySign:(NSString *)currencySign plusSign:(NSString *)plusSign displayPlusSign:(BOOL)displayPlusSign;
- (NSString *)negativeNumberPrefixForCurrencySign:(NSString *)currencySign minusSign:(NSString *)minusSign;

@property (nonatomic, readonly) NSRecursiveLock *numberFormatLock;
@property (nonatomic, readonly) NSNumberFormatter *numberIntegralFormatter;
@property (nonatomic, readonly) NSNumberFormatter *numberDecimalFormatter;

- (NSString *)positiveNumberPrefixForPlusSign:(NSString *)plusSign displayPlusSign:(BOOL)displayPlusSign;
- (NSString *)negativeNumberPrefixForMinusSign:(NSString *)minusSign;

@property (nonatomic, readonly) NSRecursiveLock *dateFormatLock;
@property (nonatomic, readonly) NSDateFormatter *dateFormatter;

- (void)registerCurrencyCode:(NSString *)code sign:(NSString *)sign numberOfDecimals:(NSInteger)numberOfDecimals;
- (void)removeRegisteredCurrencyForCode:(NSString *)code;

+ (NSDictionary *)unwrapLocalizedStringsJSONDictionary:(NSDictionary *)dictionary;
@property (nonatomic, readonly, nullable) NSString *localizedStringsFilePath;

- (void)checkForLanguageUpdates;

- (void)didChangePreferredLanguageFrom:(NSString *)fromPreferredLanguage to:(NSString *)toPreferredLanguage;
- (void)didChangeCountryCodeFrom:(NSString *)fromPreferredLanguage to:(NSString *)toPreferredLanguage;

- (void)setAcceptLanguageForRequest:(NSMutableURLRequest *)request;

@end

#if !TARGET_INTERFACE_BUILDER

#define BFLocalizedString(key) [[[BFModuleCenter sharedCenter] moduleForProtocol:@protocol(BFLocalizationService)] localizedStringForKey:(key) defaultValue:nil]
#define BFLocalizedStringF(key, ...) [NSString stringWithFormat:(BFLocalizedString(key) ?: @""), ##__VA_ARGS__]

#define BFLocalizedAttributedStringF(attributes, key, ...) [NSAttributedString stringWithDefaultAttributes:attributes format:BFLocalizedString(key), ##__VA_ARGS__]

#define BFLocalizedPlural(pluralKey, pluralNumber) [[[BFModuleCenter sharedCenter] moduleForProtocol:@protocol(BFLocalizationService)] localizedPluralForKey:(pluralKey) number:(pluralNumber) defaultValue:nil]
#define BFLocalizedPluralF(pluralKey, pluralNumber, ...) [NSString stringWithFormat:BFLocalizedPlural(pluralKey, pluralNumber), (pluralNumber), ##__VA_ARGS__]

#else

#define BFLocalizedString(key) @""
#define BFLocalizedStringF(key, ...) @""

#define BFLocalizedAttributedStringF(attributes, key, ...) @""

#define BFLocalizedPlural(pluralKey, pluralNumber) @""
#define BFLocalizedPluralF(pluralKey, pluralNumber, ...) @""

#endif

NS_ASSUME_NONNULL_END
