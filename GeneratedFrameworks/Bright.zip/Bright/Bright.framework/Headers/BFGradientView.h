#import <UIKit/UIKit.h>
#import <Bright/BFGradient.h>
#import <Bright/BFCGAddtions.h>

NS_ASSUME_NONNULL_BEGIN

/**
 A simple view subclass with an optional background color in the form of a gradient.
 */
@interface BFGradientView : UIView

///------------------------------------------///
/// @name Configuring the gradient background
///------------------------------------------///

/**
 The direction in which to draw the background gradient.
 */
@property (nonatomic, assign) BFGradientDirection gradientDirection;

/**
 The gradient to draw the background with.
 */
@property (nonatomic, strong, nullable) BFGradient *backgroundGradient;

@end

NS_ASSUME_NONNULL_END
