#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

extern float const BFProgressViewIndeterminateProgress;

@interface BFProgressView : UIView

@property (nonatomic, assign) float progress;
- (void)setProgress:(float)progress animated:(BOOL)animated;

@property (nonatomic, assign, getter = isVisible) BOOL visible;

@end

NS_ASSUME_NONNULL_END
