#import "BFImageService.h"

NS_ASSUME_NONNULL_BEGIN

@interface BFImageServiceImplementation (Subclass)

- (nullable NSURL *)imageUrlForPath:(NSString *)path parameters:(nullable NSDictionary *)parameters;

@end

NS_ASSUME_NONNULL_END
