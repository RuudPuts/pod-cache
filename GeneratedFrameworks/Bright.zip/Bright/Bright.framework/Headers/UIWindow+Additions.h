#import <Bright/Bright.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIWindow (BFAdditions)

@property (nonatomic, strong, readonly, nullable) UIViewController *topMostViewController;

@end

NS_ASSUME_NONNULL_END
