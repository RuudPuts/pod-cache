#import <Bright/BFJihaaObject.h>
#import <Bright/BFJihaaObjectDecoder.h>

NS_ASSUME_NONNULL_BEGIN

@class BFJSONDecoder;

@interface BFJihaaObject (Decoding)

+ (nullable id)decodeFromJSON:(id)jsonObject type:(BFJihaaObjectDecoderType)type rootKeyPath:(nullable NSArray *)rootKeyPath attributes:(nullable NSSet<NSString*> *)attributes error:(NSError **)error;

+ (nullable instancetype)decodeFromJSONObject:(NSDictionary *)jsonObject attributes:(nullable NSSet<NSString*> *)attributes error:(NSError **)error;
+ (nullable NSArray *)decodeArrayFromJSONArray:(NSArray *)jsonArray attributes:(nullable NSSet<NSString*> *)attributes error:(NSError **)error;

+ (nullable instancetype)decodeFromFile:(NSString *)filePath attributes:(nullable NSSet<NSString*> *)attributes error:(NSError **)error;
+ (nullable NSArray *)decodeArrayFromFile:(NSString *)filePath attributes:(nullable NSSet<NSString*> *)attributes error:(NSError **)error;

+ (nullable instancetype)decodeFromFile:(NSString *)filePath rootKeyPath:(nullable NSArray *)rootKeyPath attributes:(nullable NSSet<NSString*> *)attributes error:(NSError **)error;
+ (nullable NSArray *)decodeArrayFromFile:(NSString *)filePath rootKeyPath:(nullable NSArray *)rootKeyPath attributes:(nullable NSSet<NSString*> *)attributes error:(NSError **)error;

+ (nullable instancetype)decodeFromData:(NSData *)data rootKeyPath:(nullable NSArray *)rootKeyPath attributes:(nullable NSSet<NSString*> *)attributes error:(NSError **)error;
+ (nullable NSArray *)decodeArrayFromData:(NSData *)data rootKeyPath:(nullable NSArray *)rootKeyPath attributes:(nullable NSSet<NSString*> *)attributes error:(NSError **)error;

+ (BFJihaaObjectDecoder *)objectDecoder;
+ (BFJihaaObjectDecoder *)arrayDecoder;

+ (BFJihaaObjectDecoder *)objectDecoderWithRootKeyPath:(nullable NSArray *)rootKeyPath;
+ (BFJihaaObjectDecoder *)arrayDecoderWithRootKeyPath:(nullable NSArray *)rootKeyPath;

+ (BFJihaaObjectDecoder *)detailsObjectDecoderWithRootKeyPath:(nullable NSArray *)rootKeyPath;
+ (BFJihaaObjectDecoder *)detailsArrayDecoderWithRootKeyPath:(nullable NSArray *)rootKeyPath;

@end

NS_ASSUME_NONNULL_END
