#import <Foundation/Foundation.h>

@class BFCurrency;

NS_ASSUME_NONNULL_BEGIN

@interface BFCurrencyNumber : NSObject <NSCopying, NSSecureCoding>

+ (instancetype)currencyNumberWithCurrency:(BFCurrency *)currency value:(long long)value;
+ (instancetype)currencyNumberWithCurrency:(BFCurrency *)currency decimalNumber:(NSNumber *)decimalNumber;
+ (instancetype)currencyNumberWithCurrency:(BFCurrency *)currency integralValue:(long long)integralValue decimalValue:(long long)decimalValue;

@property (nonatomic, copy) BFCurrency *currency;

@property (nonatomic, assign) long long value;
@property (nonatomic, readonly) double doubleValue;

@property (nonatomic, readonly, copy) NSString *formattedString;

@property (nonatomic, readonly) NSUInteger integerDigitCount;
@property (nonatomic, readonly) NSUInteger numberOfDigits;

@property (nonatomic, readonly, copy) BFCurrencyNumber *negativeNumber;
@property (nonatomic, readonly, copy) BFCurrencyNumber *positiveNumber;

@property (nonatomic, readonly) long long integralValue;
@property (nonatomic, readonly) long long decimalValue;

@end

NS_ASSUME_NONNULL_END
