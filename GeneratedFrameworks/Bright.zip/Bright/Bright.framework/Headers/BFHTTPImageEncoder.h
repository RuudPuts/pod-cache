#import <Bright/BFHTTPRequestOperation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSUInteger, BFImageRepresentation) {
	BFImageRepresentationPNG,
	BFImageRepresentationJPEG,
};

@interface BFHTTPImageEncoder : NSObject <BFHTTPBodyEncoder>

+ (instancetype)encoderWithImage:(UIImage *)image;
- (instancetype)initWithImage:(UIImage *)image NS_DESIGNATED_INITIALIZER;

- (instancetype)init NS_UNAVAILABLE;

@property (nonatomic, strong) UIImage *image;

@property (nonatomic, assign) BFImageRepresentation representation;
@property (nonatomic, assign) CGFloat jpegCompressionQuality;

@end

NS_ASSUME_NONNULL_END
