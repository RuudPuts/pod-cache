#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/**
 UIImage category for cropping and resizing the image. When cropping and resizing the image, the EXIF rotation information is taken into account, in order to get a correctly rotated result. This category can also be used, to simply rotate the UIImage to the correct orientation.
 */
@interface UIImage (BFCropResize)

///------------------------------------------///
/// @name Cropping an image
///------------------------------------------///

/**
 Crops the image based on a given crop rect
 
 This function does not maintain the aspect ratio of the crop rect. This means that if the intersection of the crop rect with the image, does not completely fill the crop rect, the final aspect ratio of the crop will be different from the crop rect.
 
 @param cropRect the rectangle specifying the crop, based on a coordinate system starting at the top left corner of the image
 @param maxSize the maximum size the crop can be, if the crop of the image is larger than this size, it will be resized to fit within these dimensions
 @param quality the quality of interpolation when resizing the image
 @return the cropped image
 */
- (UIImage *)croppedImage:(CGRect)cropRect maximumSize:(CGSize)maxSize interpolationQuality:(CGInterpolationQuality)quality;

/**
 Crops the image based on a given crop rect
 
 @param cropRect the rectangle specifying the crop, based on a coordinate system starting at the top left corner of the image
 @param maxSize the maximum size the crop can be, if the crop of the image is larger than this size, it will be resized to fit within these dimensions
 @param fixedAspectRatio if YES, the aspect ratio of the crop rect will be maintained. If the intersection between the image and the crop rect does not
 completely fill the crop rect, the part that does not intersect will be transparent
 @param backgroundColor this is the color that will be used to fill the transparent parts of the crop, can be nil to keep it transparent
 @param quality the quality of interpolation when resizing the image
 @return the cropped image
 */
- (UIImage *)croppedImage:(CGRect)cropRect maximumSize:(CGSize)maxSize fixedAspectRatio:(BOOL)fixedAspectRatio backgroundColor:(nullable UIColor *)backgroundColor interpolationQuality:(CGInterpolationQuality)quality;

/**
 Crops the image based on a given crop rect
 
 @param cropRect the rectangle specifying the crop, based on a coordinate system starting at the top left corner of the image
 @param maskPath a path that defines the clip mask that will be used when drawing the image. Using this path a more advanced cropping rectangle can be created. It can be combined together with a mask image.
 @param maskImage a image that defines the clip mask that will be used when drawing the image. Using this image a more advanced cropping rectangle can be created. It can be combined together with a mask path.
 @param maxSize the maximum size the crop can be, if the crop of the image is larger than this size, it will be resized to fit within these dimensions
 @param fixedAspectRatio if YES, the aspect ratio of the crop rect will be maintained. If the intersection between the image and the crop rect does not
 completely fill the crop rect, the part that does not intersect will be transparent
 @param backgroundColor this is the color that will be used to fill the transparent parts of the crop, can be nil to keep it transparent
 @param quality the quality of interpolation when resizing the image
 @return the cropped image
 */
- (UIImage *)croppedImage:(CGRect)cropRect maskPath:(nullable CGPathRef)maskPath maskImage:(nullable UIImage *)maskImage maximumSize:(CGSize)maxSize fixedAspectRatio:(BOOL)fixedAspectRatio backgroundColor:(nullable UIColor *)backgroundColor interpolationQuality:(CGInterpolationQuality)quality;

///------------------------------------------///
/// @name Resizing an image
///------------------------------------------///

/**
 Calculates the dimensions to use for scaling an image
 
 These dimensions will retain the image aspect ratio
 
 @param maxDimension the maximum size after scaling
 @param imageDimension the aspect ratio of the image
 @return the dimensions to use when scaling the image
 */
+ (CGSize)scaleDimension:(CGSize)maxDimension imageDimension:(CGSize)imageDimension;

/**
 Calculates the dimensions to use for scaling an image
 
 These dimensions will retain the image aspect ratio
 
 @param maxDimension the maximum size after scaling.
 @return The dimensions to use when scaling the image.
 */
- (CGSize)scaleDimension:(CGSize)maxDimension;

/**
 Returns a rescaled copy of the image, taking into account its orientation
 
 The image will be scaled disproportionately if necessary to fit the bounds specified by the parameter
 
 @param newSize the size to use for scaling the image
 @param quality the quality of the rescaled image
 @return the rescaled image
 */
- (UIImage *)resizedImage:(CGSize)newSize interpolationQuality:(CGInterpolationQuality)quality;

/**
 Resizes the image according to the given content mode, taking into account the image's orientation
 @param contentMode the UIViewContentMode to use for the resizing
 @param bounds the maximum size of the resized image
 @param quality the quality of the resized image
 @return the resized image
 */
- (UIImage *)resizedImageWithContentMode:(UIViewContentMode)contentMode bounds:(CGSize)bounds interpolationQuality:(CGInterpolationQuality)quality;

///------------------------------------------///
/// @name Rotating an image
///------------------------------------------///

/**
 Rotates the image based on the EXIF information
 
 Even though the difference between the rotated image and the original will not be visible on the iPhone itself (as it already rotates images before viewing), this function can be very useful for uploading an image to the Internet, making sure it is viewed in the correct orientation.
 
 @param quality the quality of the rotated image
 @return the rotated image
 */
- (UIImage *)rotatedImageByEXIFWithInterpolationQuality:(CGInterpolationQuality)quality;

///------------------------------------------///
/// @name Retrieving transform based on orientation
///------------------------------------------///

/**
 Returns the transform for the orientation of the image, based on a given size for the image.
 
 This transform can be used when drawing the image, to keep the actual orientation of the image, based on EXIF rotation.
 
 @param newSize The size the image that will be drawn.
 @return The transform to correctly display the image while drawing.
 */
- (CGAffineTransform)transformForOrientation:(CGSize)newSize;

@end

NS_ASSUME_NONNULL_END
