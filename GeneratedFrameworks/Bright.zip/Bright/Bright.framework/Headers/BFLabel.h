#import <UIKit/UIKit.h>
#import <Bright/BFDefines.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFLabel : UILabel

@property (nonatomic, assign) IBInspectable BOOL autoUpdatePreferredMaxLayoutWidth;

@property (nonatomic, assign) IBInspectable UIEdgeInsets contentPadding;
@property (nonatomic, assign) IBInspectable UIEdgeInsets contentMargins;

- (void)setFont:(nullable UIFont *)font compactSize:(CGFloat)compactSize regularSize:(CGFloat)regularSize;
@property (nonatomic, readonly) CGFloat compactFontSize;
@property (nonatomic, readonly) CGFloat regularFontSize;
- (void)resetSizeClassFontSizes;

@end

NS_ASSUME_NONNULL_END
