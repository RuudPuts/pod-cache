#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_OPTIONS(NSInteger, BFImageCacheType) {
    BFImageCacheTypeNone = 0,
    BFImageCacheTypeMemory = 1 << 0,
    BFImageCacheTypeDisk = 1 << 1,
    BFImageCacheTypeAll = BFImageCacheTypeMemory | BFImageCacheTypeDisk,
};

typedef void(^BFImageCacheRetrievalBlock)(UIImage * _Nullable image, BFImageCacheType sourceCacheType);

@interface BFImageCache : NSObject

///------------------------------------------///
/// @name Shared Cache
///------------------------------------------///

+ (instancetype)defaultCache;

///------------------------------------------///
/// @name Initialize
///------------------------------------------///

- (instancetype)initWithIdentifier:(NSString *)identifier NS_DESIGNATED_INITIALIZER;

///------------------------------------------///
/// @name Configure Cache
///------------------------------------------///

@property (nonatomic, readonly) NSString *identifier;

@property (nonatomic, assign) NSTimeInterval maximumCacheAge;

@property (nonatomic, assign) NSUInteger maximumMemoryCost;
@property (nonatomic, assign) NSUInteger maximumMemoryCount;

@property (nonatomic, assign) NSUInteger maximumDiskCacheSize;

///------------------------------------------///
/// @name Cache Keys
///------------------------------------------///

+ (nullable NSString *)imageKeyForURL:(NSURL *)url;

///------------------------------------------///
/// @name Retrieval
///------------------------------------------///

- (BOOL)containsImageForKey:(NSString *)key fromCacheType:(BFImageCacheType)cacheType;

- (nullable UIImage *)imageForKey:(NSString *)key fromCacheType:(BFImageCacheType)cacheType;
- (void)retrieveImageForKey:(NSString *)key fromCacheType:(BFImageCacheType)cacheType completion:(BFImageCacheRetrievalBlock)completion;

///------------------------------------------///
/// @name Manage Cache
///------------------------------------------///

- (void)setImage:(UIImage *)image forKey:(NSString *)key;
- (void)setImage:(UIImage *)image forKey:(NSString *)key destination:(BFImageCacheType)destination;

- (void)saveImageDataToDisk:(NSData *)imageData forKey:(NSString *)key;

- (void)removeImageForKey:(NSString *)key;
- (void)removeImageForKey:(NSString *)key fromCacheType:(BFImageCacheType)cacheType;

- (void)clearCacheWithType:(BFImageCacheType)type completion:(void(^ __nullable)(void))completion;
- (void)cleanupDiskCacheWithCompletion:(void(^ __nullable)(void))completion;

///------------------------------------------///
/// @name Cache Size
///------------------------------------------///

- (void)calculateDiskCacheSizeAndCountWithCompletion:(void(^)(NSUInteger size, NSUInteger count))completion;

@end

NS_ASSUME_NONNULL_END
