#import <Bright/BFImageView.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFImageView ()

@property (nonatomic, readonly) UIImageView *imageView;

- (void)updateForStateChanged;

- (void)updateForImageChange;
- (void)animateImage;

@end

NS_ASSUME_NONNULL_END
