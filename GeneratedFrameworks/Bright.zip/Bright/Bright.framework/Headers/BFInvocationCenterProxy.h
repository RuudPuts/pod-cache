#import "BFInvocationCenter.h"

NS_ASSUME_NONNULL_BEGIN

@interface BFInvocationCenterProxy : NSProxy

- (instancetype)initForInvocationCenter:(BFInvocationCenter *)center protocol:(Protocol *)protocol object:(id)object callbackOnMainThread:(BOOL)callbackOnMainThread;

@end

NS_ASSUME_NONNULL_END
