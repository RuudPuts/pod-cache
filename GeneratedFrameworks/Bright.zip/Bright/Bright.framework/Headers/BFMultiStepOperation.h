#import <Bright/BFOperation.h>

NS_ASSUME_NONNULL_BEGIN

typedef void(^BFMultiStepOperationStepCompletionBlock)(_Nullable id context);
typedef _Nullable id <BFOperation>(^BFMultiStepOperationBlock)(_Nullable id context, BFMultiStepOperationStepCompletionBlock stepCompletionBlock);

@interface BFMultiStepOperation : NSObject <BFOperation>

- (void)addStep:(BFMultiStepOperationBlock)block;
- (instancetype)runWithContext:(nullable id)context;

@end

NS_ASSUME_NONNULL_END
