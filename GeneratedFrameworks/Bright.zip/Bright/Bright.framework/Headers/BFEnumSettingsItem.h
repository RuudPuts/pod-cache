#import <Bright/BFSettingsItem.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFEnumSettingsItem : BFSettingsItem

@property (nonatomic, copy, nullable) NSArray *possibleValues;

@end

NS_ASSUME_NONNULL_END
