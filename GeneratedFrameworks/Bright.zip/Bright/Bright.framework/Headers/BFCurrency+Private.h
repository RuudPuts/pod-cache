#import <Bright/BFCurrency.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFCurrency ()

- (instancetype)initWithCode:(NSString *)code sign:(NSString *)sign numberOfDecimals:(NSUInteger)numberOfDecimals;

@end

NS_ASSUME_NONNULL_END
