#import <Bright/BFService.h>
#import <Bright/BFImageCache.h>

NS_ASSUME_NONNULL_BEGIN

@protocol BFImageService <BFServiceInterface>

- (nullable UIImage *)cachedImageForPath:(NSString *)path parameters:(nullable NSDictionary *)parameters;
- (nullable id <BFOperation>)getImageWithPath:(NSString *)path parameters:(nullable NSDictionary *)parameters success:(void(^ __nullable)(UIImage *image))success failure:(nullable BFServiceFailureHandler)failure;

@end

@interface BFImageServiceImplementation : BFService <BFImageService>

@property (nonatomic, readonly) BFImageCache *imageCache;

@end

NS_ASSUME_NONNULL_END
