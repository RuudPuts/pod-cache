#import <Bright/BFService.h>
#import <Bright/BFModuleCenter.h>

NS_ASSUME_NONNULL_BEGIN

extern NSString *const BFAccessibilityStringsFileName;
extern NSString *const BFAccessibilityStringsExtension;

/**
 *  'BFAccessibilityService' is a service used to retrieve localized strings for accessibility elements in the app. 
 */
@protocol BFAccessibilityService <BFServiceInterface>

@property (nonatomic, readonly, copy) NSString *preferredBundleLanguage;

- (NSString *)accessibilityStringForKey:(NSString *)key defaultValue:(nullable NSString *)defaultValue;

- (NSString *)accessibilityPluralForKey:(NSString *)key number:(NSNumber *)number defaultValue:(nullable NSString *)defaultValue;

@end

@interface BFAccessibilityServiceImplementation : BFService <BFAccessibilityService>

@property (nonatomic, readonly, copy, nullable) NSString *accessibilityStringsFilePath;

@end

#if !TARGET_INTERFACE_BUILDER

#define BFAccessibilityString(accessibilityKey) [[[BFModuleCenter sharedCenter] moduleForProtocol:@protocol(BFAccessibilityService)] accessibilityStringForKey:(accessibilityKey) defaultValue:@""]
#define BFAccessibilityStringF(accessibilityKey, ...) [NSString stringWithFormat:(BFAccessibilityString(accessibilityKey) ?: @""), ##__VA_ARGS__]

#define BFAccessibilityPlural(pluralKey, pluralNumber) [[[BFModuleCenter sharedCenter] moduleForProtocol:@protocol(BFAccessibilityService)] accessibilityPluralForKey:(pluralKey) number:(pluralNumber) defaultValue:nil]
#define BFAccessibilityPluralF(pluralKey, pluralNumber, ...) [NSString stringWithFormat:BFAccessibilityPlural(pluralKey, pluralNumber), (pluralNumber), ##__VA_ARGS__]

#else

#define BFAccessibilityString(accessibilityKey) @""
#define BFAccessibilityStringF(accessibilityKey, ...) @""

#define BFAccessibilityPlural(pluralKey, pluralNumber) @""
#define BFAccessibilityPluralF(pluralKey, pluralNumber, ...) @""

#endif

NS_ASSUME_NONNULL_END
