#import <Bright/BFSettingsCell.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFSettingsCell ()

@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UIView *accessoryView;
@property (weak, nonatomic) IBOutlet UIImageView *detailsImageView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *minimumAccessoryViewWidthConstraint;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *minimumTrailingSpaceAccessoryViewConstraint;

- (void)updateContentsAnimated:(BOOL)animated;
- (void)userDidChangeValue:(nullable id)value valueDescription:(nullable NSString *)valueDescription;
- (void)updateForClickable:(BOOL)clickable enabled:(BOOL)enabled;

@end

NS_ASSUME_NONNULL_END
