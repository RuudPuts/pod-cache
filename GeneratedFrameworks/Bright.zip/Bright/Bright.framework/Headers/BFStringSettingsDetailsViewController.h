#import <Bright/BFSettingsDetailsViewController.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFStringSettingsDetailsViewController : BFSettingsDetailsViewController

@property (nonatomic, assign) BOOL valueCanBeEmptyString;

@end

NS_ASSUME_NONNULL_END
