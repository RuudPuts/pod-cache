NS_ASSUME_NONNULL_BEGIN

#define BFUserInterfaceIdiom() [[UIDevice currentDevice] userInterfaceIdiom]

#define BFLocalizeTodo(string) (string)

#define BFRaiseNotImplementedInSubclassExeception() ({[NSException raise:NSInternalInconsistencyException format:@"The %@ method in %@ must be implemented by a subclass.", NSStringFromSelector(_cmd), NSStringFromClass([self class])]; nil;})

#define BFWeakSelf() \
    __weak typeof(self) weakSelf = self;

#define BFStrongSelf() \
    typeof(self) strongSelf = weakSelf; \
    if (!strongSelf) { \
        return; \
    }

#define BFStrongSelfReturn(returnValue) \
    typeof(self) strongSelf = weakSelf; \
    if (!strongSelf) { \
        return returnValue; \
    }

NS_ASSUME_NONNULL_END
