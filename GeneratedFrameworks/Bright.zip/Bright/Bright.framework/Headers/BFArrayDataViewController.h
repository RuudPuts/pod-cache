#import <Bright/BFDataViewController.h>

NS_ASSUME_NONNULL_BEGIN

/**
 The display type indicating the type of content view used by the `BFArrayDataViewController`.
 */
typedef NS_ENUM(NSUInteger, BFArrayDataViewControllerDisplayType) {
    BFArrayDataViewControllerDisplayTypeNone,
    BFArrayDataViewControllerDisplayTypeTableView,      /**< Indicates using a `UITableView` for displaying the data. */
    BFArrayDataViewControllerDisplayTypeCollectionView,  /**< Indicates using a `UICollectionView` for displaying the data. */
};

@protocol BFArrayDataViewControllerDelegate;

/**
 Generic view controller for loading an array of data objects.

 This view controller is specifically used for data that is shown in a table or collection view. When using a table view, it also supports loading data in steps (load more).

 Subclassing notes
 The BFArrayDataViewController's data is stored in the property array `data`. When the data is stored in another object make sure to override the following method.
 `dataItemForIndexPath:`
 */
@interface BFArrayDataViewController : BFDataViewController

///------------------------------------------///
/// @name Retrieving the display type
///------------------------------------------///

/**
 The display type with which the view controller was initialized.
 */
@property (nonatomic, assign, readonly) BFArrayDataViewControllerDisplayType displayType;

///------------------------------------------///
/// @name Managing the data object
///------------------------------------------///

/**
 This property overwrites the class type of the data object of `BFDataViewController` to be an `NSArray`.

 The overwrite is done as this view controller only works with an array of data objects.
 */
@property (nonatomic, strong, nullable) NSArray *data;

/**
 This method updates the NSArray *data object. Updating the NSArray *data using the property performs, by default, the
 reload of the view. Using this method, the reload of the view can be skipped.

 i.e.
 When updating the NSArray *data in a UITableView, during insertion or deletion, there is no need to reload
 the UITableView itself since it will be updated by the executed operation:

     [self.tableView beginUpdates];

     [self setData:<data> reloadingView:NO];
     [self.tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];

     [self.tableView endUpdates];
 */
- (void)setData:(NSArray *)data reloadingView:(BOOL)reload;

- (void)setData:(nullable NSArray *)data hasReachedEnd:(BOOL)hasReachedEnd totalCount:(nullable NSNumber *)totalCount;

@property (nonatomic, strong, readonly, nullable) NSNumber *totalDataCount;

- (nullable id)dataItemForIndexPath:(NSIndexPath *)indexPath;
- (nullable NSIndexPath *)indexPathForDataItem:(id)item;

///------------------------------------------///
/// @name Loading More
///------------------------------------------///

/**
 Property indicating whether the view controller is currently loading more data.
 */
@property (nonatomic, readonly, getter = isLoadingMore) BOOL loadingMoreData;

- (IBAction)setNeedsToLoadMoreData;
@property (nonatomic, assign, readonly) BOOL needsToLoadMoreData;

///------------------------------------------///
/// @name Setting the delegate
///------------------------------------------///

/**
 The delegate for the array data view controller.
 */
@property (nonatomic, weak) id <BFArrayDataViewControllerDelegate> delegate;

@end

/**
 The delegate for the `BFArrayDataViewController`.
 */
@protocol BFArrayDataViewControllerDelegate <NSObject>
@optional

///------------------------------------------///
/// @name Retrieving selected items callback
///------------------------------------------///

/**
 When implementing this method in the delegate, the delegate will receive a callback when an item is clicked.

 If this method is implemented, the `BFArrayDataViewController` will not perform the standard action of pushing in a details view controller. The delegate will then be responsible for taking an action.
 */
- (void)arrayDataViewController:(BFArrayDataViewController *)viewController didTapItem:(id)item atIndexPath:(NSIndexPath *)indexPath;

@end

NS_ASSUME_NONNULL_END
