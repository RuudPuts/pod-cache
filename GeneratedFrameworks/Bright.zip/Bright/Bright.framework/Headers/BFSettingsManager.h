#import <Bright/BFSingleton.h>
#import <Foundation/Foundation.h>

@class BFModule, BFSettingsItem;
@protocol BFSettingsChangeHandler;

NS_ASSUME_NONNULL_BEGIN

extern NSString *const BFSettingsItemValueDidChangeNotification;

@protocol BFSettingsItemDataSource <NSObject>

@property (nonatomic, readonly) NSUInteger numberOfSections;
- (NSUInteger)numberOfItemsInSection:(NSUInteger)section;
- (nullable NSString *)titleForSection:(NSUInteger)section;
- (nullable __kindof BFSettingsItem *)settingsItemAtIndexPath:(NSIndexPath *)indexPath;

@end

@interface BFSettingsManager : NSObject <BFSettingsItemDataSource>

BFSynthesizeSingletonInterface(sharedManager);

- (void)registerSettings:(NSArray<__kindof BFSettingsItem*> *)settings forId:(NSString *)settingsId changeHandler:(nullable id <BFSettingsChangeHandler>)handler;

- (nullable id)valueForSettingsItem:(BFSettingsItem *)settingsItem;
- (void)setValue:(nullable id)value forSettingsItem:(BFSettingsItem *)settingsItem;

- (void)resetAllSettings;
- (void)resetSettingsForItem:(BFSettingsItem *)settingsItem;
- (void)resetUserDefaults;
- (void)updateItemVisibility:(BFSettingsItem *)item;

- (NSArray<BFSettingsItem *> *)allSettingsItems;

@property (nonatomic, readonly) NSUInteger numberOfSections;
- (NSUInteger)numberOfItemsInSection:(NSUInteger)section;
- (NSString *)titleForSection:(NSUInteger)section;
- (nullable __kindof BFSettingsItem *)settingsItemAtIndexPath:(NSIndexPath *)indexPath;

@end

@protocol BFSettingsChangeHandler <NSObject>

- (void)didChangeValue:(nullable id)value forSettingsItem:(BFSettingsItem *)item;

@end

NS_ASSUME_NONNULL_END
