#import <Bright/BFSettingsItem.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFStringSettingsItem : BFSettingsItem

@property (nonatomic, assign) BOOL valueCanBeEmptyString;

@property (nonatomic, strong, nullable) NSString *currentValue;
@property (nonatomic, strong, nullable) NSString *defaultValue;

@end

NS_ASSUME_NONNULL_END
