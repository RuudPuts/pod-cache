NS_ASSUME_NONNULL_BEGIN

#ifdef DEBUG
	#define DLog(fmt, ...) printf("%s\n", [[NSString stringWithFormat:(@"DEBUG %s, line %d: " fmt), __PRETTY_FUNCTION__, __LINE__, ##__VA_ARGS__] cStringUsingEncoding:NSUTF8StringEncoding]);
#else
	#define DLog(...)
#endif

NS_ASSUME_NONNULL_END
