#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/**
 Category for creating a dictionary from query parameters.
 */
@interface NSString (BFQueryParameters)

///------------------------------------------///
/// @name Retrieving query parameters
///------------------------------------------///

/**
 Returns a dictionary containing the query parameters in the current string.
 */
@property (nonatomic, readonly, copy) NSDictionary *queryToDictionary;

- (NSDictionary *)queryParametersWithDelimiter:(NSString *)deLimiter;
@end

@interface NSURLRequest (BFQueryParameters)

@property (nonatomic, copy, readonly, nullable) NSDictionary *queryParameters;

@end

/**
 Category on `NSMutableURLRequest` to retrieve and modify the URL query parameters as an `NSDictionary`.
 */
@interface NSMutableURLRequest (BFQueryParameters)

///------------------------------------------///
/// @name Managing URL query parameters
///------------------------------------------///

/**
 The URL query parameters in `NSDictionary` format.
 
 The parameters can both be obtained and set.
 */
@property (nonatomic, copy, readwrite, nullable) NSDictionary *queryParameters;

/**
 This method adds query parameters to existing ones, overwriting any duplicate keys.
 
 @param parameters The query parameters to add.
 */
- (void)addQueryParameters:(NSDictionary *)parameters;

@end

NS_ASSUME_NONNULL_END
