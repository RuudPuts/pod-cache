#import <Foundation/Foundation.h>

@class BFSettingsItem;

NS_ASSUME_NONNULL_BEGIN

typedef NSInteger BFModuleStartupPriority;
extern BFModuleStartupPriority const BFModuleStartupPriorityHighest;
extern BFModuleStartupPriority const BFModuleStartupPriorityDefault;
extern BFModuleStartupPriority const BFModuleStartupPriorityLowest;

@protocol BFModuleInterface <NSObject>

@end

@protocol BFModuleObserver <NSObject>
@end

@interface BFModule : NSObject <BFModuleInterface>

@property (nonatomic, copy, readonly, nullable) NSString *id;
@property (nonatomic, strong, readonly, nullable) Protocol *interface;

///------------------------------------------///
/// @name Setting up the module item
///------------------------------------------///

@property (nonatomic, readonly) NSInteger startupPriority;

@property (nonatomic, assign, readonly, getter = isSetup) BOOL setup;
- (void)setup;
- (BOOL)needsToBeSetupForSelector:(SEL)aSelector;

@property (nonatomic, assign, readonly, getter = isStarted) BOOL started;
- (void)start;
- (void)stop;
- (BOOL)needsToBeStartedForSelector:(SEL)aSelector;

///------------------------------------------///
/// @name Determining dependencies
///------------------------------------------///

@property (nonatomic, readonly) NSArray<Protocol*> *dependencies;

///------------------------------------------///
/// @name Managing settings
///------------------------------------------///

@property (nonatomic, readonly) NSArray<BFSettingsItem*> *settings;
- (void)didChangeValue:(nullable id)value forSettingsItem:(BFSettingsItem *)item;

///------------------------------------------///
/// @name Observing
///------------------------------------------///

@property (nonatomic, readonly, strong, nullable) Protocol *observableProtocol;
@property (nonatomic, readonly, strong) id observersProxy;
- (id)observersProxyWithCallbackOnMainThread:(BOOL)callbackOnMainThread;

@end

NS_ASSUME_NONNULL_END
