#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFSettingsValue : NSObject

+ (instancetype)valueWithTitle:(NSString *)title value:(id)value;

@property (nonatomic, copy) NSString *title;
@property (nonatomic, strong) id value;

@end

NS_ASSUME_NONNULL_END
