#import <Bright/BFJihaaPropertyTransformer.h>

@interface BFDemoJSONDataTransformer : BFJihaaPropertyTransformer

@end
