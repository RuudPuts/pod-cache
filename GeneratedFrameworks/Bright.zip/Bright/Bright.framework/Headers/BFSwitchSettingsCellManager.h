#import <Bright/BFSettingsCellManager.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFSwitchSettingsCellManager : BFSettingsCellManager

@end

NS_ASSUME_NONNULL_END
