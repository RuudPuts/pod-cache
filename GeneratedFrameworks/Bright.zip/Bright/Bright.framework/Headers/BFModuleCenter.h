#import <Bright/BFSingleton.h>
#import <Foundation/Foundation.h>

@class BFModule;

NS_ASSUME_NONNULL_BEGIN

#define BFGetModule(moduleProtocol) (id <moduleProtocol>)[[BFModuleCenter sharedCenter] moduleForProtocol:@protocol(moduleProtocol)]
#define BFModuleExists(moduleProtocol) ([[BFModuleCenter sharedCenter] moduleForProtocol:@protocol(moduleProtocol)] ? YES : NO)

@interface BFModuleCenter : NSObject

BFSynthesizeSingletonInterface(sharedCenter);

- (nullable id)moduleWithId:(NSString *)moduleId;
- (nullable id)moduleForProtocol:(Protocol *)protocol;

- (nullable id)moduleForProtocolWithName:(NSString *)protocolName;

- (void)addObserver:(NSObject *)observer forModule:(Protocol *)protocol;
- (void)removeObserver:(NSObject *)observer forModule:(Protocol *)protocol;

@end

NS_ASSUME_NONNULL_END
