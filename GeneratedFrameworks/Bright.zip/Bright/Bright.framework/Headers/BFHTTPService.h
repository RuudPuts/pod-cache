#import <Bright/BFService.h>
#import <Bright/BFURLSettingsItem.h>
#import <Bright/BFStringSettingsItem.h>
#import <Bright/BFBoolSettingsItem.h>
#import <Bright/BFNumberSettingsItem.h>

NS_ASSUME_NONNULL_BEGIN

extern NSString *const BFHTTPServiceRequestIdentifierKey;

typedef void (^BFURLRequestModifierBlock)(NSMutableURLRequest *request);
typedef void (^BFHTTPRequestOperationModifierBlock)(BFHTTPRequestOperation *operation);
typedef void (^BFHTTPResponseHandlerBlock)(NSHTTPURLResponse *response, BFHTTPRequestOperation *operation);
typedef BOOL (^BFHTTPRequestOperationErrorHandlerBlock)(BFError *error, BFHTTPRequestOperation *operation);

@protocol BFHTTPService <BFServiceInterface>

@property (nonatomic, readonly, nullable) NSURL *baseURL;
- (NSString *)relativeToBaseURLForURL:(NSString *)url;

- (nullable NSURL *)urlWithPath:(NSString *)path parameters:(nullable NSDictionary *)parameters;

- (id)addRequestModifier:(BFURLRequestModifierBlock)block;
- (void)removeRequestModifier:(id)identifier;

- (id)addOperationModifier:(BFHTTPRequestOperationModifierBlock)block;
- (void)removeOperationModifier:(id)identifier;

- (id)addErrorHandlerBlock:(BFHTTPRequestOperationErrorHandlerBlock)block;
- (void)removeErrorHandlerBlock:(id)block;

- (id)addResponseHandlerBlock:(BFHTTPResponseHandlerBlock)block;
- (void)removeResponseHandlerBlock:(id)block;

- (NSMutableURLRequest *)requestWithURL:(NSURL *)url;
- (NSMutableURLRequest *)requestWithMethod:(NSString *)method
                                      path:(NSString *)path
                                parameters:(nullable NSDictionary *)parameters;

- (BFHTTPRequestOperation *)operationWithMethod:(NSString *)method
                                           path:(NSString *)path
                                     parameters:(nullable NSDictionary *)parameters
                                        success:(nullable BFHTTPRequestOperationSuccessBlock)success
                                        failure:(nullable BFHTTPRequestOperationFailureBlock)failure;

- (BFHTTPRequestOperation *)operationWithRequest:(NSURLRequest *)urlRequest
                                         success:(nullable BFHTTPRequestOperationSuccessBlock)success
                                         failure:(nullable BFHTTPRequestOperationFailureBlock)failure;

- (id)operationWithRequest:(NSURLRequest *)urlRequest
                     class:(Class)operationClass
                   success:(nullable BFHTTPRequestOperationSuccessBlock)success
                   failure:(nullable BFHTTPRequestOperationFailureBlock)failure;

- (id <BFHTTPBodyEncoder>)encoderForBody:(id)body request:(nullable NSURLRequest *)request;

- (void)enqueueOperation:(BFHTTPRequestOperation *)operation;
- (void)enqueueOperation:(BFHTTPRequestOperation *)operation queue:(nullable NSOperationQueue *)queue;

- (BFHTTPRequestOperation *)getPath:(NSString *)path
                         parameters:(nullable NSDictionary *)parameters
                            decoder:(nullable id <BFHTTPRequestResponseDecoder>)decoder
                            success:(nullable BFHTTPRequestOperationSuccessBlock)success
                            failure:(nullable BFHTTPRequestOperationFailureBlock)failure;

- (BFHTTPRequestOperation *)postPath:(NSString *)path
                                body:(nullable id)body
                             decoder:(nullable id <BFHTTPRequestResponseDecoder>)decoder
                             success:(nullable BFHTTPRequestOperationSuccessBlock)success
                             failure:(nullable BFHTTPRequestOperationFailureBlock)failure;

- (BFHTTPRequestOperation *)putPath:(NSString *)path
                               body:(nullable id)body
                            decoder:(nullable id <BFHTTPRequestResponseDecoder>)decoder
                            success:(nullable BFHTTPRequestOperationSuccessBlock)success
                            failure:(nullable BFHTTPRequestOperationFailureBlock)failure;

- (BFHTTPRequestOperation *)deletePath:(NSString *)path
                               decoder:(nullable id <BFHTTPRequestResponseDecoder>)decoder
                               success:(nullable BFHTTPRequestOperationSuccessBlock)success
                               failure:(nullable BFHTTPRequestOperationFailureBlock)failure;

- (BFHTTPRequestOperation *)downloadPath:(NSString *)path
                              parameters:(nullable NSDictionary *)parameters
                              toFilePath:(NSString *)filePath
                                progress:(nullable BFHTTPRequestOperationProgressBlock)progress
                                 success:(nullable BFHTTPRequestOperationSuccessBlock)success
                                 failure:(nullable BFHTTPRequestOperationFailureBlock)failure;

- (BFHTTPRequestOperation *)uploadPath:(NSString *)path
                            withMethod:(NSString *)method
                          fromFilePath:(NSString *)filePath
                               decoder:(nullable id <BFHTTPRequestResponseDecoder>)decoder
                              progress:(nullable BFHTTPRequestOperationProgressBlock)progress
                               success:(nullable BFHTTPRequestOperationSuccessBlock)success
                               failure:(nullable BFHTTPRequestOperationFailureBlock)failure;

@property (nonatomic, readonly, copy) NSDate *serverDate;

- (void)cancelAllRequests;

@end

@protocol BFHTTPServiceObserver <BFServiceObserver>
@optional

- (void)httpService:(id <BFHTTPService>)service didChangeBaseURL:(nullable NSURL *)baseURL;

@end

@interface BFHTTPServiceImplementation : BFService <BFHTTPService>

@property (nonatomic, readonly) NSOperationQueue *defaultOperationQueue;

@property (nonatomic, strong) BFURLSettingsItem <BFHiddenSetting> *baseURLSetting;

@property (nonatomic, strong) BFBoolSettingsItem <BFHiddenSetting> *delayRequestOperations;
@property (nonatomic, strong) BFNumberSettingsItem <BFHiddenSetting> *delayRequestOperationsTime;

@end

NS_ASSUME_NONNULL_END
