#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, BFErrorCode) {
    BFErrorCodeGenericError,
    BFErrorCodeServerError,
    BFErrorCodeNoInternetError,
    BFErrorCodeConnectionError,
    BFErrorCodeCancelled,
};

extern NSString *const BFErrorDomain;

extern NSString *const BFErrorTitleKey;
extern NSString *const BFErrorMessageKey;
extern NSString *const BFErrorIconKey;

@interface BFError : NSError <UIAccessibilityIdentification>

- (instancetype)init NS_UNAVAILABLE;
- (instancetype)initWithDomain:(NSString *)domain code:(NSInteger)code userInfo:(nullable NSDictionary *)dict NS_UNAVAILABLE;
+ (instancetype)errorWithDomain:(NSString *)domain code:(NSInteger)code userInfo:(nullable NSDictionary *)dict NS_UNAVAILABLE;

- (instancetype)initWithCode:(BFErrorCode)code userInfo:(nullable NSDictionary *)dict NS_DESIGNATED_INITIALIZER;
+ (instancetype)errorWithCode:(BFErrorCode)code userInfo:(nullable NSDictionary *)dict;

- (instancetype)initWithNSError:(NSError*)error;
+ (instancetype)errorWithNSError:(NSError*)error;

@property (readonly) BFErrorCode code;

@property (nonatomic, readonly) NSInteger httpStatusCode;

@property (nonatomic, assign, readonly) BOOL handledByGlobalErrorHandler;
- (void)markAsHandled;

@property (nonatomic, readonly, nullable) NSError *originalError;

@property (nonatomic, readonly, nullable) NSString *dialogTitle;
@property (nonatomic, readonly, nullable) NSString *dialogText;

@property (nonatomic, readonly, nullable) UIImage *icon;
@property (nonatomic, readonly, nullable) NSString *labelText;

@end

NS_ASSUME_NONNULL_END
