#import <Bright/BFJihaaObject.h>

NS_ASSUME_NONNULL_BEGIN

@class BFJihaaProperty;

@interface BFJihaaObject (Properties)

+ (NSDictionary *)_jihaaProperties;
+ (id <BFJihaaPropertyTransformer>)_transformerForProperty:(BFJihaaProperty *)property;

@end

NS_ASSUME_NONNULL_END
