#import <Bright/BFDataViewController.h>
#import <Bright/BFViewController+Subclass.h>
#import <Bright/BFOperation.h>

NS_ASSUME_NONNULL_BEGIN

extern NSString *const BFDataViewControllerPlaceholderData;

/**
 The private interface which can be used by subclasses of the `BFDataViewController`.
 */
@interface BFDataViewController ()

///------------------------------------------///
/// @name Content View
///------------------------------------------///

@property (nonatomic, strong, null_unspecified) IBOutlet UIView *contentView;

///------------------------------------------///
/// @name Retrieving the data
///------------------------------------------///

@property (nonatomic, readonly) BOOL shouldRetrieveData;

@property (nonatomic, assign) BOOL retrieveDataOnlyWhenVisible;

/**
 This method should be implemented by a subclass and is responsible for the actual retrieval of data.
 
 The retrieval can either be synchronous or asynchronous. This method will however be called on the main thread, so make sure not to block it.
 
 @param success The success block. The data parameter will be used to update the `data` property with.
 @param failure The failure block which should be called in case of an error during retrieval.
 @return The `BFOperation` allowing to cancel the retrieval, can be `nil` if the operation can not be cancelled.
 */
- (nullable id <BFOperation>)retrieveDataWithSuccess:(void(^__nullable)(id data))success failure:(void(^__nullable)(BFError *error))failure;

- (void)cancelRetrieval;

- (void)updateViewForDataChange;
- (void)updateForDataRetrievalStateChange;

@property (nonatomic, readonly) BOOL shouldHideContent;
- (void)updateViewVisibility;

///------------------------------------------///
/// @name Error handling
///------------------------------------------///

/**
 Called when retrieving data has failed.
 
 This method should not be called directly and should generally not be overwritten.
 
 By default this method will show an error view with a retry button.
 
 @param error The error that occurred.
 */
- (void)didFailToRetrieveDataWithError:(BFError *)error;

/**
 Returns the message for the error view shown by `didFailToRetrieveDataWithError:`.
 
 @param error The error that occurred.
 @return The message for the error view.
 */
- (nullable NSString *)messageForDataRetrievalError:(BFError *)error;

/**
 Returns the retry button title for the error view shown by `didFailToRetrieveDataWithError:`.
 
 When returning `nil` from this method, the retry button will not be visible.
 
 @param error The error that occurred.
 @return The retry button title for the error view or `nil` if the button should be hidden.
 */
- (nullable NSString *)retryActionTitleForDataRetrievalError:(BFError *)error;

/**
 Returns the retry action callback for the error view shown by `didFailToRetrieveDataWithError:`.
 
 When returning `NULL` from this method, the retry button will not be visible.
 
 @param error The error that occurred.
 @return The retry action callback for the error view or `NULL` if the button should be hidden.
 */
- (nullable BFMessageViewCallback)retryActionCallbackForDataRetrievalError:(BFError *)error;

@end

NS_ASSUME_NONNULL_END
