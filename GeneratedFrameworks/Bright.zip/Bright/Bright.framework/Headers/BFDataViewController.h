#import <Bright/BFViewController.h>

NS_ASSUME_NONNULL_BEGIN

/**
 Generic view controller for loading data.

 The data loaded by this view controller generally consists of a single data object. The view controller is generally used as a details view controller. For data that consists of an array of objects, use the `BFArrayDataViewController` instead.
 */
@interface BFDataViewController : BFViewController

///------------------------------------------///
/// @name Managing the data object
///------------------------------------------///

/**
 Property indicating whether the view controller is currently retrieving data.
 */
@property (nonatomic, readonly, getter = isRetrievingData) BOOL retrievingData;

/**
 The data object which will be set after that data has been retrieved.

 The class type of this object is determined by the subclass.
 */
@property (nonatomic, strong, nullable) id data;

/**
 This method should be called when the data needs to be reloaded.

 When this method is called, the `data` property is set to `nil`. If the view is currently visible the `retrieveData` method is called directly, otherwise the `retrieveData` method will be called in `viewWillAppear:`.
 */
- (IBAction)setNeedsDataReload;

/**
 This method updates the NSArray *data object. Updating the NSArray *data using the property performs, by default, the
 reload of the view. Using this method, the reload of the view can be skipped.

 i.e.
 When updating the NSArray *data in a UITableView, during insertion or deletion, there is no need to reload
 the UITableView itself since it will be updated by the executed operation:

 [self.tableView beginUpdates];

 [self setData:<data> reloadingView:NO];
 [self.tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];

 [self.tableView endUpdates];
 */
- (void)setData:(id)data reloadingView:(BOOL)reload;

@property (nonatomic, assign, readonly) BOOL needsDataReload;

///------------------------------------------///
/// @name Visiblity Configuration
///------------------------------------------///

@property (nonatomic, assign) BOOL shouldFadeInContent;

@end

NS_ASSUME_NONNULL_END
