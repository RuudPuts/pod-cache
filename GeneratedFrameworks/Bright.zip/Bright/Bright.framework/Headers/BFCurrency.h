#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFCurrency : NSObject <NSCopying, NSSecureCoding>

+ (BFCurrency *)currencyWithCode:(NSString *)code;
- (instancetype)initWithCode:(NSString *)code;

@property (nonatomic, readonly) NSString *code;
@property (nonatomic, readonly) NSString *sign;

@property (nonatomic, assign) NSUInteger numberOfDecimals;

@end

NS_ASSUME_NONNULL_END
