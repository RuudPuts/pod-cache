NS_ASSUME_NONNULL_BEGIN

@protocol BFBootstrapDelegate, BFViewController;
@class BFSettingsItem, BFModuleConfiguration, BFGroupSettingsItem;

typedef void (^BFBootstrapRestorationHandler)(NSArray * _Nullable restorationHandler);
typedef BOOL (^BFBootstrapOpenURLHandler)(NSURL *url, NSString * _Nullable sourceApplication, id annotation);
typedef BOOL (^BFBootstrapUserActivityHandler)(NSUserActivity *userActivity, BFBootstrapRestorationHandler restorationHandler);

extern NSString *const BFBootstrapDidRegisterForRemoteNotificationsNotification;
extern NSString *const BFBootstrapDidFailToRegisterForRemoteNotificationsNotification;
extern NSString *const BFBootstrapDidCleanAllAppDataNotification;
extern NSString *const BFBootstrapDidSetupWindowNotification;
extern NSString *const BFBootstrapWillRestartNotification;

@interface BFBootstrap : NSObject

+ (BFBootstrap *)sharedBootstrap;

@property (nonatomic, readonly, nullable) UIWindow *window;
@property (nonatomic, readonly, nullable) UIViewController *rootViewController;
@property (nonatomic, readonly, nullable) UIViewController *topViewController;

- (void)clearAllAppData;
- (void)startBootstrap;
- (void)restartBootstrap;

@property (nonatomic, readonly) BOOL notificationsEnabled;
@property (nonatomic, readonly, nullable) NSData *remoteNotificationsDeviceToken;
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
- (void)registerForRemoteNotificationTypes:(UIUserNotificationType)types;
#pragma clang diagnostic pop

@property (nonatomic, weak) id <BFBootstrapDelegate> delegate;

@property (nonatomic, readonly, nullable) BFGroupSettingsItem *dynamicModuleSettingsGroup;

@property (nonatomic, readonly) BOOL didFinishLaunching;

@end

@protocol BFBootstrapObserver <NSObject>
@optional

- (void)bootstrap:(BFBootstrap *)bootstrap didReceiveRemoteNotification:(NSDictionary *)remoteNotification;
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
- (void)bootstrap:(BFBootstrap *)bootstrap didReceiveLocalNotification:(UILocalNotification *)localNotification;
#pragma clang diagnostic pop

@end

@protocol BFBootstrapDelegate <NSObject>
@required

- (BFModuleConfiguration *)moduleConfigurationForBootstrap:(BFBootstrap *)bootstrap;

@optional

- (void)bootstrapWillRestart:(BFBootstrap *)bootstrap;

- (void)bootstrapDidCreateSettingsItems:(BFBootstrap *)bootstrap;
- (void)bootstrap:(BFBootstrap *)bootstrap didChangeValue:(nullable id)value forSettingsItem:(BFSettingsItem *)item;

- (void)bootstrapDidCreateMenuItems:(BFBootstrap *)bootstrap;

- (BOOL)bootstrap:(BFBootstrap *)bootstrap application:(UIApplication *)application didFinishLaunchingWithOptions:(nullable NSDictionary *)launchOptions;
- (BOOL)bootstrap:(BFBootstrap *)bootstrap application:(UIApplication *)application openURL:(NSURL *)url options:(NSDictionary<NSString *, id> *)options;
- (BOOL)bootstrap:(BFBootstrap *)bootstrap application:(UIApplication *)application continueUserActivity:(NSUserActivity *)userActivity restorationHandler:(void (^)(NSArray<id<UIUserActivityRestoring>> * _Nullable))restorationHandler;

- (void)bootstrapWillSetupApplicationWindow:(BFBootstrap *)bootstrap;
- (void)bootstrapDidSetupApplicationWindow:(BFBootstrap *)bootstrap;

- (void)skinUIAppearanceForBootstrap:(BFBootstrap *)bootstrap;

- (void)bootstrap:(BFBootstrap *)bootstrap didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken;
- (void)bootstrap:(BFBootstrap *)bootstrap didFailToRegisterForRemoteNotificationsWithError:(NSError *)error;

- (void)bootstrap:(BFBootstrap *)bootstrap applicationDidEnterBackground:(UIApplication *)application;
- (void)bootstrap:(BFBootstrap *)bootstrap applicationDidBecomeActive:(UIApplication *)application;
- (void)bootstrap:(BFBootstrap *)bootstrap applicationWillTerminate:(UIApplication *)application;

- (UIInterfaceOrientationMask)bootstrap:(BFBootstrap *)bootstrap application:(UIApplication *)application supportedInterfaceOrientationsForWindow:(nullable UIWindow *)window;

- (void)bootstrap:(BFBootstrap *)bootstrap performActionForShortcutItem:(UIApplicationShortcutItem *)shortcutItem completionHandler:(void (^)(BOOL))completionHandler;

@end

NS_ASSUME_NONNULL_END
