#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, BFPageCollectionViewLayoutDirection) {
    BFPageCollectionViewLayoutDirectionHorizontal,
    BFPageCollectionViewLayoutDirectionVertical,
};

typedef NS_ENUM(NSInteger, BFPageCollectionViewLayoutHorizontalCellAlignment) {
    BFPageCollectionViewLayoutHorizontalCellAlignmentCenter,
    BFPageCollectionViewLayoutHorizontalCellAlignmentLeft,
    BFPageCollectionViewLayoutHorizontalCellAlignmentRight,
};

@interface BFPageCollectionViewLayout : UICollectionViewLayout

@property (nonatomic, assign) CGFloat itemSize;
@property (nonatomic, assign) CGFloat itemSpacing;
@property (nonatomic, assign) CGFloat itemScalingFactor;
@property (nonatomic, assign) CGFloat itemOffset;
@property (nonatomic, assign) BFPageCollectionViewLayoutDirection direction;
@property (nonatomic, assign) BFPageCollectionViewLayoutHorizontalCellAlignment horizontalAlignment;
/**
 Boolean that indicates if snap to cell is enabled.
 @discussion If the value of this property is YES, the layout view stops on multiples of the cells’s bounds when the user scrolls. The default value is YES.
 */
@property (nonatomic, assign) BOOL snapToCellEnabled;

- (CGPoint)offsetForPageAtIndex:(NSUInteger)pageIndex;

- (NSInteger)pageIndexForOffset:(CGFloat)offset;
@property (nonatomic, readonly) NSUInteger pageIndexForCurrentContentOffset;

@end

NS_ASSUME_NONNULL_END
