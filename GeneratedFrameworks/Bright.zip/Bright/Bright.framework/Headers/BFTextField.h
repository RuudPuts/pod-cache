#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFTextField : UITextField

@property (nonatomic, assign) IBInspectable UIEdgeInsets inputRectInsets;

@property (nonatomic, strong, nullable) IBInspectable UIColor *placeholderColor;

- (void)setFont:(nullable UIFont *)font compactSize:(CGFloat)compactSize regularSize:(CGFloat)regularSize;
@property (nonatomic, readonly) CGFloat compactFontSize;
@property (nonatomic, readonly) CGFloat regularFontSize;
- (void)resetSizeClassFontSizes;

@end

NS_ASSUME_NONNULL_END
