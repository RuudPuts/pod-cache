#import "BFProgressView.h"
#import <Bright/BFActivityIndicatorView.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFProgressView ()

@property (nonatomic, weak) IBOutlet UIView <BFActivityIndicatorView> *activityIndicatorView;

- (void)updateForVisiblityChangeAnimated:(BOOL)animated;

@end

NS_ASSUME_NONNULL_END
