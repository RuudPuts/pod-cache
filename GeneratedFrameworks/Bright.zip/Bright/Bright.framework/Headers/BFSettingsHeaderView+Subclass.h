#import "BFSettingsHeaderView.h"

NS_ASSUME_NONNULL_BEGIN

@interface BFSettingsHeaderView ()

@property (nonatomic, weak) IBOutlet UILabel *titleLabel;

@end

NS_ASSUME_NONNULL_END
