#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFNibWrapperView : UIView

@property (nonatomic, readonly) id contentView;
@property (nonatomic, readonly, strong) Class contentViewClass;
@property (nonatomic, readonly, strong) NSString *contentViewNibName;

@end

NS_ASSUME_NONNULL_END
