#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface UILabel (LocalizationKeys)

- (void)setTextWithLocalizationKey:(NSString *)key;

- (void)setFormattedTextWithLocalizationKey:(NSString *)key, ... ;

@end

NS_ASSUME_NONNULL_END
