#import <Bright/BFService.h>

NS_ASSUME_NONNULL_BEGIN

@protocol BFErrorService <BFServiceInterface>

- (nullable BFError *)errorForServerResponse:(NSURLResponse *)response operation:(BFURLConnectionOperation *)operation json:(nullable id)jsonObject;

- (nullable NSString *)dialogTitleForError:(BFError *)error;
- (nullable NSString *)dialogTextForError:(BFError *)error;

- (nullable UIImage *)iconForError:(BFError *)error;
- (nullable NSString *)labelTextForError:(BFError *)error;

@end

NS_ASSUME_NONNULL_END
