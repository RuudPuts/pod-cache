#import <Bright/BFJSONDecoder.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFJSONMultiDecoder : BFJSONDecoder

+ (instancetype)decoderWithDecoders:(NSDictionary<NSString*, BFJSONDecoder*> *)decoders;
@property (nonatomic, readonly) NSDictionary<NSString*, BFJSONDecoder*> *decoders;

@end

NS_ASSUME_NONNULL_END
