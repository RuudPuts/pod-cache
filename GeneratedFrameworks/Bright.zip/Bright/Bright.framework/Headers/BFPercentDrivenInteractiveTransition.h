#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFPercentDrivenInteractiveTransition : NSObject <UIViewControllerInteractiveTransitioning>

- (instancetype)initWithAnimator:(nullable id <UIViewControllerAnimatedTransitioning>)animator NS_DESIGNATED_INITIALIZER;

@property (nonatomic, strong, nullable) id <UIViewControllerAnimatedTransitioning> animator;

@property (readonly) CGFloat duration;

@property (readonly) CGFloat percentComplete;

@property (nonatomic, assign) CGFloat completionSpeed;
@property (nonatomic, assign) UIViewAnimationCurve completionCurve;

- (void)updateInteractiveTransition:(CGFloat)percentComplete;
- (void)cancelInteractiveTransition;
- (void)finishInteractiveTransition;

- (BOOL)addAnimateAlongsideView:(UIView *)view;

@end

NS_ASSUME_NONNULL_END
