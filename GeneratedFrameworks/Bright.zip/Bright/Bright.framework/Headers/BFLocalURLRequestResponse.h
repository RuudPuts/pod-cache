#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFLocalURLRequestResponse : NSObject <NSSecureCoding>

@property (nonatomic, strong, nullable) NSURLResponse *urlResponse;
@property (nonatomic, strong, nullable) NSData *data;

@property (nonatomic, strong, nullable) NSDate *timestamp;

@end

NS_ASSUME_NONNULL_END
