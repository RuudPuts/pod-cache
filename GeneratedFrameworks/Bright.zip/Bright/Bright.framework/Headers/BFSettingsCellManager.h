#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>
#import <UIKit/UIKit.h>

@protocol BFViewController;
@class BFSettingsItem, BFSettingsCell, BFSettingsViewController;

NS_ASSUME_NONNULL_BEGIN

extern CGFloat const BFSettingsCellDefaultHeight;

@protocol BFSettingsCellManager <NSObject>

@required

- (id)settingsCellNibOrClassForItemClass:(Class)itemClass;
- (NSString *)cellIdentifierForItem:(BFSettingsItem *)item;

@optional

- (void)setupCell:(BFSettingsCell *)cell forItem:(BFSettingsItem *)item;

- (BOOL)hasDetailsViewControllerForItem:(BFSettingsItem *)item;
- (UIViewController <BFViewController> *)detailsViewControllerForItem:(BFSettingsItem *)item;

- (BOOL)canPerformSelectActionForItem:(BFSettingsItem *)item;
- (void)performSelectActionForSettingsViewController:(BFSettingsViewController *)settingsViewController cell:(BFSettingsCell *)cell item:(BFSettingsItem *)item;

- (CGFloat)cellHeightForItem:(BFSettingsItem *)item;

@end

@interface BFSettingsCellManager : NSObject <BFSettingsCellManager>

- (instancetype)initWithNibOrCellClass:(id)nibOrCellClass NS_DESIGNATED_INITIALIZER;

@end

NS_ASSUME_NONNULL_END
