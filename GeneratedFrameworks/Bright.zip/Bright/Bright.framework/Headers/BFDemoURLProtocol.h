#import "BFDemoService+Private.h"

@interface BFDemoURLProtocol : NSURLProtocol

+ (void)setDemoService:(BFDemoServiceImplementation *)service;

@end
