#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@class BFError;

NS_ASSUME_NONNULL_BEGIN

typedef NSString *BFAlertViewButton;
extern BFAlertViewButton const BFAlertViewButtonOK;
extern BFAlertViewButton const BFAlertViewButtonRetry;
extern BFAlertViewButton const BFAlertViewButtonCancel;
extern BFAlertViewButton const BFAlertViewButtonYes;
extern BFAlertViewButton const BFAlertViewButtonNo;

@class BFAlertView;

typedef void (^BFAlertViewCompletionHandler)(BFAlertViewButton button);
typedef void (^BFAlertViewButtonIndexCompletionHandler)(BFAlertView *alertView, NSInteger buttonIndex);

NS_CLASS_DEPRECATED_IOS(2_0, 9_0)
@interface BFAlertView : UIAlertView

+ (instancetype)showAlertForError:(BFError *)error callback:(nullable BFAlertViewCompletionHandler)callback;
+ (instancetype)showAlertForError:(BFError *)error cancelButtonKey:(nullable NSString *)cancelButtonKey otherButtonKeys:(nullable NSArray<NSString*> *)otherButtonKeys callback:(nullable BFAlertViewCompletionHandler)callback;

+ (instancetype)showAlertForLocalizedKey:(NSString *)key callback:(BFAlertViewCompletionHandler)callback;
+ (instancetype)showAlertForLocalizedKey:(NSString *)key cancelButtonKey:(nullable NSString *)cancelButtonKey otherButtonKeys:(nullable NSArray<NSString*> *)otherButtonKeys callback:(nullable BFAlertViewCompletionHandler)callback;

+ (instancetype)showAlertWithTitle:(nullable NSString *)title message:(nullable NSString *)message callback:(nullable BFAlertViewCompletionHandler)callback;
+ (instancetype)showAlertWithTitle:(nullable NSString *)title message:(nullable NSString *)message cancelButtonKey:(nullable NSString *)cancelButtonKey otherButtonKeys:(nullable NSArray<NSString*> *)otherButtonKeys callback:(nullable BFAlertViewCompletionHandler)callback;

+ (BOOL)hasActiveAlertViews;
+ (void)dismissActiveAlertViews;
+ (void)dismissActiveAlertViewsAnimated:(BOOL)animated;

- (void)showWithCompletion:(nullable BFAlertViewButtonIndexCompletionHandler)completion;

@end

NS_ASSUME_NONNULL_END
