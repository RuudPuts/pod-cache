#import <Bright/BFHTTPRequestOperation.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFHTTPDataEncoder : NSObject <BFHTTPBodyEncoder>

+ (instancetype)encoderWithData:(NSData *)data;
+ (instancetype)encoderWithData:(NSData *)data contentType:(NSString *)contentType;

- (instancetype)initWithData:(NSData *)data;
- (instancetype)initWithData:(NSData *)data contentType:(NSString *)type NS_DESIGNATED_INITIALIZER;

- (instancetype)init NS_UNAVAILABLE;

@property (nonatomic, copy) NSData *data;
@property (nonatomic, copy, nullable) NSString *contentType;

@end

NS_ASSUME_NONNULL_END
