#import <Bright/Bright.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFSettingsViewController ()

@property (nonatomic, weak) IBOutlet UITableView *settingsTableView;

- (void)navigateToDetailsViewController:(UIViewController <BFViewController> *)detailsViewController;
- (void)navigateBackFromDetailsViewController:(UIViewController <BFViewController> *)detailsViewController;

@end

NS_ASSUME_NONNULL_END
