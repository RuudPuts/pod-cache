#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

//! Project version number for Bright.
FOUNDATION_EXPORT double BrightVersionNumber;

//! Project version string for Bright.
FOUNDATION_EXPORT const unsigned char BrightVersionString[];

#import "BFGoogleAnalyticsService.h"
