#import <Bright/BFHTTPRequestOperation.h>

NS_ASSUME_NONNULL_BEGIN

typedef id _Nullable (^BFResponseDecoderBlock)(NSURLResponse *response, NSData *data, BFURLConnectionOperation *operation, NSError **error);

@interface BFBlockResponseDecoder : NSObject <BFHTTPRequestResponseDecoder>

+ (instancetype)decoderWithBlock:(BFResponseDecoderBlock)block;

@end

NS_ASSUME_NONNULL_END
