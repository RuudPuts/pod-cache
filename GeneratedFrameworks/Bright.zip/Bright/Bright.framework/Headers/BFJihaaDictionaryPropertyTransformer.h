#import <Bright/BFJihaaPropertyTransformer.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFJihaaDictionaryPropertyTransformer : BFJihaaPropertyTransformer

- (instancetype)init NS_UNAVAILABLE;

- (instancetype)initForObjectClass:(Class)cls attributes:(nullable NSSet *)attributes NS_DESIGNATED_INITIALIZER;

@property (nonatomic, readonly) Class dictionaryObjectClass;
@property (nonatomic, readonly, nullable) NSSet *attributes;

@end

NS_ASSUME_NONNULL_END
