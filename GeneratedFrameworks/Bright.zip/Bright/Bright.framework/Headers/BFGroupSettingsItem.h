#import <Bright/BFSettingsItem.h>
#import <Bright/BFSettingsManager.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFGroupSettingsItem : BFSettingsItem <BFSettingsItemDataSource>

@end

NS_ASSUME_NONNULL_END
