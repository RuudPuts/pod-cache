#import <Bright/BFJihaaPropertyTransformer.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFJihaaPassthroughPropertyTransformer : BFJihaaPropertyTransformer

- (instancetype)init NS_UNAVAILABLE;

- (instancetype)initForClass:(Class)cls NS_DESIGNATED_INITIALIZER;

@property (nonatomic, readonly) Class passthroughClass;

@end

NS_ASSUME_NONNULL_END
