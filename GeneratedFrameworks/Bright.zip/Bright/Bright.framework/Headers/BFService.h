#import <Bright/BFModule.h>
#import <Bright/BFError.h>
#import <Bright/BFHTTPRequestOperation.h>

NS_ASSUME_NONNULL_BEGIN

typedef void(^BFServiceSuccessHandler)(void);
typedef void(^BFServiceDataSuccessHandler)(id data);
typedef void(^BFServicePagingSuccessHandler)(NSArray *data, BOOL hasReachedEnd, NSNumber * _Nullable totalCount);
typedef void(^BFServiceFailureHandler)(BFError *error);
typedef void(^BFServiceProgressHandler)(NSInteger bytes, NSInteger totalBytes, long long totalBytesExpected);

extern BFHTTPRequestOperationSuccessBlock BFHTTPSuccessHandlerForSuccess(_Nullable BFServiceSuccessHandler handler);
extern BFHTTPRequestOperationSuccessBlock BFHTTPSuccessHandlerForSuccessData(_Nullable  BFServiceDataSuccessHandler handler);
extern BFHTTPRequestOperationFailureBlock BFHTTPFailureHandlerForFailure(_Nullable BFServiceFailureHandler handler);
extern BFHTTPRequestOperationProgressBlock BFHTTPProgressHandlerForProgress(_Nullable BFServiceProgressHandler handler);

@protocol BFServiceInterface <BFModuleInterface>
@end

@protocol BFServiceObserver <BFModuleObserver>
@end

@interface BFService : BFModule <BFServiceInterface>

@end

NS_ASSUME_NONNULL_END
