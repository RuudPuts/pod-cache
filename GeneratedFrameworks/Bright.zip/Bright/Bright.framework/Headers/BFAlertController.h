#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <Bright/BFViewController.h>
#import <Bright/BFError.h>

@protocol BFAlertAction;

NS_ASSUME_NONNULL_BEGIN

typedef void (^BFAlertActionCallback)(id <BFAlertAction> action);

@protocol BFAlertAction <NSCopying, NSObject, UIAccessibilityIdentification>

@property (nonatomic, copy, readonly, nullable) NSString *title;
@property (nonatomic, readonly) UIAlertActionStyle style;
@property (nonatomic, getter=isEnabled) BOOL enabled;

- (void)invokeAction;

@end

@interface BFAlertController : NSObject <UIAccessibilityIdentification>

+ (void)setViewControllerClass:(Class)cls forStyle:(UIAlertControllerStyle)style;
+ (void)setViewControllerClass:(Class)cls forCustomStyleWithIdentifier:(NSString *)styleIdentifier;

+ (instancetype)alertControllerWithTitle:(nullable NSString *)title message:(nullable NSString *)message preferredStyle:(UIAlertControllerStyle)preferredStyle;
+ (instancetype)alertControllerWithTitle:(nullable NSString *)title message:(nullable NSString *)message styleIdentifier:(NSString *)styleIdentifier;
+ (instancetype)alertControllerForError:(BFError *)error;

+ (instancetype)showAlertWithTitle:(nullable NSString *)title message:(nullable NSString *)message inViewController:(UIViewController *)viewController completion:(void(^ __nullable)(void))completion;
+ (instancetype)showAlertWithTitleKey:(nullable NSString *)titleKey messageKey:(nullable NSString *)messageKey inViewController:(UIViewController *)viewController completion:(void(^ __nullable)(void))completion;
+ (instancetype)showAlertForError:(BFError *)error inViewController:(UIViewController *)viewController completion:(void (^ __nullable)(void))completion;

+ (void)dismissActiveAlertControllers;
+ (void)dismissActiveAlertControllersForStyle:(UIAlertControllerStyle)style;

- (void)addAction:(id <BFAlertAction>)action;
- (id <BFAlertAction>)addActionWithTitle:(nullable NSString *)title handler:(nullable BFAlertActionCallback)handler;
- (id <BFAlertAction>)addActionWithTitle:(nullable NSString *)title style:(UIAlertActionStyle)style handler:(nullable BFAlertActionCallback)handler;

- (id <BFAlertAction>)addActionWithKey:(NSString *)key handler:(nullable BFAlertActionCallback)handler;
- (id <BFAlertAction>)addActionWithKey:(NSString *)key style:(UIAlertActionStyle)style handler:(nullable BFAlertActionCallback)handler;

@property (nonatomic, readonly) NSArray<id <BFAlertAction>> *actions;

@property (nonatomic, copy, nullable) NSString *title;
@property (nonatomic, copy, nullable) NSString *message;

@property (nonatomic, readonly) UIAlertControllerStyle preferredStyle;
@property (nonatomic, readonly, nullable) NSString *styleIdentifier;

@property (nonatomic, copy, nullable) NSDictionary *customViewControllerOptions;

@property (nonatomic, assign) BOOL dismissWhenEnteringBackground;

- (void)showInViewController:(UIViewController *)viewController;

@end

@protocol BFAlertPresentationViewController <NSObject>
@required

- (void)setActions:(NSArray<id <BFAlertAction>> *)actions;

@optional

- (void)setMessage:(nullable NSString *)message;
- (void)setCustomOptions:(nullable NSDictionary *)customOptions;

@end

NS_ASSUME_NONNULL_END
