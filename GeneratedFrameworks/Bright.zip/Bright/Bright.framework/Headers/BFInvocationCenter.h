#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/**
 This class is similar to `NSNotificationCenter` in that objects can register as observers. Instead of observing for specific notifications however, the objects are observes for calls to methods from a specific protocol.
 
 So an object implements a protocol, registers itself as an observer for that protocol. Afterwards another object can request a proxy for this protocol and call any methods on this proxy that are in that protocol. The proxy will then forward this call to all observers for this protocol.
 */
@interface BFInvocationCenter : NSObject

///------------------------------------------///
/// @name Retrieving the default `BFInvocationCenter`
///------------------------------------------///

/**
 Returns the default shared `BFInvocationCenter` instance.
 
 @return The default `BFInvocationCenter`.
 */
+ (instancetype)defaultCenter;

///------------------------------------------///
/// @name Managing observers
///------------------------------------------///

/**
 Adds an object as an observer for a specific protocol to the receiver’s dispatch table.
 
 @param observer The observer to add.
 @param protocol The protocol for which to register the observer.
 @param invocationSender The object whose proxy calls the observer wants to receive; that is, only messages to the proxy sent by this sender are delivered to the observer. If you pass nil, the observer will receive messages from all senders.
 */
- (void)addObserver:(NSObject *)observer protocol:(Protocol *)protocol object:(nullable id)invocationSender;

/**
 Removes matching entries from the receiver’s dispatch table.
 
 @param observer The observer to remove.
 @param protocol The protocol for which to remove the observer from the dispatch table. When `nil`, the receiver does not use the protocol as criteria for removal.
 @param invocationSender The sender for which to remove the observer from the dispatch table. When `nil`, the receiver does not use the sender as criteria for removal.
 */
- (void)removeObserver:(NSObject *)observer protocol:(nullable Protocol *)protocol object:(nullable id)invocationSender;

/**
 Removes all the entries specifying a given observer from the receiver’s dispatch table.
 
 @param observer The observer to remove.
 */
- (void)removeObserver:(NSObject *)observer;

///------------------------------------------///
/// @name Retrieving a proxy
///------------------------------------------///

/**
 Returns a proxy for the given protocol.
 
 Any method that is part of the given protocol can be called on the returned proxy. Each call will be forwarded to all observers at the time of the call.
 
 The proxy object can be stored for later use, but it will not be retained by this `BFInvocationCenter`.
 
 @param protocol The protocol for which to receive the proxy object.
 @param invocationSender The object which will make calls to the proxy object.
 @return The proxy object.
 */
- (id)proxyForProtocol:(Protocol *)protocol object:(id)invocationSender;

/**
 Returns a proxy for the given protocol.
 
 Any method that is part of the given protocol can be called on the returned proxy. Each call will be forwarded to all observers at the time of the call.
 
 The proxy object can be stored for later use, but it will not be retained by this `BFInvocationCenter`.
 
 @param protocol The protocol for which to receive the proxy object.
 @param invocationSender The object which will make calls to the proxy object.
 @param callbackOnMainThread Indicates whether observers are called on the main thread. If `NO` they will simply be called on the current thread.
 @return The proxy object.
 */
- (id)proxyForProtocol:(Protocol *)protocol object:(id)invocationSender callbackOnMainThread:(BOOL)callbackOnMainThread;

@end

NS_ASSUME_NONNULL_END
