#import <Bright/BFJihaaObject.h>

NS_ASSUME_NONNULL_BEGIN

@protocol BFJihaaPropertyTransformer <NSObject>

@property (nonatomic, readonly, strong) Class valueClass;
@property (nonatomic, readonly, strong) Class jsonValueClass;

- (nullable id)encodeObject:(id)object path:(NSArray *)path parentAttributes:(nullable NSSet *)parentAttributes parentObject:(nullable id)parentObject encodedParentObject:(nullable id)encodedParentObject error:(NSError **)error;
- (nullable id)decodeJSONObject:(id)jsonObject path:(NSArray *)path parentAttributes:(nullable NSSet *)parentAttributes parentObject:(nullable id)parentObject decodedParentObject:(nullable id)decodedParentObject error:(NSError **)error;

@end

@interface BFJihaaPropertyTransformer : NSObject <BFJihaaPropertyTransformer>

- (BOOL)validateObject:(id)object expectedClass:(Class)cls path:(NSArray *)path error:(NSError **)error;
- (NSError *)errorWithCode:(BFJihaaErrorCode)errorCode path:(NSArray *)path format:(NSString *)format, ... NS_FORMAT_FUNCTION(3,4);

@end

NS_ASSUME_NONNULL_END
