#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSData (BFAdditions)

///------------------------------------------///
/// @name Creating a hash
///------------------------------------------///

/**
 Returns the MD5 hash for the current data.
 
 @return The MD5 hash.
 */
@property (nonatomic, readonly, copy) NSString *BFMD5Hash;

/**
 Returns the SHA1 hash for the current data.
 
 @return The SHA1 hash.
 */
@property (nonatomic, readonly, copy) NSString *BFSHA1Hash;

///------------------------------------------///
/// @name Hex
///------------------------------------------///

@property (nonatomic, readonly, copy) NSString *BFHexString;

@end

NS_ASSUME_NONNULL_END
