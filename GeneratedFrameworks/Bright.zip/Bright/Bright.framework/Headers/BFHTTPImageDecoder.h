#import <Bright/BFHTTPRequestOperation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

extern UIImage * _Nullable BFInflatedImageFromResponseWithDataAtScale(NSURLResponse *response, NSData *data, CGFloat scale);

@interface BFHTTPImageDecoder : NSObject <BFHTTPRequestResponseDecoder>

+ (instancetype)decoder;

@property (nonatomic, assign) CGFloat imageScale;
@property (nonatomic, assign) BOOL automaticallyInflatesResponseImage;

@end

NS_ASSUME_NONNULL_END
