#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@class BFGradient;

NS_ASSUME_NONNULL_BEGIN

/**
 Alignment values, used for placement of views. Each alignment value is basically a combination of `UIViewAutoresizing` flags, which can be used as the `autoresizingMask` property value of `UIView`.
 */
typedef NS_OPTIONS(NSUInteger, BFViewAlignment) {
    BFViewAlignmentLeft = UIViewAutoresizingFlexibleRightMargin,
    BFViewAlignmentRight = UIViewAutoresizingFlexibleLeftMargin,
    BFViewAlignmentHCenter = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin,
    BFViewAlignmentHFill = UIViewAutoresizingFlexibleWidth,
    
    BFViewAlignmentTop = UIViewAutoresizingFlexibleBottomMargin,
    BFViewAlignmentBottom = UIViewAutoresizingFlexibleTopMargin,
    BFViewAlignmentVCenter = UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleBottomMargin,
    BFViewAlignmentVFill = UIViewAutoresizingFlexibleHeight,
    
    BFViewAlignmentCenter = BFViewAlignmentHCenter | BFViewAlignmentVCenter,
    BFViewAlignmentFill = BFViewAlignmentHFill | BFViewAlignmentVFill,
	
    BFViewAlignmentNone = UIViewAutoresizingNone,
};

/**
 The possible gradient directions.
 */
typedef NS_ENUM(NSUInteger, BFGradientDirection) {
	BFGradientTop2Bottom,
	BFGradientBottom2Top,
	BFGradientLeft2Right,
	BFGradientRight2Left,
	BFGradientTopLeft2BottomRight,
	BFGradientBottomRight2TopLeft,
	BFGradientTopRight2BottomLeft,
	BFGradientBottomLeft2TopRight
};

extern CGFloat const kUIPhoneKeyboardHeight;

/**
 Aligns a `CGRect` in another given `CGRect` based on a `BFViewAlignment` value.
 
 @param rectToAlign The `CGRect` to align.
 @param parentSize The `CGSize` of the parent rect in which to align.
 @param alignment The `BFViewAlignment` used for alignment calculations.
 @param edgeInsets The edge insets to use for alignment.
 @return The aligned `CGRect`.
 */
extern CGRect CGRectAlign(CGRect rectToAlign, CGSize parentSize, BFViewAlignment alignment, UIEdgeInsets edgeInsets);

/**
 Custom `CGRectIntegral` method which actually basis its calculations on the screen scale.
 
 @param rect The rect to integral.
 @return The integralled rect.
 */
extern CGRect CGRectIntegralScaled(CGRect rect);

extern CGRect CGRectRound(CGRect rect);

extern CGFloat CGFloatRoundedByScreenScale(CGFloat value);

/**
 Returns the center point of a given rectangle.
 
 @param rect The rectangle.
 @return The center point for the rectangle.
 */
extern CGPoint CGRectGetCenterPoint(CGRect rect);

extern CGRect CGRectAspectFit(CGSize aspectRatio, CGRect boundingRect);

extern CGRect CGRectAspectFill(CGSize aspectRatio, CGRect boundingRect);

/**
 Indicates whether a specific `CGSize` will fit in another `CGSize`.
 
 @param size1 The size to check if it fits in `size2`.
 @param size2 The size to check if `size1` fits into it.
 @return `YES` if `size1` fits in `size2`, `NO` otherwise.
 */
extern BOOL CGSizeFitsInSize(CGSize size1, CGSize size2);

/**
 Draws a gradient in a given bitmap context.
 
 @param c The context to draw the gradient in.
 @param rect The bounding rectangle in which the gradient should be drawn.
 @param gradient The gradient to draw.
 @param startPoint The coordinate that defines the starting point of the gradient.
 @param endPoint The coordinate that defines the ending point of the gradient.
 */
extern void CGContextDrawGradient(CGContextRef c, CGRect rect, BFGradient *gradient, CGPoint startPoint, CGPoint endPoint);

/**
 Draws a gradient in a given bitmap context.
 
 @param c The context to draw the gradient in.
 @param rect The bounding rectangle in which the gradient should be drawn.
 @param gradient The gradient to draw.
 @param direction The direction of the gradient.
 */
extern void CGContextDrawGradientWithDirection(CGContextRef c, CGRect rect, BFGradient *gradient, BFGradientDirection direction);

extern NSTimeInterval statusBarFrameAnimationDuration(void);

extern CGFloat statusBarHeight(void);

extern CGFloat defaultToolbarHeightForOrientation(UIInterfaceOrientation orientation);

NS_ASSUME_NONNULL_END
