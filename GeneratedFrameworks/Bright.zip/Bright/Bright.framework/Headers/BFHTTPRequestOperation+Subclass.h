NS_ASSUME_NONNULL_BEGIN

@interface BFHTTPRequestOperation ()

@property (nonatomic, copy, nullable) BFHTTPRequestOperationSuccessBlock successBlock;
@property (nonatomic, copy, nullable) BFHTTPRequestOperationFailureBlock failureBlock;

@end

NS_ASSUME_NONNULL_END
