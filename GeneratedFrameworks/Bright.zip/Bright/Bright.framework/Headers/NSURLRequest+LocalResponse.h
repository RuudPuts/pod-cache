#import <Bright/BFLocalURLRequestResponse.h>
#import <Bright/BFError.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSURLRequest (BFLocalResponse)

@property (nonatomic, strong, nullable) BFLocalURLRequestResponse *localResponse;

@property (nonatomic, assign, readonly, getter = isLocalResponseEnabled) BOOL localResponseEnabled;
@property (nonatomic, assign, readonly) NSTimeInterval localResponseInvalidationTime;
@property (nonatomic, assign, readonly) BOOL shouldDirectlyReturnLocalResponseIfAvailable;
@property (nonatomic, assign, readonly) BOOL shouldFailIfLocalResponseIsInvalid;

@property (nonatomic, assign, readonly, nullable) BFError *localResponseActualRequestError;

@end

@interface NSMutableURLRequest (BFLocalResponse)

@property (nonatomic, assign, readwrite, getter = isLocalResponseEnabled) BOOL localResponseEnabled;
@property (nonatomic, assign, readwrite) NSTimeInterval localResponseInvalidationTime;
@property (nonatomic, assign, readwrite) BOOL shouldDirectlyReturnLocalResponseIfAvailable;
@property (nonatomic, assign, readwrite) BOOL shouldFailIfLocalResponseIsInvalid;

@property (nonatomic, assign, readwrite, nullable) BFError *localResponseActualRequestError;

@end

NS_ASSUME_NONNULL_END
