NS_ASSUME_NONNULL_BEGIN

@interface BFEnumSettingsDetailsTableViewCell : UITableViewCell

@property (nonatomic, strong, nullable) NSString *valueDescription;

@end

NS_ASSUME_NONNULL_END
