#import <Bright/BFModule.h>

@class BFViewController;
@protocol BFViewController;

NS_ASSUME_NONNULL_BEGIN

@protocol BFUIProviderInterface <BFModuleInterface>
@end

@protocol BFUIProviderObserver <BFModuleObserver>
@end

@interface BFUIProvider : BFModule <BFUIProviderInterface>

@end

NS_ASSUME_NONNULL_END
