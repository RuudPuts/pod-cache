#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIColor (BFAdditions)

+ (instancetype)colorWithHex:(NSInteger)hex;
+ (instancetype)colorWithHex32:(NSInteger)hex;
+ (instancetype)colorWithHex:(NSInteger)hex alpha:(CGFloat)alpha;

+ (nullable instancetype)colorWithHexText:(nullable NSString *)hexString;

@property (nonatomic, readonly, copy) NSString *hexStringValue;
@property (nonatomic, readonly, copy) NSString *hex32StringValue;
@property (nonatomic, readonly, copy) NSString *cssHexStringValue;

@property (nonatomic, readonly, strong) UIImage *image;
- (UIImage *)imageWithCornerRadius:(CGFloat)cornerRadius;

+ (UIColor *)randomColor;
+ (UIColor *)randomGrayColor;

@end

NS_ASSUME_NONNULL_END
