#import <Bright/BFSettingsCellManager.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFURLSettingsCellManager : BFSettingsCellManager

@end

NS_ASSUME_NONNULL_END
