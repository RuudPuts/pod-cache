#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFInvocationCenterEntry : NSObject

- (instancetype)initWithObject:(nullable id)object NS_DESIGNATED_INITIALIZER;

@property (nonatomic, weak, readonly, nullable) id object;

@end

NS_ASSUME_NONNULL_END
