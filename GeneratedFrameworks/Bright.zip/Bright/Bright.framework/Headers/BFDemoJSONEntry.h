#import <Bright/BFJihaaObject.h>

BFJihaaDecoration(BFDemoJSONEntry);

@interface BFDemoJSONEntry : BFJihaaObject

@property (nonatomic, strong) NSNumber <BFJihaaOptional> *isResource;
@property (nonatomic, copy) NSString <BFJihaaOptional> *MIMEType;
@property (nonatomic, strong) id <BFJihaaOptional> data;

@end
