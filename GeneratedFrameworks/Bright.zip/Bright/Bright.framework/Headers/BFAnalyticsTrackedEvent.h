#import <Bright/BFJihaaObject.h>

NS_ASSUME_NONNULL_BEGIN

BFJihaaDecoration(BFAnalyticsTrackedEvent);

@interface BFAnalyticsTrackedEvent : BFJihaaObject

@property (nonatomic, assign) NSTimeInterval timestamp;

@property (nonatomic, copy, nullable) NSString <BFJihaaOptional> *module;
@property (nonatomic, copy, nullable) NSString *category;
@property (nonatomic, copy, nullable) NSString *action;
@property (nonatomic, copy, nullable) NSString <BFJihaaOptional> *label;
@property (nonatomic, strong, nullable) NSNumber <BFJihaaOptional> *value;

@end

NS_ASSUME_NONNULL_END
