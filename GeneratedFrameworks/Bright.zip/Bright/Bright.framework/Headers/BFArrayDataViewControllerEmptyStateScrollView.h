#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@protocol BFArrayDataViewControllerEmptyStateScrollViewDelegate;

@interface BFArrayDataViewControllerEmptyStateScrollView : UIScrollView

@property (nonatomic, weak) id <BFArrayDataViewControllerEmptyStateScrollViewDelegate> emptyStateScrollViewDelegate;

@end

@protocol BFArrayDataViewControllerEmptyStateScrollViewDelegate <NSObject>

- (void)emptyStateScrollViewDidScroll:(BFArrayDataViewControllerEmptyStateScrollView *)scrollView;

@end

NS_ASSUME_NONNULL_END
