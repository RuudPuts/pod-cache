#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/**
 Category on `UIImage` to create an image by drawing on a context.
 */
@interface UIImage (BFDraw)

///------------------------------------------///
/// @name Drawing an image
///------------------------------------------///

/**
 Creates a new image of a specific size and uses a block to draw on this image.
 
 @param size The size of the image.
 @param opaque Indicates whether the image should be opaque.
 @param block The block in which the image will be drawn. It has the current bitmap context and the drawing rectangle as parameters.
 @return The created image.
 */
+ (UIImage *)imageWithSize:(CGSize)size opaque:(BOOL)opaque drawBlock:(void(^)(CGContextRef ctx, CGRect rect))block;

+ (UIImage *)imageWithSize:(CGSize)size opaque:(BOOL)opaque blurredWithRadius:(CGFloat)blurRadius tintColor:(nullable UIColor *)tintColor saturationDeltaFactor:(CGFloat)saturationDeltaFactor maskImage:(nullable UIImage *)maskImage drawBlock:(void(^)(CGContextRef ctx, CGRect rect))block;

+ (UIImage *)lightEffectImageWithSize:(CGSize)size opaque:(BOOL)opaque drawBlock:(void(^)(CGContextRef ctx, CGRect rect))block;
+ (UIImage *)extraLightEffectImageWithSize:(CGSize)size opaque:(BOOL)opaque drawBlock:(void(^)(CGContextRef ctx, CGRect rect))block;
+ (UIImage *)darkEffectImageWithSize:(CGSize)size opaque:(BOOL)opaque drawBlock:(void(^)(CGContextRef ctx, CGRect rect))block;

@end

NS_ASSUME_NONNULL_END
