#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/**
 Timer similar to `NSTimer` but using GCD methods. This allows you to specify blocks to be called when the timer ticks, instead of having to create a new callback method.
 
 `NSTimer` can only be used once, after invalidation a new one has to be created. The `BFGCDTimer` can be used as many times as needed. However, everytime the <run:> is called, the previous <run:> method is cancelled and a new one is scheduled.
 
 The advantage of using a timer over the `dispatch_after` method, is that the timer can be cancelled.
 
 To start a timer, simply call the <run:> method.
 */
@interface BFGCDTimer : NSObject

///------------------------------------------///
/// @name Initializing a timer
///------------------------------------------///

/**
 Creates an <BFGCDTimer> on the current queue which fires after a given interval.
 
 This timer will not repeat.
 
 @param seconds The interval after which the timer will fire.
 @return The created timer.
 */
+ (instancetype)timerWithTimeInterval:(NSTimeInterval)seconds;

/**
 Creates an <BFGCDTimer> on the current queue which fires after a given interval.
 
 @param seconds The interval after which the timer will fire.
 @param repeats Indicates whether the timer will fire more than once.
 @return The created timer.
 */
+ (instancetype)timerWithTimeInterval:(NSTimeInterval)seconds repeats:(BOOL)repeats;

/**
 Creates an <BFGCDTimer> which fires after a given interval.
 
 @param queue The queue on which the timer will be scheduled.
 @param seconds The interval after which the timer will fire.
 @param repeats Indicates whether the timer will fire more than once.
 @return The created timer.
 */
+ (instancetype)timerWithQueue:(nullable dispatch_queue_t)queue timeInterval:(NSTimeInterval)seconds repeats:(BOOL)repeats;

/**
 Initializes an <BFGCDTimer> on the current queue which fires after a given interval.
 
 @param seconds The interval after which the timer will fire.
 @param repeats Indicates whether the timer will fire more than once.
 @return The initialized timer.
 */
- (instancetype)initWithTimeInterval:(NSTimeInterval)seconds repeats:(BOOL)repeats;

/**
 Initializes an <BFGCDTimer> on the current queue which fires after a given interval.
 
 @param queue The queue on which the timer will be scheduled.
 @param seconds The interval after which the timer will fire.
 @param repeats Indicates whether the timer will fire more than once.
 @return The initialized timer.
 */
- (instancetype)initWithQueue:(nullable dispatch_queue_t)queue timeInterval:(NSTimeInterval)seconds repeats:(BOOL)repeats NS_DESIGNATED_INITIALIZER;

///------------------------------------------///
/// @name Configuring the timer
///------------------------------------------///

/**
 The queue on which the timer will be scheduled.
 
 When the timer is run, the completion handler will also be called on this queue.
 */
@property (nonatomic, readonly) dispatch_queue_t queue;

/**
 The interval after which the timer will fire.
 */
@property (nonatomic, assign) NSTimeInterval timeInterval;

/**
 Indicates whether the timer will fire more than once.
 */
@property (nonatomic, assign) BOOL repeats;

///------------------------------------------///
/// @name Managing the timer
///------------------------------------------///

/**
 Indicates whether the timer is currently running.
 */
@property (nonatomic, readonly, getter = isRunning) BOOL running;

/**
 Starts the timer with a given completion method.
 
 When <repeats> is set to `YES`, the completion method can be called more than once.
 
 If this method is called while the timer is running, the timer is cancelled and rescheduled. In this case, the first completion method is not called.
 
 @param completion The completion method to call when the timer fires.
 */
- (void)run:(void(^)(BFGCDTimer *timer))completion;

/**
 Cancels the currently scheduled timer.
 */
- (void)cancel;

@end

NS_ASSUME_NONNULL_END
