#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UITextField (BFAdditions)

- (BOOL)shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string maxLength:(NSInteger)maxLength block:(NSString *(^ _Nullable)(NSString *replacementString))block;

@end

@interface UITextView (BFAdditions)

- (BOOL)shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text maxLength:(NSInteger)maxLength block:(NSString *(^ _Nullable)(NSString *replacementText))block;

@end

NS_ASSUME_NONNULL_END
