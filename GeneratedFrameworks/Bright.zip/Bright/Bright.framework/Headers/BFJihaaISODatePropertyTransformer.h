#import <Bright/Bright.h>

@interface BFJihaaISODatePropertyTransformer : BFJihaaPropertyTransformer

@end
