#import <Bright/BFSettingsItem.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFBoolSettingsItem : BFSettingsItem

@property (nonatomic, strong, nullable) NSNumber *currentValue;
@property (nonatomic, readonly) BOOL currentBoolValue;

@property (nonatomic, strong, nullable) NSNumber *defaultValue;

@end

NS_ASSUME_NONNULL_END
